### ios Wallet 

### 一. category

 1. Boarding pass 登机牌，如飞机票、火车票
 2. Coupon 优惠券，如打折券、减免券。一般为一次性使用的券。
 3. Event ticket 票，如电影票、演出票
 4. Generic 通用类型。
 5. Store card 购物卡。可以显示余额等信息。
 
 
 
###  二. create

eg: create Event ticket

实例下载:
https://developer.apple.com/services-account/download?path=/iOS/Wallet_Support_Materials/WalletCompanionFiles.zip

1. Creating and Populating the Pass Package（创建一个包含Pass所有信息和资源文件的文件夹）

2. Setting the Pass Type Identifier and Team ID（设置PassTypeId和Team ID）

3. Signing and Compressing the Pass（签名并压缩 pass ）

```
cd ~/Documents 
```

```
./signpass -p filmTicket.pass
```

```
@IBAction func showWalletPass(_ sender: Any) {
    guard PKPassLibrary.isPassLibraryAvailable() else {
        return
    }
    guard let fileUrl = Bundle.main.url(forResource: "Lollipop", withExtension: "pkpass") else {
        return
    }
    guard let passData = try? Data.init(contentsOf: fileUrl) else {
        return
    }
    var error: NSError?
    let pass = PKPass(data: passData, error: &error)
    if error != nil {
        showAlert(message: "\(String(describing: error?.localizedDescription))")
        return
    }
    if PKAddPassesViewController.canAddPasses() {
        showPass(pass: pass)
    } else {
    }
}
```

```
func showPass(pass: PKPass) {
    passToAdd = pass
    let addPassVc = PKAddPassesViewController(pass: pass)
    addPassVc.delegate = self
    self.present(addPassVc, animated: true) {
    }
}
```
官方说明文档: 
https://developer.apple.com/library/archive/documentation/UserExperience/Reference/PassKit_Bundle/Chapters/LowerLevel.html#//apple_ref/doc/uid/TP40012026-CH3-SW3

pass.json说明文档
https://developer.apple.com/library/archive/documentation/UserExperience/Reference/PassKit_Bundle/Chapters/LowerLevel.html#//apple_ref/doc/uid/TP40012026-CH3-SW3 




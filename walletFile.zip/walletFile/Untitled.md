1. Creating and Populating the Pass Package（创建一个包含Pass所有信息和资源文件的文件夹）
Passes 的创建需要一个 pass.json 文件，这个 pass.json 文件包含 pass 的所有信息，如票据类型，logo、icon资源图片，过期时间、票据描述等信息。将 pass.json 和需要的图片资源文件一起放入一个文件夹，然后从这个文件夹生成 Pass。

创建步骤：

创建一个 filmTicket.pass 文件夹，使用 .pass 作为文件夹的后缀名，放在 Documents 目录下。
这里下载示例文件。
解压缩，将 Event.pass 文件夹中的所有内容拷贝到 filmTicket.pass 文件夹中。
image.png
2.Setting the Pass Type Identifier and Team ID（设置PassTypeId和Team ID）
每一个 pass 都需要通过一个 PassTypeID 关联到一个开发者账号下。所有的 PassTypeID 都通过开发者账号中心管理。想要创建 pass ，必须到开发者账号下配置你的 PassTypeID 。

**创建 PassTypeID **

到你的开发者账号中心，找到Certificates, Identifiers & Profiles，选择 Identifiers。
在 Identifiers 下, 选择 Pass Type IDs。
点击右上角 + 按钮。
填写描述和 Pass Type ID 并提交。
image.png
查看 Team ID:

到开发者账号下，选择 MemberShip 。
image.png
**添加 PassTypeID 和 Team ID 到 pass.json **

打开 filmTicket.pass 文件夹下的 pass.json , 将 PassTypeID 和 Team ID 替换为自己开发者账号下的。

{
...
"passTypeIdentifier" : "your pass type identifier",
"teamIdentifier" : "your Team ID",
...
}
3. Signing and Compressing the Pass（签名并压缩 pass ）
As part of building your production environment, you will need to set up a system for automatically signing and compressing passes as described in Passes Are Cryptographically Signed and Compressed. For this tutorial, a very simple tool for signing passes is included.

下载签名证书

在 Certificates, Identifiers & Profiles, 选择 Identifiers
在 Identifiers 下，选择 Pass Type IDs.
选择你已经创建好的 pass type identifier， 点击编辑。
如果已经存在证书文件，直接点击下载即可。如果没有，点击创建，按照提示创建一个（与创建 APNs 推送证书基本一样）。
image.png
生成 .pkpass 后缀的压缩文件

找到上面已经下载的文件包，找到 signpass 工程，使用 Xcode 打开并运行。
选中 Xcode 中 Products 文件夹下的 signpass 文件，右击鼠标，Show in Finder。
image.png
拷贝 signpass 文件到 filmTicket.pass 文件夹的同级目录（Documents）下。
执行以下语句：
cd ~/Documents
./signpass -p filmTicket.pass
上面语句会生成 filmTicket.pkpass 文件，也就是我们需要的压缩后的 pass。

4. 查看 pass
在 Mac 中直接双击就能打开查看。或者打开你的模拟器，将 filmTicket.pkpass文件拖拽到你的模拟器，就能添加这个 pass 到你模拟器的 Wallet 应用。

5. 修改信息，并重新生成 pass
原有 pass.json 文件内容

{
  "formatVersion" : 1,
  "passTypeIdentifier" : "pass.com.apple.devpubs.example",
  "serialNumber" : "nmyuxofgna",
  "teamIdentifier" : "A93A5CM278",
  "webServiceURL" : "https://example.com/passes/",
  "authenticationToken" : "vxwxd7J8AlNNFPS8k0a0FfUFtq0ewzFdc",
  "relevantDate" : "2011-12-08T13:00-08:00",
  "locations" : [
    {
      "longitude" : -122.3748889,
      "latitude" : 37.6189722
    },
    {
      "longitude" : -122.03118,
      "latitude" : 37.33182
    }
  ],
  "barcode" : {
    "message" : "123456789",
    "format" : "PKBarcodeFormatPDF417",
    "messageEncoding" : "iso-8859-1"
  },
  "organizationName" : "Apple Inc.",
  "description" : "Apple Event Ticket",
  "foregroundColor" : "rgb(255, 255, 255)",
  "backgroundColor" : "rgb(60, 65, 76)",
  "eventTicket" : {
    "primaryFields" : [
      {
        "key" : "event",
        "label" : "EVENT",
        "value" : "The Beat Goes On"
      }
    ],
    "secondaryFields" : [
      {
        "key" : "loc",
        "label" : "LOCATION",
        "value" : "Moscone West"
      }
    ]
  }
}
需要修改 eventTicket 的子级内容

描述信息


image.png
条形码改为二维码，添加描述
// 修改前
"barcode" : {
    "message" : "123456789",
    "format" : "PKBarcodeFormatPDF417",
    "messageEncoding" : "iso-8859-1"
}
// 修改后
"barcode" : {
    "altText" : "订单号：123456",
    "message" : "123456789",
    "format" : "PKBarcodeFormatQR",
    "messageEncoding" : "iso-8859-1"
}
删除原来生成的 filmTicket.pkpass 文件，重复上面的生成步骤。
5. pass.json 设计说明
样式和内容规范
相关 key-value 说明
三、在APP中提供Wallet凭证支持（添加凭证到Wallet）
直接上代码：记得 import PassKit。

将上个步骤生成的 .pkpass 文件拖拽到工程，然后加载本地凭证数据。
@IBAction func showWalletPass(_ sender: Any) {
    guard PKPassLibrary.isPassLibraryAvailable() else {
        showAlert(message: "您的设备不支持Wallet")
        return
    }
    guard let fileUrl = Bundle.main.url(forResource: "Lollipop", withExtension: "pkpass") else {
        showAlert(message: "未找到票据凭证")
        return
    }
    guard let passData = try? Data.init(contentsOf: fileUrl) else {
        showAlert(message: "未找到票据凭证")
        return
    }
    var error: NSError?
    let pass = PKPass(data: passData, error: &error)
    if error != nil {
        showAlert(message: "\(String(describing: error?.localizedDescription))")
        return
    }
    if PKAddPassesViewController.canAddPasses() {
        showPass(pass: pass)
    } else {
        showAlert(message: "您的设备不支持Wallet")
    }
}
显示凭证信息：
func showPass(pass: PKPass) {
    passToAdd = pass
    let addPassVc = PKAddPassesViewController(pass: pass)
    addPassVc.delegate = self
    self.present(addPassVc, animated: true) {
    }
}
用户添加、取消后的回调操作：
extension ViewController: PKAddPassesViewControllerDelegate {
    func addPassesViewControllerDidFinish(_ controller: PKAddPassesViewController) {
        controller.dismiss(animated: true) { [weak self] in
            self?.showLookAlert(message: "添加完成")
        }
    }
}
查看 Wallet 中已添加的凭证：
guard let passURL = self?.passToAdd?.passURL else {
    return
}
if UIApplication.shared.canOpenURL(passURL) {
    UIApplication.shared.open(passURL, options: [:], completionHandler: { _ in
    })
}
四、更新凭证
当你购买了电影票，需要在指定的时间前去观看，超过了这个时间就过期了，那就需要更新凭证。
任何一个凭证凭证都可以通过它的 authentication token 和 serial number 更新。

1. 更新流程简介
Updating a pass is a cooperative effort between the user’s device, Apple’s servers, and your servers. At a high level, it consists of the following steps, shown in Figure 6-1:

pass 被设置为支持更新和安装，并且用户设备注册到你的服务器获取更新。
如果有变更，则触发更新，你的服务器发送推送通知。
用户收到推送后，从你的服务器查询更新的列表。
用户从你的服务器获取每个 pass 的最新版本到自己的设备。
image.png
更新过程中需要使用的信息：
image.png
web server 注意事项
备份私钥和证书，并将其保存在安全的位置。
避免将私钥存储在Web服务器上，因为Web服务器通常具有较大的攻击面。一个更安全的方法是具有不同的服务器句柄创建和签名传递，并将完成的传递推送到您的Web服务器。
当与您的Web服务通话时，序列号，传递类型标识符和last-update标签全部包含在URL中。使其过长可能会对对URL长度造成限制的系统造成问题。
不要更改更新中的身份验证令牌。因为 passes 不能保证被更新，所以仍然可能有具有旧通行证和旧认证令牌的设备。您的服务器必须根据已经有效的每个令牌的列表来检查身份验证令牌。


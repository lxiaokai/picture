https://qualityassurance-amh-dbbsp-mauth-uat.p2g.netd2.hsbc.com.hk/api/v2/auth/login?aid=hsbcbizexpress&did=5e4868eb-712c-47e9-97da-6f26497718e0&sid=e8e4b675-e072-4e83-a6a0-0c4104ffb0a9

获取八位流动编码

```
{
	"headers": [{
		"type": "uid",
		"uid": "amhb2g0680_1"
	}],
	"data": {
		"collection_result": {
			"content": {
				"accounts": [],
				"device_details": {
					"logged_users": 1,
					"biometric_db_hash": "VdYSNiJ9mDM0hUj0c25RmP+tFnYmedcIXpfOj3Qdais=",
					"keychain_err_logs": "1567564969.871122_N/A_rsaEncryptionEnabled_generateKeyPairSuccess,1567564969.682778_N/A_rsaEncryptionEnabled_getKey-private: errSecItemNotFound,1567564969.666376_N/A_rsaEncryptionEnabled_getKey-public: errSecItemNotFound,1567564969.649998_N/A_ecEncryptionEnabled_getKey-private: errSecItemNotFound,1567564969.633541_N/A_ecEncryptionEnabled_getKey-public: errSecItemNotFound,1567564969.618004_N/A_rsa_getKey-private: errSecItemNotFound,1567564969.601553_N/A_rsa_getKey-public: errSecItemNotFound,1567564969.585047_N/A_ec_getKey-private: errSecItemNotFound,1567564969.568509_N/A_ec_getKey-public: errSecItemNotFound,1567564969.541389_N/A_ec_getKey-private: errSecItemNotFound,1567564969.525801_N/A_ec_getKey-public: errSecItemNotFound,1567564969.503554_N/A_ecTarsusStdSigning_generateKeyPairSuccess,1567564969.436284_N/A_rsaTarsusStdSigning_getKey-private: errSecItemNotFound,1567564969.420119_N/A_rsaTarsusStdSigning_getKey-public: errSecItemNotFound,1567564969.403953_N/A_ecTarsusStdSigning_getKey-private: errSecItemNotFound,1567564969.387352_N/A_ecTarsusStdSigning_getKey-public: errSecItemNotFound,1567564969.257290_N/A_rsa_getKey-private: errSecItemNotFound,1567564969.241309_N/A_rsa_getKey-public: errSecItemNotFound,1567564969.224738_N/A_ec_getKey-private: errSecItemNotFound,1567564969.209456_N/A_ec_getKey-public: errSecItemNotFound,1567564969.183757_N/A_ec_getKey-private: errSecItemNotFound,1567564969.167703_N/A_ec_getKey-public: errSecItemNotFound,1567564969.147619_N/A_ec_getKey-private: errSecItemNotFound,1567564969.131583_N/A_ec_getKey-public: errSecItemNotFound,1567564969.115825_N/A_rsa_getKey-private: errSecItemNotFound,1567564969.099905_N/A_rsa_getKey-public: errSecItemNotFound,1567564969.083952_N/A_ec_getKey-private: errSecItemNotFound,1567564969.068221_N/A_ec_getKey-public: errSecItemNotFound,1567564969.052232_N/A_rsa_getKey-private: errSecItemNotFound,1567564969.035881_N/A_rsa_getKey-public: errSecItemNotFound,1567564969.020113_N/A_ec_getKey-private: errSecItemNotFound,1567564969.004344_N/A_ec_getKey-public: errSecItemNotFound,1567564968.987933_N/A_rsa_getKey-private: errSecItemNotFound,1567564968.972001_N/A_rsa_getKey-public: errSecItemNotFound,1567564968.956097_N/A_ec_getKey-private: errSecItemNotFound,1567564968.941192_N/A_ec_getKey-public: errSecItemNotFound,1567564968.925067_N/A_rsa_getKey-private: errSecItemNotFound,1567564968.908969_N/A_rsa_getKey-public: errSecItemNotFound,1567564968.892596_N/A_ec_getKey-private: errSecItemNotFound,1567564968.878594_N/A_ec_getKey-public: errSecItemNotFound,1567564968.863664_N/A_rsa_getKey-private: errSecItemNotFound,1567564968.846399_N/A_rsa_getKey-public: errSecItemNotFound,1567564968.828430_N/A_ec_getKey-private: errSecItemNotFound,1567564968.803666_N/A_ec_getKey-public: errSecItemNotFound,1567564959.095852_N/A_rsaEncryptionEnabled_generateKeyPairSuccess,1567564958.714508_N/A_rsaEncryptionEnabled_getKey-private: errSecItemNotFound,1567564958.698773_N/A_rsaEncryptionEnabled_getKey-public: errSecItemNotFound,1567564958.683018_N/A_ecEncryptionEnabled_getKey-private: errSecItemNotFound,1567564958.667338_N/A_ecEncryptionEnabled_getKey-public: errSecItemNotFound,1567564958.651534_N/A_rsa_getKey-private: errSecItemNotFound,1567564958.635884_N/A_rsa_getKey-public: errSecItemNotFound,1567564958.621012_N/A_ec_getKey-private: errSecItemNotFound,1567564958.605474_N/A_ec_getKey-public: errSecItemNotFound,1567564958.589881_N/A_rsa_getKey-private: errSecItemNotFound,1567564958.574967_N/A_rsa_getKey-public: errSecItemNotFound,1567564958.559516_N/A_ec_getKey-private: errSecItemNotFound,1567564958.544513_N/A_ec_getKey-public: errSecItemNotFound,1567564958.523165_N/A_ecTarsusStdSigning_generateKeyPairSuccess,1567564958.449165_N/A_rsaTarsusStdSigning_getKey-private: errSecItemNotFound,1567564958.433954_N/A_rsaTarsusStdSigning_getKey-public: errSecItemNotFound,1567564958.418599_N/A_ecTarsusStdSigning_getKey-private: errSecItemNotFound,1567564958.403171_N/A_ecTarsusStdSigning_getKey-public: errSecItemNotFound,1567564958.387953_N/A_rsaTarsusStdSigning_getKey-private: errSecItemNotFound,1567564958.372669_N/A_rsaTarsusStdSigning_getKey-public: errSecItemNotFound,1567564958.357197_N/A_ecTarsusStdSigning_getKey-private: errSecItemNotFound,1567564958.341258_N/A_ecTarsusStdSigning_getKey-public: errSecItemNotFound",
					"tampered": true,
					"jailbroken": false,
					"screen_lock": true,
					"tz": "Asia/Shanghai",
					"application_state": "active",
					"has_hw_security": true,
					"sflags": -2,
					"hw_type": "iPhone",
					"device_name": "6247d99a046b3d76bb4ea712d0e0b9ae",
					"sim_operator_name": "中国移动",
					"connection": "wifi: 10.121.50.133",
					"device_id": "B092F4DD-C76B-497C-A947-BEC1FD7DE711",
					"os_version": "12.4",
					"sim_operator": "46000",
					"os_type": "iPhone",
					"device_model": "iPhone11,8"
				},
				"installed_packages": [],
				"capabilities": {
					"audio_acquisition_supported": true,
					"finger_print_supported": false,
					"image_acquisition_supported": true,
					"persistent_keys_supported": true,
					"face_id_key_bio_protection_supported": true,
					"fido_client_present": false,
					"dyadic_present": false,
					"installed_plugins": [],
					"host_provided_features": "19"
				},
				"collector_state": {
					"accounts": "active",
					"devicedetails": "active",
					"contacts": "disabled",
					"owner": "active",
					"software": "active",
					"location": "disabled",
					"bluetooth": "active",
					"externalsdkdetails": "active",
					"hwauthenticators": "active",
					"capabilities": "active",
					"fidoauthenticators": "disabled",
					"largedata": "disabled",
					"localenrollments": "active"
				},
				"local_enrollments": {}
			},
			"metadata": {
				"timestamp": 1567565151.881799
			}
		},
		"push_token": "88355333b6a661f84a641e22a311c777f046dd0bdc06d330342d2a56ba7ac5d1",
		"policy_request_id": "get8BitRandomNum",
		"params": {}
	}
}
```



response data:

```
{
	"error_code": 0,
	"error_message": "",
	"data": {
		"data": {
			"json_data": {
				"randomNum": 96902616
			}
		},
		"state": "completed",
		"application_data": {
			"pending_approvals": false
		},
		"assertions_complete": true,
		"token": "eyJraWQiOiJUUyIsImFsZyI6IkhTMjU2In0.eyJzdWIiOiJhbWhiMmcwNjgwXzEiLCJvcCI6ImF1dGgiLCJkc2lkIjoiZThlNGI2NzUtZTA3Mi00ZTgzLWE2YTAtMGM0MTA0ZmZiMGE5IiwiaXNzIjoiVFMiLCJwaWQiOiJnZXQ4Qml0UmFuZG9tTnVtIiwicGFyYW1zIjp7fSwic2lkIjoiMGExNDcxY2ItZmUyZS00NWYwLThhNzQtOTk0NmY5ZmYwYTc0IiwiYXVkIjoiaHNiY2JpemV4cHJlc3MiLCJwdmlkIjoiZGVmYXVsdF92ZXJzaW9uIiwiZXhwIjoxNTY3NTY3MDAxLCJpYXQiOjE1Njc1NjUyMDEsImp0aSI6ImYwMGE0NjFlLTBjZDgtNDQyMy1hMjQ4LTk5ZmFhYzkwN2FmNyIsImRpZCI6IjVlNDg2OGViLTcxMmMtNDdlOS05N2RhLTZmMjY0OTc3MThlMCJ9.JaX6zC6jjXneh0hKV_3SV8Qk2Va5dsORB-HgW55plrU"
	},
	"headers": [{
		"device_id": "5e4868eb-712c-47e9-97da-6f26497718e0",
		"type": "device_id"
	}, {
		"session_id": "e8e4b675-e072-4e83-a6a0-0c4104ffb0a9",
		"type": "session_id"
	}]
}
```


输入安保编码 (明文)


https://qualityassurance-amh-dbbsp-mauth-uat.p2g.netd2.hsbc.com.hk/api/v2/auth/assert?aid=hsbcbizexpress&did=5e4868eb-712c-47e9-97da-6f26497718e0&sid=e8e4b675-e072-4e83-a6a0-0c4104ffb0a9

request data:  

"otp": "96902616351936"

96902616 + 351936


```
{
	"headers": [{
		"type": "uid",
		"uid": "amhb2g0680_1"
	}],
	"data": {
		"action": "authentication",
		"assert": "authenticate",
		"assertion_id": "9hhGZwtZE3sySqHLQ7qSJZOv",
		"fch": "h10QJZtRQ7pYzCQ8TvxGYzCG",
		"data": {
			"otp": "96902616351936"
		},
		"method": "otp"
	}
}
```

response data : 

```
{
	"error_code": 0,
	"error_message": "",
	"data": {
		"data": {
			"json_data": {
				"next_policy": "Verify-Pin"
			}
		},
		"state": "completed",
		"application_data": {
			"pending_approvals": false
		},
		"assertions_complete": true,
		"token": "eyJraWQiOiJUUyIsImFsZyI6IkhTMjU2In0.eyJzdWIiOiJhbWhiMmcwNjgwXzEiLCJvcCI6ImF1dGgiLCJsdmwiOjUsImRzaWQiOiJlOGU0YjY3NS1lMDcyLTRlODMtYTZhMC0wYzQxMDRmZmIwYTkiLCJpc3MiOiJUUyIsInBpZCI6IlByb3Zpc2lvbmluZyIsInBhcmFtcyI6e30sInNpZCI6Ijc0YTFhOTM3LWMyMmItNGJjYi1hODg4LTMzNGNhNmY1OWE2MiIsImF1ZCI6ImhzYmNiaXpleHByZXNzIiwicHZpZCI6InYxLjAiLCJleHAiOjE1Njc1NjcxODYsImlhdCI6MTU2NzU2NTM4NiwianRpIjoiNjgzZWEyMDctNGMwYy00NmEzLWIwYWYtZTY3ODgyZjA3MmMyIiwiZGlkIjoiNWU0ODY4ZWItNzEyYy00N2U5LTk3ZGEtNmYyNjQ5NzcxOGUwIn0.1C-aAAXJtoxYqisuEcdnnt76RlVxxNeW4khW1vRVKro"
	},
	"headers": [{
		"device_id": "5e4868eb-712c-47e9-97da-6f26497718e0",
		"type": "device_id"
	}, {
		"session_id": "e8e4b675-e072-4e83-a6a0-0c4104ffb0a9",
		"type": "session_id"
	}]
}
```
## "policy_request_id": "DeactivateMobileAuth",
#### url: https://qualityassurance-amh-dbbsp-mauth-dev.p2g.netd2.hsbc.com.hk/api/v2/auth/login?aid=hsbcbizexpress&did=ef1bd86e-c665-4ae3-9fb7-60f64390bcdd&sid=421a197d-562d-417b-91ef-220489504b8a
request data:

```
{
	"headers": [{
		"type": "uid",
		"uid": "amhb2g0680_1"
	}],
	"data": {
		"collection_result": {
			"content": {
				"accounts": [],
				"device_details": {
					"logged_users": 1,
					"biometric_db_hash": "xV3afbxthxurAjWCUgkapb0G/qZgd9HML56VqonGK5M=",
					"keychain_err_logs": "1567507164.850686_N/A_ecTarsusStdSigning_generateKeyPairSuccess,1567507164.782426_N/A_rsaTarsusStdSigning_getKey-private: errSecItemNotFound,1567507164.767868_N/A_rsaTarsusStdSigning_getKey-public: errSecItemNotFound,1567507164.752952_N/A_ecTarsusStdSigning_getKey-private: errSecItemNotFound,1567507164.737359_N/A_ecTarsusStdSigning_getKey-public: errSecItemNotFound,1567507164.715158_N/A_rsaTarsusStdSigning_getKey-private: errSecItemNotFound,1567507164.696392_N/A_rsaTarsusStdSigning_getKey-public: errSecItemNotFound,1567507164.675526_N/A_ecTarsusStdSigning_getKey-private: errSecItemNotFound,1567507164.647965_N/A_ecTarsusStdSigning_getKey-public: errSecItemNotFound,1567507075.756598_N/A_rsaEncryptionEnabled_generateKeyPairSuccess,1567507075.578611_N/A_rsaEncryptionEnabled_getKey-private: errSecItemNotFound,1567507075.563218_N/A_rsaEncryptionEnabled_getKey-public: errSecItemNotFound,1567507075.547797_N/A_ecEncryptionEnabled_getKey-private: errSecItemNotFound,1567507075.532411_N/A_ecEncryptionEnabled_getKey-public: errSecItemNotFound,1567507075.516914_N/A_rsa_getKey-private: errSecItemNotFound,1567507075.501927_N/A_rsa_getKey-public: errSecItemNotFound,1567507075.486481_N/A_ec_getKey-private: errSecItemNotFound,1567507075.472153_N/A_ec_getKey-public: errSecItemNotFound,1567507075.446030_N/A_ec_getKey-private: errSecItemNotFound,1567507075.430366_N/A_ec_getKey-public: errSecItemNotFound,1567507075.408654_N/A_ecTarsusStdSigning_generateKeyPairSuccess,1567507075.338976_N/A_rsaTarsusStdSigning_getKey-private: errSecItemNotFound,1567507075.324020_N/A_rsaTarsusStdSigning_getKey-public: errSecItemNotFound,1567507075.309443_N/A_ecTarsusStdSigning_getKey-private: errSecItemNotFound,1567507075.292211_N/A_ecTarsusStdSigning_getKey-public: errSecItemNotFound",
					"tampered": true,
					"jailbroken": false,
					"screen_lock": true,
					"tz": "Asia/Shanghai",
					"application_state": "active",
					"has_hw_security": true,
					"sflags": -1,
					"hw_type": "iPhone",
					"device_name": "9b5011a11f19dcbef96afd66970bcef5",
					"sim_operator_name": "中国移动",
					"connection": "wifi: 10.121.50.204",
					"device_id": "C7AD870A-D3A6-4EED-8C51-8BC33CD78CCF",
					"os_version": "12.4",
					"sim_operator": "46000",
					"os_type": "iPhone",
					"device_model": "iPhone11,8"
				},
				"installed_packages": [],
				"capabilities": {
					"audio_acquisition_supported": true,
					"finger_print_supported": false,
					"image_acquisition_supported": true,
					"persistent_keys_supported": true,
					"face_id_key_bio_protection_supported": true,
					"fido_client_present": false,
					"dyadic_present": false,
					"installed_plugins": [],
					"host_provided_features": "19"
				},
				"collector_state": {
					"accounts": "active",
					"devicedetails": "active",
					"contacts": "disabled",
					"owner": "active",
					"software": "active",
					"location": "disabled",
					"bluetooth": "active",
					"externalsdkdetails": "active",
					"hwauthenticators": "active",
					"capabilities": "active",
					"fidoauthenticators": "disabled",
					"largedata": "disabled",
					"localenrollments": "active"
				},
				"local_enrollments": {
					"pin": {
						"registration_status": "registered",
						"validation_status": "validated"
					},
					"face_id": {
						"registration_status": "registered",
						"validation_status": "validated"
					}
				}
			},
			"metadata": {
				"timestamp": 1567581332.720454
			}
		},
		"push_token": "ee24051780631611df8b9ee69f48f8b38d1e7e9984efc4d02b72ef4894ec920b",
		"policy_request_id": "DeactivateMobileAuth",
		"params": {
			"deviceId": "ef1bd86e-c665-4ae3-9fb7-60f64390bcdd"
		}
	}
}
```

response data: 

```
{
	"error_code": 0,
	"error_message": "",
	"data": {
		"data": {
			"json_data": {
				"pin_registered": "false",
				"pin_transaction": "false"
			}
		},
		"state": "completed",
		"application_data": {
			"pending_approvals": true
		},
		"assertions_complete": true,
		"token": "eyJraWQiOiJUUyIsImFsZyI6IkhTMjU2In0.eyJzdWIiOiJhbWhiMmcwNjgwXzEiLCJvcCI6ImF1dGgiLCJkc2lkIjoiNDIxYTE5N2QtNTYyZC00MTdiLTkxZWYtMjIwNDg5NTA0YjhhIiwiaXNzIjoiVFMiLCJwaWQiOiJEZWFjdGl2YXRlTW9iaWxlQXV0aCIsInBhcmFtcyI6eyJkZXZpY2VJZCI6ImVmMWJkODZlLWM2NjUtNGFlMy05ZmI3LTYwZjY0MzkwYmNkZCJ9LCJzaWQiOiIxOGNmZWUwZi02ZDM3LTQxY2YtYmU2ZS0yNDI3MDQ1Yzg0MzMiLCJhdWQiOiJoc2JjYml6ZXhwcmVzcyIsInB2aWQiOiJkZWZhdWx0X3ZlcnNpb24iLCJleHAiOjE1Njc1ODM1NzgsImlhdCI6MTU2NzU4MTc3OCwianRpIjoiYmIxZmI4M2UtNjdiNi00YWUxLTg4NDQtZTRhMGU5ZDcwYzg3IiwiZGlkIjoiZWYxYmQ4NmUtYzY2NS00YWUzLTlmYjctNjBmNjQzOTBiY2RkIn0.WdWSiqFq9pZjBi62HkRGyzQsKjGTGvBqUlNxh4wOLPc"
	},
	"headers": [{
		"device_id": "ef1bd86e-c665-4ae3-9fb7-60f64390bcdd",
		"type": "device_id"
	}, {
		"session_id": "421a197d-562d-417b-91ef-220489504b8a",
		"type": "session_id"
	}]
}
```
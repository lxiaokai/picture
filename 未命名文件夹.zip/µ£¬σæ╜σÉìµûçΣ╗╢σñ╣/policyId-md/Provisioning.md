## "policy_request_id":"Provisioning", 
#### url: https://qualityassurance-amh-dbbsp-mauth-dev.p2g.netd2.hsbc.com.hk/api/v2/auth/login?aid=hsbcbizexpress&did=ef1bd86e-c665-4ae3-9fb7-60f64390bcdd&sid=6464112a-754f-4815-8827-3369702c2261

request data:

```
{
	"headers": [{
		"type": "uid",
		"uid": "amhb2g0680_1"
	}],
	"data": {
		"collection_result": {
			"content": {
				"accounts": [],
				"device_details": {
					"logged_users": 1,
					"biometric_db_hash": "xV3afbxthxurAjWCUgkapb0G/qZgd9HML56VqonGK5M=",
					"keychain_err_logs": "",
					"tampered": true,
					"jailbroken": false,
					"screen_lock": true,
					"tz": "Asia/Shanghai",
					"application_state": "active",
					"has_hw_security": true,
					"sflags": -1,
					"hw_type": "iPhone",
					"device_name": "6247d99a046b3d76bb4ea712d0e0b9ae",
					"sim_operator_name": "中国移动",
					"connection": "wifi: 10.121.49.142",
					"device_id": "C7AD870A-D3A6-4EED-8C51-8BC33CD78CCF",
					"os_version": "12.4",
					"sim_operator": "46000",
					"os_type": "iPhone",
					"device_model": "iPhone11,8"
				},
				"installed_packages": [],
				"capabilities": {
					"audio_acquisition_supported": true,
					"finger_print_supported": false,
					"image_acquisition_supported": true,
					"persistent_keys_supported": true,
					"face_id_key_bio_protection_supported": true,
					"fido_client_present": false,
					"dyadic_present": false,
					"installed_plugins": [],
					"host_provided_features": "19"
				},
				"collector_state": {
					"accounts": "active",
					"devicedetails": "active",
					"contacts": "disabled",
					"owner": "active",
					"software": "active",
					"location": "disabled",
					"bluetooth": "active",
					"externalsdkdetails": "active",
					"hwauthenticators": "active",
					"capabilities": "active",
					"fidoauthenticators": "disabled",
					"largedata": "disabled",
					"localenrollments": "active"
				},
				"local_enrollments": {}
			},
			"metadata": {
				"timestamp": 1567406590.2422252
			}
		},
		"policy_request_id": "Provisioning",
		"params": {}
	}
}
```

response data :

```
{
	"error_code": 0,
	"error_message": "",
	"data": {
		"data": {
			"otp_format": {
				"length": 6,
				"type": "numeric"
			},
			"otp_length": 6,
			"wrong_inputs_left": 999999999
		},
		"challenge": "+Wl15QKE4RBgBQOc4E0aEOf4",
		"state": "pending",
		"control_flow": [{
			"methods": [{
				"channels": [{
					"assertion_id": "hn2aSE3bJYU6YxU3NXeerdHD",
					"type": "none",
					"target": "none"
				}],
				"otp_format": {
					"length": 6,
					"type": "numeric"
				},
				"last_used": 1567407686873,
				"expired": false,
				"state": "validate",
				"locked": false,
				"assertion_id": "",
				"status": "registered",
				"type": "otp",
				"wrong_inputs_left": 999999999
			}],
			"options": {
				"update_default": true,
				"start_with": "default"
			},
			"assertion_id": "",
			"type": "authentication"
		}],
		"assertions_complete": false
	},
	"headers": [{
		"device_id": "ef1bd86e-c665-4ae3-9fb7-60f64390bcdd",
		"type": "device_id"
	}, {
		"session_id": "6464112a-754f-4815-8827-3369702c2261",
		"type": "session_id"
	}]
}
```

## policy_request_id: get8BitRandomNum
 
#### url: https://qualityassurance-amh-dbbsp-mauth-dev.p2g.netd2.hsbc.com.hk/api/v2/auth/login?aid=hsbcbizexpress&did=ef1bd86e-c665-4ae3-9fb7-60f64390bcdd&sid=6464112a-754f-4815-8827-3369702c2261


request data:

```
{
	"headers": [{
		"type": "uid",
		"uid": "amhb2g0680_1"
	}],
	"data": {
		"collection_result": {
			"content": {
				"accounts": [],
				"device_details": {
					"logged_users": 1,
					"biometric_db_hash": "xV3afbxthxurAjWCUgkapb0G/qZgd9HML56VqonGK5M=",
					"keychain_err_logs": "",
					"tampered": true,
					"jailbroken": false,
					"screen_lock": true,
					"tz": "Asia/Shanghai",
					"application_state": "active",
					"has_hw_security": true,
					"sflags": -1,
					"hw_type": "iPhone",
					"device_name": "6247d99a046b3d76bb4ea712d0e0b9ae",
					"sim_operator_name": "中国移动",
					"connection": "wifi: 10.121.49.142",
					"device_id": "C7AD870A-D3A6-4EED-8C51-8BC33CD78CCF",
					"os_version": "12.4",
					"sim_operator": "46000",
					"os_type": "iPhone",
					"device_model": "iPhone11,8"
				},
				"installed_packages": [],
				"capabilities": {
					"audio_acquisition_supported": true,
					"finger_print_supported": false,
					"image_acquisition_supported": true,
					"persistent_keys_supported": true,
					"face_id_key_bio_protection_supported": true,
					"fido_client_present": false,
					"dyadic_present": false,
					"installed_plugins": [],
					"host_provided_features": "19"
				},
				"collector_state": {
					"accounts": "active",
					"devicedetails": "active",
					"contacts": "disabled",
					"owner": "active",
					"software": "active",
					"location": "disabled",
					"bluetooth": "active",
					"externalsdkdetails": "active",
					"hwauthenticators": "active",
					"capabilities": "active",
					"fidoauthenticators": "disabled",
					"largedata": "disabled",
					"localenrollments": "active"
				},
				"local_enrollments": {}
			},
			"metadata": {
				"timestamp": 1567406590.2422252
			}
		},
		"policy_request_id": "get8BitRandomNum",
		"params": {}
	}
}
```


response data: 

```
{
	"error_code": 0,
	"error_message": "",
	"data": {
		"data": {
			"json_data": {
				"randomNum": 45463321
			}
		},
		"state": "completed",
		"application_data": {
			"pending_approvals": false
		},
		"assertions_complete": true,
		"token": "eyJraWQiOiJUUyIsImFsZyI6IkhTMjU2In0.eyJzdWIiOiJhbWhiMmcwNjgwXzEiLCJvcCI6ImF1dGgiLCJkc2lkIjoiNjQ2NDExMmEtNzU0Zi00ODE1LTg4MjctMzM2OTcwMmMyMjYxIiwiaXNzIjoiVFMiLCJwaWQiOiJnZXQ4Qml0UmFuZG9tTnVtIiwicGFyYW1zIjp7fSwic2lkIjoiZTRiNmYwOTQtMjJlYy00NzI4LWFmOTMtY2U2YTUwZmYyMmE5IiwiYXVkIjoiaHNiY2JpemV4cHJlc3MiLCJwdmlkIjoiZGVmYXVsdF92ZXJzaW9uIiwiZXhwIjoxNTY3NDA5NDEzLCJpYXQiOjE1Njc0MDc2MTMsImp0aSI6IjQ4NDY3Nzk3LTFjOWMtNGIwZi05OTVkLWFhYTVkMzZhOTg0NiIsImRpZCI6ImVmMWJkODZlLWM2NjUtNGFlMy05ZmI3LTYwZjY0MzkwYmNkZCJ9.SCRkE0fOtsXxc15TIlmfZXmR8K--A5rKOSdTtbiTGGc"
	},
	"headers": [{
		"device_id": "ef1bd86e-c665-4ae3-9fb7-60f64390bcdd",
		"type": "device_id"
	}, {
		"session_id": "6464112a-754f-4815-8827-3369702c2261",
		"type": "session_id"
	}]
}
```
## policy_request_id": "TDS-Mobile",
#### url: https://qualityassurance-amh-dbbsp-mauth-dev.p2g.netd2.hsbc.com.hk/api/v2/auth/login?aid=hsbcbizexpress&did=ef1bd86e-c665-4ae3-9fb7-60f64390bcdd

request data:

```
{
	"headers": [{
		"type": "uid",
		"uid": "amhb2g0680_1"
	}],
	"data": {
		"collection_result": {
			"content": {
				"accounts": [],
				"device_details": {
					"logged_users": 1,
					"biometric_db_hash": "xV3afbxthxurAjWCUgkapb0G/qZgd9HML56VqonGK5M=",
					"keychain_err_logs": "1567407959.038186_N/A_ecTarsusStdSigning_generateKeyPairSuccess,1567407958.966880_N/A_rsaTarsusStdSigning_getKey-private: errSecItemNotFound,1567407958.951733_N/A_rsaTarsusStdSigning_getKey-public: errSecItemNotFound,1567407958.936158_N/A_ecTarsusStdSigning_getKey-private: errSecItemNotFound,1567407958.920415_N/A_ecTarsusStdSigning_getKey-public: errSecItemNotFound,1567407958.898178_N/A_rsaTarsusStdSigning_getKey-private: errSecItemNotFound,1567407958.881655_N/A_rsaTarsusStdSigning_getKey-public: errSecItemNotFound,1567407958.861803_N/A_ecTarsusStdSigning_getKey-private: errSecItemNotFound,1567407958.833784_N/A_ecTarsusStdSigning_getKey-public: errSecItemNotFound,1567407039.384998_N/A_rsaEncryptionEnabled_generateKeyPairSuccess,1567407039.165152_N/A_rsaEncryptionEnabled_getKey-private: errSecItemNotFound,1567407039.150557_N/A_rsaEncryptionEnabled_getKey-public: errSecItemNotFound,1567407039.135234_N/A_ecEncryptionEnabled_getKey-private: errSecItemNotFound,1567407039.119747_N/A_ecEncryptionEnabled_getKey-public: errSecItemNotFound,1567407039.104459_N/A_rsa_getKey-private: errSecItemNotFound,1567407039.088987_N/A_rsa_getKey-public: errSecItemNotFound,1567407039.073372_N/A_ec_getKey-private: errSecItemNotFound,1567407039.057421_N/A_ec_getKey-public: errSecItemNotFound,1567407039.030648_N/A_ec_getKey-private: errSecItemNotFound,1567407039.015415_N/A_ec_getKey-public: errSecItemNotFound,1567407038.995681_N/A_ecTarsusStdSigning_generateKeyPairSuccess,1567407038.927117_N/A_rsaTarsusStdSigning_getKey-private: errSecItemNotFound,1567407038.911870_N/A_rsaTarsusStdSigning_getKey-public: errSecItemNotFound,1567407038.896433_N/A_ecTarsusStdSigning_getKey-private: errSecItemNotFound,1567407038.880395_N/A_ecTarsusStdSigning_getKey-public: errSecItemNotFound",
					"tampered": true,
					"jailbroken": false,
					"screen_lock": true,
					"tz": "Asia/Shanghai",
					"application_state": "active",
					"has_hw_security": true,
					"sflags": -1,
					"hw_type": "iPhone",
					"device_name": "6247d99a046b3d76bb4ea712d0e0b9ae",
					"sim_operator_name": "中国移动",
					"connection": "wifi: 10.121.49.142",
					"device_id": "C7AD870A-D3A6-4EED-8C51-8BC33CD78CCF",
					"os_version": "12.4",
					"sim_operator": "46000",
					"os_type": "iPhone",
					"device_model": "iPhone11,8"
				},
				"installed_packages": [],
				"capabilities": {
					"audio_acquisition_supported": true,
					"finger_print_supported": false,
					"image_acquisition_supported": true,
					"persistent_keys_supported": true,
					"face_id_key_bio_protection_supported": true,
					"fido_client_present": false,
					"dyadic_present": false,
					"installed_plugins": [],
					"host_provided_features": "19"
				},
				"collector_state": {
					"accounts": "active",
					"devicedetails": "active",
					"contacts": "disabled",
					"owner": "active",
					"software": "active",
					"location": "disabled",
					"bluetooth": "active",
					"externalsdkdetails": "active",
					"hwauthenticators": "active",
					"capabilities": "active",
					"fidoauthenticators": "disabled",
					"largedata": "disabled",
					"localenrollments": "active"
				},
				"local_enrollments": {
					"pin": {
						"registration_status": "registered",
						"validation_status": "validated"
					},
					"face_id": {
						"registration_status": "registered",
						"validation_status": "validated"
					}
				}
			},
			"metadata": {
				"timestamp": 1567409324.461769
			}
		},
		"push_token": "e45e5e70b885e2e7d421d9b43bfa7b4ae74e320c6c9c0eee98e3240d986438bb",
		"policy_request_id": "TDS-Mobile",
		"params": {
			"amount": "10100",
			"creditAccount": "123456789",
			"language": "SimplifiedChinese",
			"debitAccount": "e1072176ef7959ee69d3754a28137352"
		}
	}
}
```

response data:

```
{
	"error_code": 0,
	"error_message": "",
	"data": {
		"data": null,
		"challenge": "ccgHbg2187GeZPOEpqEIGoPX",
		"state": "pending",
		"control_flow": [{
			"methods": [{
				"last_used": 1567408491013,
				"expired": false,
				"retries_left": 5,
				"locked": false,
				"registered_at": 1567407807718,
				"assertion_id": "aSEPZELTrnufKzR2Gyzm0LXL",
				"status": "registered",
				"length": 6,
				"type": "pin"
			}, {
				"last_used": 1565175502792,
				"assertion_id": "U9+yA9sb1VtG22WHM7Br0NoJ",
				"status": "unregistered",
				"type": "fingerprint"
			}, {
				"last_used": 1567409270623,
				"expired": false,
				"locked": false,
				"registered_at": 1567407962735,
				"assertion_id": "zUxlHxiyA07pUtWwJu33P0L+",
				"status": "registered",
				"type": "face_id"
			}],
			"options": {
				"start_in_menu": true,
				"update_default": true,
				"start_with": "menu"
			},
			"assertion_id": "",
			"type": "authentication"
		}],
		"assertions_complete": false
	},
	"headers": [{
		"device_id": "ef1bd86e-c665-4ae3-9fb7-60f64390bcdd",
		"type": "device_id"
	}, {
		"session_id": "9556812a-93bd-450c-a152-4aff2a9a234f",
		"type": "session_id"
	}]
}
```
## "policy_request_id": "Verify-Old-Pin", 
#### url: https://qualityassurance-amh-dbbsp-mauth-dev.p2g.netd2.hsbc.com.hk/api/v2/auth/login?aid=hsbcbizexpress&did=ef1bd86e-c665-4ae3-9fb7-60f64390bcdd&sid=1ead4b28-34ab-4cf5-962c-128938b8087f

request data:

```
{
	"headers": [{
		"type": "uid",
		"uid": "amhb2g0680_1"
	}],
	"data": {
		"collection_result": {
			"content": {
				"accounts": [],
				"device_details": {
					"logged_users": 1,
					"biometric_db_hash": "xV3afbxthxurAjWCUgkapb0G/qZgd9HML56VqonGK5M=",
					"keychain_err_logs": "1567507164.850686_N/A_ecTarsusStdSigning_generateKeyPairSuccess,1567507164.782426_N/A_rsaTarsusStdSigning_getKey-private: errSecItemNotFound,1567507164.767868_N/A_rsaTarsusStdSigning_getKey-public: errSecItemNotFound,1567507164.752952_N/A_ecTarsusStdSigning_getKey-private: errSecItemNotFound,1567507164.737359_N/A_ecTarsusStdSigning_getKey-public: errSecItemNotFound,1567507164.715158_N/A_rsaTarsusStdSigning_getKey-private: errSecItemNotFound,1567507164.696392_N/A_rsaTarsusStdSigning_getKey-public: errSecItemNotFound,1567507164.675526_N/A_ecTarsusStdSigning_getKey-private: errSecItemNotFound,1567507164.647965_N/A_ecTarsusStdSigning_getKey-public: errSecItemNotFound,1567507075.756598_N/A_rsaEncryptionEnabled_generateKeyPairSuccess,1567507075.578611_N/A_rsaEncryptionEnabled_getKey-private: errSecItemNotFound,1567507075.563218_N/A_rsaEncryptionEnabled_getKey-public: errSecItemNotFound,1567507075.547797_N/A_ecEncryptionEnabled_getKey-private: errSecItemNotFound,1567507075.532411_N/A_ecEncryptionEnabled_getKey-public: errSecItemNotFound,1567507075.516914_N/A_rsa_getKey-private: errSecItemNotFound,1567507075.501927_N/A_rsa_getKey-public: errSecItemNotFound,1567507075.486481_N/A_ec_getKey-private: errSecItemNotFound,1567507075.472153_N/A_ec_getKey-public: errSecItemNotFound,1567507075.446030_N/A_ec_getKey-private: errSecItemNotFound,1567507075.430366_N/A_ec_getKey-public: errSecItemNotFound,1567507075.408654_N/A_ecTarsusStdSigning_generateKeyPairSuccess,1567507075.338976_N/A_rsaTarsusStdSigning_getKey-private: errSecItemNotFound,1567507075.324020_N/A_rsaTarsusStdSigning_getKey-public: errSecItemNotFound,1567507075.309443_N/A_ecTarsusStdSigning_getKey-private: errSecItemNotFound,1567507075.292211_N/A_ecTarsusStdSigning_getKey-public: errSecItemNotFound",
					"tampered": true,
					"jailbroken": false,
					"screen_lock": true,
					"tz": "Asia/Shanghai",
					"application_state": "active",
					"has_hw_security": true,
					"sflags": -1,
					"hw_type": "iPhone",
					"device_name": "9b5011a11f19dcbef96afd66970bcef5",
					"sim_operator_name": "中国移动",
					"connection": "wifi: 10.121.50.204",
					"device_id": "C7AD870A-D3A6-4EED-8C51-8BC33CD78CCF",
					"os_version": "12.4",
					"sim_operator": "46000",
					"os_type": "iPhone",
					"device_model": "iPhone11,8"
				},
				"installed_packages": [],
				"capabilities": {
					"audio_acquisition_supported": true,
					"finger_print_supported": false,
					"image_acquisition_supported": true,
					"persistent_keys_supported": true,
					"face_id_key_bio_protection_supported": true,
					"fido_client_present": false,
					"dyadic_present": false,
					"installed_plugins": [],
					"host_provided_features": "19"
				},
				"collector_state": {
					"accounts": "active",
					"devicedetails": "active",
					"contacts": "disabled",
					"owner": "active",
					"software": "active",
					"location": "disabled",
					"bluetooth": "active",
					"externalsdkdetails": "active",
					"hwauthenticators": "active",
					"capabilities": "active",
					"fidoauthenticators": "disabled",
					"largedata": "disabled",
					"localenrollments": "active"
				},
				"local_enrollments": {
					"pin": {
						"registration_status": "registered",
						"validation_status": "validated"
					},
					"face_id": {
						"registration_status": "registered",
						"validation_status": "validated"
					}
				}
			},
			"metadata": {
				"timestamp": 1567581332.720454
			}
		},
		"push_token": "ee24051780631611df8b9ee69f48f8b38d1e7e9984efc4d02b72ef4894ec920b",
		"policy_request_id": "Verify-Old-Pin",
		"params": {}
	}
}
```

response data: 

```
{
	"error_code": 0,
	"error_message": "",
	"data": {
		"data": null,
		"challenge": "RY6si/iBNzAsFgWKhRwUuAd2",
		"state": "pending",
		"control_flow": [{
			"methods": [{
				"last_used": 1567408491013,
				"expired": false,
				"retries_left": 5,
				"locked": false,
				"registered_at": 1567507150364,
				"assertion_id": "sg+h0PbaSuO7UwmHCPUohXf6",
				"status": "registered",
				"length": 6,
				"type": "pin"
			}],
			"options": {
				"update_default": true,
				"start_with": "default"
			},
			"assertion_id": "",
			"type": "authentication"
		}],
		"assertions_complete": false
	},
	"headers": [{
		"device_id": "ef1bd86e-c665-4ae3-9fb7-60f64390bcdd",
		"type": "device_id"
	}, {
		"session_id": "1ead4b28-34ab-4cf5-962c-128938b8087f",
		"type": "session_id"
	}]
}
```
```
{
	"headers": [{
		"type": "uid",
		"uid": "amhb2g0680_1"
	}],
	"data": {
		"collection_result": {
			"content": {
				"accounts": [],
				"device_details": {
					"logged_users": 1,
					"biometric_db_hash": "Zxg9VOw4Eg3m0bbChDbOW9mrbksGvoHIbOossjP+fGk=",
					"keychain_err_logs": "1567503550.376678_N/A_ecTarsusStdSigning_generateKeyPairSuccess,1567503550.306389_N/A_rsaTarsusStdSigning_getKey-private: errSecItemNotFound,1567503550.289781_N/A_rsaTarsusStdSigning_getKey-public: errSecItemNotFound,1567503550.273054_N/A_ecTarsusStdSigning_getKey-private: errSecItemNotFound,1567503550.256204_N/A_ecTarsusStdSigning_getKey-public: errSecItemNotFound,1567503550.233583_N/A_rsaTarsusStdSigning_getKey-private: errSecItemNotFound,1567503550.216494_N/A_rsaTarsusStdSigning_getKey-public: errSecItemNotFound,1567503550.199422_N/A_ecTarsusStdSigning_getKey-private: errSecItemNotFound,1567503550.181645_N/A_ecTarsusStdSigning_getKey-public: errSecItemNotFound,1567503440.912402_N/A_ecTarsusStdSigning_generateKeyPairSuccess,1567503440.837991_N/A_rsaTarsusStdSigning_getKey-private: errSecItemNotFound,1567503440.820991_N/A_rsaTarsusStdSigning_getKey-public: errSecItemNotFound,1567503440.803765_N/A_ecTarsusStdSigning_getKey-private: errSecItemNotFound,1567503440.786594_N/A_ecTarsusStdSigning_getKey-public: errSecItemNotFound,1567503440.763418_N/A_rsaTarsusStdSigning_getKey-private: errSecItemNotFound,1567503440.747089_N/A_rsaTarsusStdSigning_getKey-public: errSecItemNotFound,1567503440.730639_N/A_ecTarsusStdSigning_getKey-private: errSecItemNotFound,1567503440.713592_N/A_ecTarsusStdSigning_getKey-public: errSecItemNotFound,1567503185.001596_N/A_ecTarsusStdSigning_generateKeyPairSuccess,1567503184.928101_N/A_rsaTarsusStdSigning_getKey-private: errSecItemNotFound,1567503184.911905_N/A_rsaTarsusStdSigning_getKey-public: errSecItemNotFound,1567503184.895206_N/A_ecTarsusStdSigning_getKey-private: errSecItemNotFound,1567503184.877878_N/A_ecTarsusStdSigning_getKey-public: errSecItemNotFound,1567503184.854571_N/A_rsaTarsusStdSigning_getKey-private: errSecItemNotFound,1567503184.837072_N/A_rsaTarsusStdSigning_getKey-public: errSecItemNotFound,1567503184.817170_N/A_ecTarsusStdSigning_getKey-private: errSecItemNotFound,1567503184.792426_N/A_ecTarsusStdSigning_getKey-public: errSecItemNotFound,1567502899.602242_N/A_rsaEncryptionEnabled_generateKeyPairSuccess,1567502899.453773_N/A_rsaEncryptionEnabled_getKey-private: errSecItemNotFound,1567502899.436879_N/A_rsaEncryptionEnabled_getKey-public: errSecItemNotFound,1567502899.419958_N/A_ecEncryptionEnabled_getKey-private: errSecItemNotFound,1567502899.402848_N/A_ecEncryptionEnabled_getKey-public: errSecItemNotFound,1567502899.386060_N/A_rsa_getKey-private: errSecItemNotFound,1567502899.369700_N/A_rsa_getKey-public: errSecItemNotFound,1567502899.353085_N/A_ec_getKey-private: errSecItemNotFound,1567502899.336233_N/A_ec_getKey-public: errSecItemNotFound,1567502899.319158_N/A_rsa_getKey-private: errSecItemNotFound,1567502899.302215_N/A_rsa_getKey-public: errSecItemNotFound,1567502899.285154_N/A_ec_getKey-private: errSecItemNotFound,1567502899.267721_N/A_ec_getKey-public: errSecItemNotFound,1567502899.242844_N/A_ecTarsusStdSigning_generateKeyPairSuccess,1567502899.169693_N/A_rsaTarsusStdSigning_getKey-private: errSecItemNotFound,1567502899.153309_N/A_rsaTarsusStdSigning_getKey-public: errSecItemNotFound,1567502899.136463_N/A_ecTarsusStdSigning_getKey-private: errSecItemNotFound,1567502899.119598_N/A_ecTarsusStdSigning_getKey-public: errSecItemNotFound,1567502899.102617_N/A_rsaTarsusStdSigning_getKey-private: errSecItemNotFound,1567502899.084618_N/A_rsaTarsusStdSigning_getKey-public: errSecItemNotFound,1567502899.064079_N/A_ecTarsusStdSigning_getKey-private: errSecItemNotFound,1567502899.036803_N/A_ecTarsusStdSigning_getKey-public: errSecItemNotFound,1567502826.323443_N/A_rsa_getKey-private: errSecItemNotFound,1567502826.306178_N/A_rsa_getKey-public: errSecItemNotFound,1567502826.289939_N/A_ec_getKey-private: errSecItemNotFound,1567502826.272318_N/A_ec_getKey-public: errSecItemNotFound,1567502826.245704_N/A_ec_getKey-private: errSecItemNotFound,1567502826.228664_N/A_ec_getKey-public: errSecItemNotFound,1567502826.207232_N/A_ec_getKey-private: errSecItemNotFound,1567502826.190659_N/A_ec_getKey-public: errSecItemNotFound,1567502826.174182_N/A_rsa_getKey-private: errSecItemNotFound,1567502826.157132_N/A_rsa_getKey-public: errSecItemNotFound,1567502826.139438_N/A_ec_getKey-private: errSecItemNotFound,1567502826.124188_N/A_ec_getKey-public: errSecItemNotFound,1567502826.107716_N/A_rsa_getKey-private: errSecItemNotFound,1567502826.090907_N/A_rsa_getKey-public: errSecItemNotFound,1567502826.073897_N/A_ec_getKey-private: errSecItemNotFound,1567502826.057042_N/A_ec_getKey-public: errSecItemNotFound,1567502826.038638_N/A_rsa_getKey-private: errSecItemNotFound,1567502826.021196_N/A_rsa_getKey-public: errSecItemNotFound,1567502826.003825_N/A_ec_getKey-private: errSecItemNotFound,1567502825.984335_N/A_ec_getKey-public: errSecItemNotFound,1567502825.967070_N/A_rsa_getKey-private: errSecItemNotFound,1567502825.949624_N/A_rsa_getKey-public: errSecItemNotFound,1567502825.932011_N/A_ec_getKey-private: errSecItemNotFound,1567502825.914455_N/A_ec_getKey-public: errSecItemNotFound,1567502825.896907_N/A_rsa_getKey-private: errSecItemNotFound,1567502825.879086_N/A_rsa_getKey-public: errSecItemNotFound,1567502825.862409_N/A_ec_getKey-private: errSecItemNotFound,1567502825.842811_N/A_ec_getKey-public: errSecItemNotFound,1567500634.378909_N/A_ecTarsusStdSigning_generateKeyPairSuccess,1567500634.295867_N/A_rsaTarsusStdSigning_getKey-private: errSecItemNotFound,1567500634.279515_N/A_rsaTarsusStdSigning_getKey-public: errSecItemNotFound,1567500634.262842_N/A_ecTarsusStdSigning_getKey-private: errSecItemNotFound,1567500634.246130_N/A_ecTarsusStdSigning_getKey-public: errSecItemNotFound,1567500634.222630_N/A_rsaTarsusStdSigning_getKey-private: errSecItemNotFound,1567500634.204415_N/A_rsaTarsusStdSigning_getKey-public: errSecItemNotFound,1567500634.182310_N/A_ecTarsusStdSigning_getKey-private: errSecItemNotFound,1567500634.150299_N/A_ecTarsusStdSigning_getKey-public: errSecItemNotFound,1567500511.713002_N/A_rsaEncryptionEnabled_generateKeyPairSuccess,1567500511.308687_N/A_rsaEncryptionEnabled_getKey-private: errSecItemNotFound,1567500511.291265_N/A_rsaEncryptionEnabled_getKey-public: errSecItemNotFound,1567500511.274107_N/A_ecEncryptionEnabled_getKey-private: errSecItemNotFound,1567500511.257133_N/A_ecEncryptionEnabled_getKey-public: errSecItemNotFound,1567500511.240674_N/A_rsa_getKey-private: errSecItemNotFound,1567500511.224204_N/A_rsa_getKey-public: errSecItemNotFound,1567500511.206917_N/A_ec_getKey-private: errSecItemNotFound,1567500511.189501_N/A_ec_getKey-public: errSecItemNotFound,1567500511.173147_N/A_rsa_getKey-private: errSecItemNotFound,1567500511.152987_N/A_rsa_getKey-public: errSecItemNotFound,1567500511.136886_N/A_ec_getKey-private: errSecItemNotFound,1567500511.121363_N/A_ec_getKey-public: errSecItemNotFound,1567500511.097859_N/A_ecTarsusStdSigning_generateKeyPairSuccess",
					"tampered": true,
					"jailbroken": false,
					"screen_lock": true,
					"tz": "Asia/Shanghai",
					"application_state": "active",
					"has_hw_security": true,
					"sflags": -2,
					"hw_type": "iPhone",
					"device_name": "6247d99a046b3d76bb4ea712d0e0b9ae",
					"sim_operator_name": "中国移动",
					"connection": "wifi: 10.121.50.82",
					"device_id": "148836C6-4338-4F63-BA8A-44BD1F18A964",
					"os_version": "12.4",
					"sim_operator": "46000",
					"os_type": "iPhone",
					"device_model": "iPhone11,8"
				},
				"installed_packages": [],
				"capabilities": {
					"audio_acquisition_supported": true,
					"finger_print_supported": false,
					"image_acquisition_supported": true,
					"persistent_keys_supported": true,
					"face_id_key_bio_protection_supported": true,
					"fido_client_present": false,
					"dyadic_present": false,
					"installed_plugins": [],
					"host_provided_features": "19"
				},
				"collector_state": {
					"accounts": "active",
					"devicedetails": "active",
					"contacts": "disabled",
					"owner": "active",
					"software": "active",
					"location": "disabled",
					"bluetooth": "active",
					"externalsdkdetails": "active",
					"hwauthenticators": "active",
					"capabilities": "active",
					"fidoauthenticators": "disabled",
					"largedata": "disabled",
					"localenrollments": "active"
				},
				"local_enrollments": {
					"pin": {
						"registration_status": "registered",
						"validation_status": "validated"
					},
					"face_id": {
						"registration_status": "registered",
						"validation_status": "validated"
					}
				}
			},
			"metadata": {
				"timestamp": 1567503555.774281
			}
		},
		"push_token": "32c18331c3839941942bfc9c5f7342faae141dce4ea2970eb235ac537575d226",
		"policy_request_id": "DeviceIsRegister",
		"params": {}
	}
}
```

```json
{
	"error_code": 0,
	"error_message": "",
	"data": {
		"data": {
			"json_data": {
				"isInProvisioned": "true"
			}
		},
		"state": "completed",
		"application_data": {
			"pending_approvals": false
		},
		"assertions_complete": true,
		"token": "eyJraWQiOiJUUyIsImFsZyI6IkhTMjU2In0.eyJzdWIiOiJhbWhiMmcwNjgwXzEiLCJvcCI6ImF1dGgiLCJkc2lkIjoiNjM4ZjI1MjQtMGIzMi00NWMyLTlhNjAtNmQ0NzJkNzk0ZTI0IiwiaXNzIjoiVFMiLCJwaWQiOiJEZXZpY2VJc1JlZ2lzdGVyIiwicGFyYW1zIjp7fSwic2lkIjoiMDg1ZmY0MDItNGJiNi00NzE2LTllZGMtYjk3MDkwYzEzODdjIiwiYXVkIjoiaHNiY2JpemV4cHJlc3MiLCJwdmlkIjoiZGVmYXVsdF92ZXJzaW9uIiwiZXhwIjoxNTY3NTA1NDEzLCJpYXQiOjE1Njc1MDM2MTMsImp0aSI6ImJmOWM1ZDhmLTg3NjMtNGQwZi04NjczLTMwYTFkNjUxZjY1NCIsImRpZCI6IjljMTEyZWJkLTZkNzItNGNiYi05MTY0LTQyMGEzMzkzZDg0NSJ9.5g6bVN6GT4YWGJnIzAU3fBaCzAslYeZKLuT0ieq0Tvw"
	},
	"headers": [{
		"device_id": "9c112ebd-6d72-4cbb-9164-420a3393d845",
		"type": "device_id"
	}, {
		"session_id": "638f2524-0b32-45c2-9a60-6d472d794e24",
		"type": "session_id"
	}]
}
```
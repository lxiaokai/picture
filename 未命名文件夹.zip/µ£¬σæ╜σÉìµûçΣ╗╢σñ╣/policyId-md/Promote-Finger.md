## "policy_request_id": "Promote-Finger",
#### url: https://qualityassurance-amh-dbbsp-mauth-dev.p2g.netd2.hsbc.com.hk/api/v2/auth/login?aid=hsbcbizexpress&did=ef1bd86e-c665-4ae3-9fb7-60f64390bcdd&sid=6464112a-754f-4815-8827-3369702c2261

request data:

```
{
	"headers": [{
		"type": "uid",
		"uid": "amhb2g0680_1"
	}],
	"data": {
		"collection_result": {
			"content": {
				"accounts": [],
				"device_details": {
					"logged_users": 1,
					"biometric_db_hash": "xV3afbxthxurAjWCUgkapb0G/qZgd9HML56VqonGK5M=",
					"keychain_err_logs": "1567407039.384998_N/A_rsaEncryptionEnabled_generateKeyPairSuccess,1567407039.165152_N/A_rsaEncryptionEnabled_getKey-private: errSecItemNotFound,1567407039.150557_N/A_rsaEncryptionEnabled_getKey-public: errSecItemNotFound,1567407039.135234_N/A_ecEncryptionEnabled_getKey-private: errSecItemNotFound,1567407039.119747_N/A_ecEncryptionEnabled_getKey-public: errSecItemNotFound,1567407039.104459_N/A_rsa_getKey-private: errSecItemNotFound,1567407039.088987_N/A_rsa_getKey-public: errSecItemNotFound,1567407039.073372_N/A_ec_getKey-private: errSecItemNotFound,1567407039.057421_N/A_ec_getKey-public: errSecItemNotFound,1567407039.030648_N/A_ec_getKey-private: errSecItemNotFound,1567407039.015415_N/A_ec_getKey-public: errSecItemNotFound,1567407038.995681_N/A_ecTarsusStdSigning_generateKeyPairSuccess,1567407038.927117_N/A_rsaTarsusStdSigning_getKey-private: errSecItemNotFound,1567407038.911870_N/A_rsaTarsusStdSigning_getKey-public: errSecItemNotFound,1567407038.896433_N/A_ecTarsusStdSigning_getKey-private: errSecItemNotFound,1567407038.880395_N/A_ecTarsusStdSigning_getKey-public: errSecItemNotFound",
					"tampered": true,
					"jailbroken": false,
					"screen_lock": true,
					"tz": "Asia/Shanghai",
					"application_state": "active",
					"has_hw_security": true,
					"sflags": -1,
					"hw_type": "iPhone",
					"device_name": "6247d99a046b3d76bb4ea712d0e0b9ae",
					"sim_operator_name": "中国移动",
					"connection": "wifi: 10.121.49.142",
					"device_id": "C7AD870A-D3A6-4EED-8C51-8BC33CD78CCF",
					"os_version": "12.4",
					"sim_operator": "46000",
					"os_type": "iPhone",
					"device_model": "iPhone11,8"
				},
				"installed_packages": [],
				"capabilities": {
					"audio_acquisition_supported": true,
					"finger_print_supported": false,
					"image_acquisition_supported": true,
					"persistent_keys_supported": true,
					"face_id_key_bio_protection_supported": true,
					"fido_client_present": false,
					"dyadic_present": false,
					"installed_plugins": [],
					"host_provided_features": "19"
				},
				"collector_state": {
					"accounts": "active",
					"devicedetails": "active",
					"contacts": "disabled",
					"owner": "active",
					"software": "active",
					"location": "disabled",
					"bluetooth": "active",
					"externalsdkdetails": "active",
					"hwauthenticators": "active",
					"capabilities": "active",
					"fidoauthenticators": "disabled",
					"largedata": "disabled",
					"localenrollments": "active"
				},
				"local_enrollments": {
					"pin": {
						"registration_status": "registered",
						"validation_status": "validated"
					}
				}
			},
			"metadata": {
				"timestamp": 1567407894.0403
			}
		},
		"push_token": "e45e5e70b885e2e7d421d9b43bfa7b4ae74e320c6c9c0eee98e3240d986438bb",
		"policy_request_id": "Promote-Finger",
		"params": {}
	}
}
```
response data: 

```
{
	"error_code": 0,
	"error_message": "",
	"data": {
		"data": null,
		"challenge": "G3vc23zwW5nVHXuH6tSbL+C8",
		"state": "pending",
		"control_flow": [{
			"assertion_id": "km2Uy2JnWsyfqCKpA5oGRFqe",
			"assertions": [{
				"method": "fingerprint",
				"last_used": 1565175502792,
				"silent": false,
				"assertion_id": "3UIU4GT7gQUW9vXITdDcA2Em",
				"status": "unregistered"
			}, {
				"method": "face_id",
				"last_used": 1565175502791,
				"silent": false,
				"assertion_id": "lm7BX6hH0R89TIcZYPnY+IYI",
				"status": "unregistered"
			}],
			"type": "registration"
		}],
		"assertions_complete": false
	},
	"headers": [{
		"device_id": "ef1bd86e-c665-4ae3-9fb7-60f64390bcdd",
		"type": "device_id"
	}, {
		"session_id": "6464112a-754f-4815-8827-3369702c2261",
		"type": "session_id"
	}]
}

```


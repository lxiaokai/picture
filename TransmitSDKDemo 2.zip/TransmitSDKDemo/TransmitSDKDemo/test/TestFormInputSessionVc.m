//
//  TestFormInputSessionVc.m
//  TSXMSampleApp
//
//  Created by Eldan Ben Haim on 01/04/2018.
//  Copyright © 2018 Transmit Security. All rights reserved.
//

#import "TestFormInputSessionVc.h"
#import "OneViewController.h"

@interface TestFormInputSessionVc ()

@property (weak, nonatomic) IBOutlet UILabel *formId;
@property (weak, nonatomic) IBOutlet UITextView *formPayload;
@property (weak, nonatomic) IBOutlet UITextView *formInput;
@property (weak, nonatomic) IBOutlet UILabel *promptBar;

@end

@implementation TestFormInputSessionVc

- (void)viewDidLoad {
    [super viewDidLoad];
    
    if (self.navigationController) {
        self.navigationController.navigationBar.translucent = NO;
        self.navigationController.navigationBar.tintColor = [UIColor blackColor];
        self.navigationController.navigationBar.backgroundColor = [UIColor colorWithRed:80.0 / 255.0 green:113.0 / 255.0 blue:155.0 / 255.0 alpha: 1];
        [self.navigationController setNavigationBarHidden:NO];
        self.navigationItem.title = @"Form Action";
        self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Submit"
                                                                                  style:UIBarButtonItemStyleDone
                                                                                 target:self
                                                                                 action:@selector(onSubmitButtonClicked:)];
        self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Cancel"
                                                                                 style:UIBarButtonItemStyleDone
                                                                                target:self
                                                                                action:@selector(onCancelButtonClicked:)];
    }
    

    self.promptBar.hidden = YES;

    self.formPayload.layer.borderColor = [[UIColor darkGrayColor] CGColor];
    self.formPayload.layer.borderWidth = 1.0;
    
    self.formInput.layer.borderColor = [[UIColor darkGrayColor] CGColor];
    self.formInput.layer.borderWidth = 1.0;
    
    [self initFormFields];
    
}

-(void)initFormFields {
    NSError *err = nil;
    NSData *payloadJson = [NSJSONSerialization dataWithJSONObject:_currentPayload
                                    options:NSJSONWritingPrettyPrinted
                                      error:&err];
    if(err) {
        self.formPayload.text = [err description];
    } else {
        self.formPayload.text = [[NSString alloc] initWithData:payloadJson
                                                      encoding:NSUTF8StringEncoding];
    }
    // self.formPayload.text = @"我是谁";
    self.formId.text = _formIdentifier;

}

-(void)showFormError:(NSString*)errorMessage {
    [UIView transitionWithView:self.promptBar
                          duration:0.25f
                           options:UIViewAnimationOptionTransitionCrossDissolve
                        animations:^{
                            self.promptBar.text = errorMessage;
                            self.promptBar.textColor = [UIColor redColor];
                            self.promptBar.hidden = NO;
                        } completion:nil];
}

-(void)showFormContinuePrompt:(NSString*)continuePrompt {
    [UIView transitionWithView:self.promptBar
                      duration:0.25f
                       options:UIViewAnimationOptionTransitionCrossDissolve
                    animations:^{
                        self.promptBar.text = continuePrompt;
                        self.promptBar.textColor = [UIColor blueColor];
                        self.promptBar.hidden = NO;
                    } completion:nil];
}

-(void)onSubmitButtonClicked:(id)sender {
    
//    OneViewController *vc = [[OneViewController alloc] init];
//    vc.delegate = self.testFormInputSession;
//    [self.navigationController pushViewController:vc animated:YES];
//    //[self presentViewController:vc animated:YES completion:nil];
//    return;

    NSData *jsonTextAsData = [self.formInput.text dataUsingEncoding:NSUTF8StringEncoding];
    NSError *jsonParseError= nil;
    NSDictionary *inputJson = [NSJSONSerialization JSONObjectWithData:jsonTextAsData
                                                              options:0
                                                                error:&jsonParseError];
    
    if(jsonParseError) {
        [self showFormError:[jsonParseError description]];
    } else {
        [self.delegate receiveFormInput:inputJson];
    }
}

-(void)onCancelButtonClicked:(id)sender {
    [self.delegate cancelFormInput];
}

@end

//
//  TestFormInputSession.m
//  TransmitSDK3Static
//
//  Created by Eldan Ben Haim on 01/04/2018.
//  Copyright © 2018 TransmitSecurity. All rights reserved.
//

#import "TestFormInputSession.h"
#import "TestFormInputSessionVc.h"
#import "LKAutoMessageDialog.h"

@interface TestFormInputSession ()  <FormInputSessionVcDelegate> {
    TSXDefaultUIHandlerHostingContext *_hostingContext;
    TestFormInputSessionVc *_vc;
    
    void (^_currentInputHandler)(TSXFormInput* _Nonnull);
}

@end

@implementation TestFormInputSession

-(instancetype)initWithFormId:(NSString *)formId payload:(NSDictionary *)payload {
    self = [super init];
    
    _vc = [[TestFormInputSessionVc alloc] initWithNibName:nil
                                               bundle:nil];
    _vc.delegate = self;
    _vc.testFormInputSession = self;
    
    _vc.formIdentifier = formId;
    _vc.currentPayload = payload;
    
    return self;
}

-(void)startSessionWithClientContext:(NSDictionary * _Nullable)clientContext actionContext:(TSXPolicyAction* _Nullable)actionContext {
    _hostingContext = [TSXDefaultUIHandler hostingContextFromClientContext:clientContext];
//     [_hostingContext presentViewController:_vc animated:YES];
    [_hostingContext.hostingViewController.navigationController pushViewController:_vc animated:YES];
    //UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:_vc];
    //[_hostingContext pushViewController:nav animated:YES];
//    [_hostingContext presentDialogViewController:_vc];
}

-(void)endSession {
    [_hostingContext dismissViewControllerAnimated:YES];
    _vc = nil;
}

-(void)onContinueWithPayload:(NSDictionary * _Nullable)payload {
    _vc.currentPayload = payload;
    [_vc showFormContinuePrompt:@"Continue input; consult payload"];
}

-(void)onErrorWithPayload:(NSDictionary * _Nullable)payload {
    _vc.currentPayload = payload;
    [_vc showFormError:@"Form error; consult payload"];
}

-(void)promiseFormInputAsynchronouslyWithHandler:(void (^ _Nonnull)(TSXFormInput* _Nonnull))handler  {
    _currentInputHandler = handler;
}

-(void)receiveFormInput:(NSDictionary*)formInput {
    _currentInputHandler([TSXFormInput createFormInputSubmissionRequestWithJsonData:formInput]);
}

-(void)cancelFormInput {
    _currentInputHandler([TSXFormInput createFormCancellationRequest]);
}

@end

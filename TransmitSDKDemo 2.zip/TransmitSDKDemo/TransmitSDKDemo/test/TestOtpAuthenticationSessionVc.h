//
//  TestOtpAuthenticationSessionVc.h
//  NoUIApp
//
//  Created by Eldan Ben Haim on 11/09/2017.
//  Copyright © 2017 Eran Berkovitz. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TestOtpAuthenticationSession.h"

@interface TestOtpAuthenticationSessionVc : UIViewController

@property (weak) TestOtpAuthenticationSession *session;

-(void)setupForOtpTarget:(TSXOtpTarget*)target format:(TSXOtpFormat*)format;

-(void)setErrorPrompt:(NSString*)prompt;
-(void)selectTarget;
@end

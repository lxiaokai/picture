//
//  TestOtpAuthenticationSession.m
//  NoUIApp
//
//  Created by Eldan Ben Haim on 11/09/2017.
//  Copyright © 2017 Eran Berkovitz. All rights reserved.
//
#import <Foundation/Foundation.h>
#import "TestOtpAuthenticationSession.h"
#import "TestOtpAuthenticationSessionVc.h"

@interface TestOtpAuthenticationSession () {

    TSXDefaultUIHandlerHostingContext *_hostingContext;
    TestOtpAuthenticationSessionVc *_viewController;

    void (^_currentHandlerForVc)(TSXInputOrControlResponse<TSXOtpInput*> *);
    
    NSArray<TSXOtpTarget*>* _targets;
    TSXOtpTarget *_target;
}

@end



@implementation TestOtpAuthenticationSession

-(instancetype)initWithTargets:(NSArray<TSXOtpTarget*>*)targets
                selectedTarget:(TSXOtpTarget*)selectedTarget {
    self = [super init];
    if(self) {
        _targets = targets;
        _target = selectedTarget;
        
        TestOtpAuthenticationSessionVc *vc = [[TestOtpAuthenticationSessionVc alloc] initWithNibName:nil bundle:nil];
        vc.session = self;
        
        _viewController = vc;
        [_viewController loadViewIfNeeded];
        [_viewController setupForOtpTarget:selectedTarget format:nil];
    }
    
    return self;
}

-(NSArray<TSXOtpTarget*>*) targets {
    return _targets;
}

-(void)setAvailableTargets:(NSArray *)targets {
    _targets = targets;
}

-(void)startSessionWithDescription:(TSXAuthenticatorDescription* _Nonnull)description mode:(TSXAuthenticatorSessionMode)mode actionContext:(TSXPolicyAction* _Nullable)actionContext clientContext:(NSDictionary * _Nullable)clientContext {
    _hostingContext = [TSXDefaultUIHandler hostingContextFromClientContext:clientContext];
    [_hostingContext presentViewController:_viewController animated:YES];
}

-(void)endSession {
    if(_viewController) {
        [_hostingContext dismissViewControllerAnimated:YES];
        _viewController = nil;
        _targets = nil;
    }
}

-(void)changeSessionModeWithNewMode:(TSXAuthenticatorSessionMode)newMode {
    
}

-(void)promiseRecoveryForErrorWithError:(TSXAuthenticationError *)error validRecoveries:(TSXAuthenticationErrorRecoverySet)validRecoveries defaultRecovery:(TSXAuthenticationErrorRecovery)defaultRecovery asynchronouslyWithHandler:(void (^)(TSXAuthenticationErrorRecovery))handler {
    [_viewController setErrorPrompt:[error description]];
    handler(AuthenticationErrorRecoveryRetryAuthenticator);
}

-(void)promiseInputAsynchronouslyWithHandler:(void (^ _Nonnull)(TSXInputOrControlResponse<TSXOtpInput*>* _Nonnull))handler
{
    _currentHandlerForVc = handler;
    
    if(!_target) {
        [_viewController selectTarget];
    }
}

-(void)setGeneratedOtpWithFormat:(TSXOtpFormat *)format target:(TSXOtpTarget *)target {
    _target = target;
    [_viewController setupForOtpTarget:target format:format];
}

-(void)userSubmittedOtp:(NSString*)otp {
    if(_currentHandlerForVc) {
        _currentHandlerForVc([TSXInputOrControlResponse createInputResponseWithInputResponse:[TSXTargetBasedAuthenticatorInput createAuthenticatorInputWithAuthenticatorInput:[TSXOtpInputOtpSubmission createOtpSubmissionWithOtp:otp]]]);
    }
}

-(void)resendOtpRequested {
    if(_currentHandlerForVc) {
        _currentHandlerForVc([TSXInputOrControlResponse createInputResponseWithInputResponse:[TSXTargetBasedAuthenticatorInput createAuthenticatorInputWithAuthenticatorInput:[TSXOtpInputRequestResend createOtpResendRequest]]]);
    }
}

-(void)userSelectedTarget:(TSXOtpTarget*)target {
    if(_currentHandlerForVc) {
        _currentHandlerForVc([TSXInputOrControlResponse createInputResponseWithInputResponse:[TSXTargetBasedAuthenticatorInput createTargetSelectionRequestWithTarget:target]]);
    }
}

-(void)cancelAuthenticator {
    _currentHandlerForVc([TSXInputOrControlResponse
                     createControlResponseWithControlRequest:[TSXControlRequest
                                                              createWithRequestType:ControlRequestTypeCancelAuthenticator]]);
}

-(void)changeSessionModeToRegistrationAfterExpiration {
    
}
@end

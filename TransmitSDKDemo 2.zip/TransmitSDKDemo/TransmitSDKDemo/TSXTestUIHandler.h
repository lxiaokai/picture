//
//  TSXTestUIHandler.h
//  TransmitSDKDemo
//
//  Created by Alex on 2019/11/20.
//  Copyright © 2019 alex. All rights reserved.
//

#import <TransmitSDKUILayer/TransmitSDKUILayer.h>

NS_ASSUME_NONNULL_BEGIN

@interface TSXTestUIHandler : TSXDefaultUIHandler
@property (nonatomic,strong) NSString *tsPassword;
@end

NS_ASSUME_NONNULL_END

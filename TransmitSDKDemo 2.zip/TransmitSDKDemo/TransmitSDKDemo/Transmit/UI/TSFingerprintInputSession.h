//
//  TSFingerprintInputSession.h
//  HSBCHybrid
//
//  Created by [Manuel L M Zhang] on 07/12/2017.
//  Copyright © 2017 HSBC. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <TransmitSDK3/TransmitSDK3.h>

@interface TSFingerprintInputSession : TSXUIAuthenticatorSession<TSXFingerprintInput*>

@property (copy, nonatomic) void (^currentHandler)(TSXInputOrControlResponse<TSXFingerprintInput*> *);

@property (nonatomic,strong) NSString *tsPrompt;

@end

//
//  TSPinInputSession.h
//  HSBCHybrid
//
//  Created by [Manuel L M Zhang] on 07/12/2017.
//  Copyright © 2017 HSBC. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <TransmitSDK3/TransmitSDKXm.h>

//#import <TransmitSDK3/TSXUIDefaultUIHandler.h>
#import <TransmitSDKUILayer/TSXDefaultUIHandler.h>
//#import <TransmitSDK3/TSXUIDefaultUIHandlerHostingContext.h>
#import <TransmitSDKUILayer/TSXDefaultUIHandlerHostingContext.h>

@interface TSPinInputSession : TSXUIAuthenticatorSession<TSXPinInput *>{
    
}

@property (strong, nonatomic) void (^currentHandler)(TSXInputOrControlResponse<TSXPinInput*> *);

@property (nonatomic,strong) NSString *tsPin;
@property (nonatomic,strong) TSXAuthenticatorDescription *tsPinDescription;

@end

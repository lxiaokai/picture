//
//  TSCustomTransportProvider.h
//  HSBCHybrid
//
//  Created by [Manuel L M Zhang] on 3/27/18.
//

#import <TransmitSDK3/TransmitSDK3.h>

@interface TSCustomTransportProvider : TSXTransportProvider

-(void)sendRequestWithRequest:(TSXTransportRequest* _Nonnull)request asynchronouslyWithHandler:(void (^ _Nonnull)(TSXTransportResponse* _Nonnull, TSXAuthenticationError* _Nullable))handler;

@end

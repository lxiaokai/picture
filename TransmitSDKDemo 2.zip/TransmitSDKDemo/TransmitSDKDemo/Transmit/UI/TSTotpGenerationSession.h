//
//  TSTotpGenerationSession.h
//  HSBCHybrid
//
//  Created by lyd on 2018/7/4.
//

#import <TransmitSDK3/TransmitSDK3.h>

@protocol TSTotpGenerationSessionDelegate <NSObject>

- (void)TSTotpGenerationSssionSetCode:(NSString *)code ttlSeconds:(long)ttlSeconds remainingSeconds:(long)remainingSeconds isEnd:(BOOL)end;

@end

@interface TSTotpGenerationSession : TSXUITotpGenerationSession

@property (nonatomic, weak) id <TSTotpGenerationSessionDelegate> delegate;

@end

//
//  TSCustomTransportProvider.m
//  HSBCHybrid
//
//  Created by [Manuel L M Zhang] on 3/27/18.
//

#import "TSCustomTransportProvider.h"

@implementation TSCustomTransportProvider

-(void)sendRequestWithRequest:(TSXTransportRequest* _Nonnull)request asynchronouslyWithHandler:(void (^ _Nonnull)(TSXTransportResponse* _Nonnull tsResponse, TSXAuthenticationError* _Nullable tsAuthErr))handler{
    
    TSXTransportResponse *tsTransportResponse = [[TSXTransportResponse alloc] init];
    TSXAuthenticationError *tsAuthenticationError = [[TSXAuthenticationError alloc] init];
    
    if([tsAuthenticationError errorCode]!=AuthenticationErrorCodeInvalidInput){
        [tsTransportResponse setStatus:200];
        [tsTransportResponse setMethod:@"POST"];
        [tsTransportResponse setBodyJson:request.bodyJson];
    }
    
    handler(tsTransportResponse,tsAuthenticationError);
    
}

@end

//
//  TSPlacehoderFaceIdSession.h
//  HSBCHybrid
//
//  Created by lyd on 2018/6/25.
//

#import <TransmitSDK3/TransmitSDK3.h>

@protocol TSPlacehoderFaceIdSessionDelegate <NSObject>

- (void)getFaceIdContextData:(NSString *)contextData andCurrentHandler:(void (^)(TSXInputOrControlResponse *))currentHandler;

@end

@interface TSPlacehoderFaceIdSession : TSXUIAuthenticatorSession <TSXPlaceholderInputResponse *>

@property (copy, nonatomic) void (^currentHandler)(TSXInputOrControlResponse *);

@property (nonatomic,weak) id<TSPlacehoderFaceIdSessionDelegate> delegate;

@property (copy, nonatomic) NSString *userName;

@property (copy, nonatomic) NSString *serverPayload;

@end

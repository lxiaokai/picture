//
//  TSNativeFaceInputSession.h
//  HSBCHybrid
//
//  Created by [Manuel L M Zhang] on 07/12/2017.
//  Copyright © 2017 HSBC. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <TransmitSDK3/TransmitSDK3.h>

@interface TSNativeFaceInputSession : TSXUIAuthenticatorSession<TSXNativeFaceInput*>

@property (copy, nonatomic) void (^currentHandler)(TSXInputOrControlResponse<TSXNativeFaceInput*> *);

@property (nonatomic,copy) NSString *tsPrompt;

@end


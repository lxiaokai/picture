//
//  TSOtpSession.m
//  HSBCHybrid
//
//  Created by Janice on 2018/1/25.
//
//

#import "TSOtpSession.h"

#import "TransmitHelper.h"

@implementation TSOtpSession
@synthesize tsOtp;

-(void)startSessionWithDescription:(TSXAuthenticatorDescription *)description mode:(TSXAuthenticatorSessionMode)mode actionContext:(TSXPolicyAction *)actionContext clientContext:(NSDictionary *)clientContext {
    
    
}

-(void)promiseInputAsynchronouslyWithHandler:(void (^)(TSXInputOrControlResponse *))handler {
    self.currentHandler = handler;
    
    //Transmit: add by Manuel on 20180326 with updated api of the sdk (start)
    if(self.selectedTarget==nil){
        self.currentHandler([TSXInputOrControlResponse createInputResponseWithInputResponse:[TSXTargetBasedAuthenticatorInput createTargetSelectionRequestWithTarget:self.possibleTargets[0]]]);
    }else {
        self.currentHandler([TSXInputOrControlResponse createInputResponseWithInputResponse:[TSXTargetBasedAuthenticatorInput createAuthenticatorInputWithAuthenticatorInput:[TSXOtpInputOtpSubmission createOtpSubmissionWithOtp:tsOtp]]]);
    }
    //Transmit: add by Manuel on 20180326 with updated api of the sdk (stop)
}

-(void)endSession {
    
}

//Transmit: add by Manuel on 20180212 to handle the error case exceptional flow
-(void)promiseRecoveryForErrorWithError:(TSXAuthenticationError *)error validRecoveries:(TSXAuthenticationErrorRecoverySet)validRecoveries defaultRecovery:(TSXAuthenticationErrorRecovery)defaultRecovery asynchronouslyWithHandler:(void (^)(TSXAuthenticationErrorRecovery))handler {
    //handler(defaultRecovery);
    handler(AuthenticationErrorRecoveryFail);
}


-(void)setGeneratedOtpWithFormat:(TSXOtpFormat *)format target:(TSXOtpTarget *)target{
    self.selectedTarget = target;
}

-(void)changeSessionModeToRegistrationAfterExpiration {
    
}

@end

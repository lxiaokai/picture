//
//  TSDeviceManagementSession.h
//  HSBCHybrid
//
//  Created by [Manuel L M Zhang] on 20180425.
//

#import <TransmitSDK3/TransmitSDK3.h>

@protocol TSDeviceManagementSessionDelegate <NSObject>

- (void)transmitHandleDeviceManagementWithType:(NSString *)type error:(TSXAuthenticationError *)error;

- (void)transmitHandleDeviceDeactivateNotFound;

@end

@interface TSDeviceManagementSession : TSXUIDeviceManagementSession

@property (nonatomic, weak) id<TSDeviceManagementSessionDelegate> delegate;

@end

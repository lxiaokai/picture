//
//  TSTotpGenerationSession.m
//  HSBCHybrid
//
//  Created by lyd on 2018/7/4.
//

#import "TSTotpGenerationSession.h"

@interface TSTotpGenerationSession ()

@property (nonatomic, copy) NSString *startTotpCode;

@property (nonatomic, copy) NSString *currentTotpCode;

@property (nonatomic, strong) NSTimer *timer;

@property (nonatomic, assign) long totalSecond;

@property (nonatomic, assign) long statrSecond;

@property (nonatomic, assign) long currentSecond;

@property (nonatomic, strong) TSXTotpGenerationSessionServices *totpGenerationSessionServices;

@end

@implementation TSTotpGenerationSession

- (void)startSessionWithTotpGenerationSessionServices:(TSXTotpGenerationSessionServices *)totpGenerationSessionServices actionContext:(TSXPolicyAction *)actionContext clientContext:(NSDictionary *)clientContext
{
	self.totalSecond = 0;
	
	self.statrSecond = 0;
	
	self.currentSecond = 0;
	
	self.startTotpCode = nil;
	
	self.totpGenerationSessionServices = totpGenerationSessionServices;
	
	[totpGenerationSessionServices startCodeGeneration];
}

-(void)promiseChallengeInputAsynchronouslyWithHandler:(void (^ _Nonnull)(TSXInputOrControlResponse<TSXTotpChallengeInput*>* _Nonnull))handler
{
	//	handler([TSXInputOrControlResponse createInputResponseWithInputResponse:[TSXTotpChallengeInput createWithChallenge:@"wrong"]]);
}

- (void)setTotpCodeWithCode:(NSString *)code ttlSeconds:(long)ttlSeconds remainingSeconds:(long)remainingSeconds
{
	if (self.startTotpCode == nil) {
		
		self.startTotpCode = code;
	}
	
	self.currentTotpCode = code;
	
	self.totalSecond = ttlSeconds;
	
	if (self.statrSecond == 0) {
		
		self.statrSecond = remainingSeconds;
	}
	
	BOOL isEnd = NO;
	
	if (self.statrSecond >= 15 && remainingSeconds == 0)
	{
		
		isEnd = YES;
	}
	
	if ([code isEqualToString:self.startTotpCode] == NO && remainingSeconds == 0)
	{
		
		isEnd = YES;
	}
	
	if ([self.delegate respondsToSelector:@selector(TSTotpGenerationSssionSetCode:ttlSeconds:remainingSeconds:isEnd:)])
	{
		if (isEnd == YES) {
			
			[self.totpGenerationSessionServices finishSession];
			
		}
		
		[self.delegate TSTotpGenerationSssionSetCode:code ttlSeconds:ttlSeconds remainingSeconds:remainingSeconds isEnd:isEnd];
	}
}

- (void)endSession
{
	
}

@end

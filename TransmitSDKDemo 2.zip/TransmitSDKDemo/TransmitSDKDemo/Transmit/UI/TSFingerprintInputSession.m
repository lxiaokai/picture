//
//  TSFingerprintInputSession.m
//  HSBCHybrid
//
//  Created by [Manuel L M Zhang] on 07/12/2017.
//  Copyright © 2017 HSBC. All rights reserved.
//

#import "TSFingerprintInputSession.h"

@implementation TSFingerprintInputSession

@synthesize tsPrompt;

-(void)startSessionWithDescription:(TSXAuthenticatorDescription* _Nonnull)description mode:(TSXAuthenticatorSessionMode)mode actionContext:(TSXPolicyAction* _Nullable)actionContext clientContext:(NSDictionary * _Nullable)clientContext {
    
    NSLog(@"%d",description.locked);
    
}

-(void)promiseInputAsynchronouslyWithHandler:(void (^)(TSXInputOrControlResponse *))handler {
    
    self.currentHandler = handler;
    
    self.currentHandler([TSXInputOrControlResponse createInputResponseWithInputResponse:[TSXFingerprintInput createWithPrompt:tsPrompt]]);
    
}

//Transmit: add by Manuel on 20180212 to handle the error case exceptional flow
-(void)promiseRecoveryForErrorWithError:(TSXAuthenticationError *)error validRecoveries:(TSXAuthenticationErrorRecoverySet)validRecoveries defaultRecovery:(TSXAuthenticationErrorRecovery)defaultRecovery asynchronouslyWithHandler:(void (^)(TSXAuthenticationErrorRecovery))handler {
    
    //handler(defaultRecovery);
    handler(AuthenticationErrorRecoveryFail);
}

-(void)changeSessionModeWithNewMode:(TSXAuthenticatorSessionMode)newMode {
    
}

-(void)changeSessionModeToRegistrationAfterExpiration {
    
}

-(void)endSession {
    
}

@end

//
//  TSOtpSession.h
//  HSBCHybrid
//
//  Created by Janice on 2018/1/25.
//
//

#import <UIKit/UIKit.h>
#import <TransmitSDK3/TransmitSDK3.h>

//#import <TransmitSDK3/TSXUIDefaultUIHandler.h>
#import <TransmitSDKUILayer/TSXDefaultUIHandler.h>
//#import <TransmitSDK3/TSXUIDefaultUIHandlerHostingContext.h>
#import <TransmitSDKUILayer/TSXDefaultUIHandlerHostingContext.h>


@interface TSOtpSession : TSXUIAuthenticatorSessionOtp


@property (strong, nonatomic) void (^currentHandler)(TSXInputOrControlResponse<TSXOtpInput*> *);
@property (strong, nonatomic) NSArray<TSXOtpTarget *> *possibleTargets;
@property (strong, nonatomic) TSXOtpTarget *autoExecedTarget;
@property (strong, nonatomic) TSXOtpTarget *selectedTarget;
//Transmit: add by Manuel on 20180326 with updated api of the sdk
@property (strong, nonatomic) NSArray<TSXOtpTarget *> *availableTargets;
@property (nonatomic,strong) NSString *tsOtp;

@end

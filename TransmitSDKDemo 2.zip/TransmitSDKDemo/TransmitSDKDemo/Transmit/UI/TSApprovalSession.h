//
//  TSApprovalSession.h
//  HSBCHybrid
//
//  Created by [Manuel L M Zhang] on 07/12/2017.
//  Copyright © 2017 HSBC. All rights reserved.
//

#import <TransmitSDK3/TransmitSDK3.h>
#import <TransmitSDK3/TransmitSDKXm.h>

@protocol TSApprovalSessionDelegate <NSObject>

- (void)TSApprovalSessionCheckLockedStatus:(NSString *)status withService:(TSXApprovalManagementSessionServices *)approvalService withApproval:(TSXManagedMobileApproval *)managedMobileApproval;
- (void)TSApprovalSessionCheckExpiredFlag:(NSString *)expiredFlag withService:(TSXApprovalManagementSessionServices *)approvalService withApproval:(TSXManagedMobileApproval*)managedMobileApproval;
- (void)TSApprovalSessionWithType:(NSString *)type error:(TSXAuthenticationError *)error;
- (void)handleApprovalErrorWithFunctionType:(NSString *)type error:(TSXAuthenticationError *)error;

@end

@interface TSApprovalSession : TSXUIApprovalsSession <TSApprovalSessionDelegate>

@property (nonatomic,weak)   id<TSApprovalSessionDelegate> delegate;
@property (strong, nonatomic) TSXManagedMobileApproval *tsManagedMobileApproval;
@property (nonatomic,strong) NSString *expiredFlag;

@end

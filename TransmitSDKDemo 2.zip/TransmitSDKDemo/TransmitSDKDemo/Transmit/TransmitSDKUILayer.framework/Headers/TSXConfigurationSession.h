//
//  TSXConfigurationSession.h
//  TSXDemo
//
//  Created by Sletean Inbar on 19/06/2018.
//  Copyright © 2018 Transmit Security LTD. All rights reserved.
//
#import "SDK3.h"

@interface TSXConfigurationSession : TSXUIAuthenticationConfigurationSession

@end

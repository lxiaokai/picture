//
//  TOTPGenerationSession.h
//  TSXDemo
//
//  Created by Sletean Inbar on 20/08/2018.
//  Copyright © 2018 Transmit Security LTD. All rights reserved.
//
#import "SDK3.h"

@interface TSXTOTPGenerationSession : TSXUITotpGenerationSession

@end

//
//  TSXPresentorsProtocol.h
//  TransmitSDKUILayer
//
//  Created by Transmit Security on 12/02/2019.
//  Copyright © 2019 Transmit Security LTD. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SDK3.h"

NS_ASSUME_NONNULL_BEGIN

typedef void (^Completion) (NSDictionary* _Nullable data, TSXAuthenticationError* _Nullable error);
@protocol TSXGeneralPresentorProtocol;


/*! \protocol TSXGeneralSessionProtocol TSXPresentorsProtocol.h
 *  \brief Base UI session protocol
 *
 * Base UI session protocol that provides policy action context and client context
 * objects to presentors.
 *
 * @implementation provided by SDK
 */
#pragma mark - Session Protocols
#pragma mark General Session (SDK)
@protocol TSXGeneralSessionProtocol

/**
 * Provides information on the currently executed action in a policy. This class is provided by the SDK to the client
 * on callback invocations to allow the client to access information about the action during its execution.
 */
@property (nonatomic, readonly, nullable) TSXPolicyAction *actionContext;

/**
 The clientContext for the SDK operation invocation for which this callback is invoked.
 */
@property (nonatomic, readonly, nullable) NSDictionary *clientContext;
@end

#pragma mark Authenticator Session (SDK)

/*! \protocol TSXGeneralAuthenticatorSessionProtocol TSXPresentorsProtocol.h
 *  \brief Base authentication UI session protocol
 *
 * Base authentication UI session protocol that provides authenticator description object
 * and authenticator session mode.
 *
 * @implementation provided by SDK
 */
@protocol TSXGeneralAuthenticatorSessionProtocol <TSXGeneralSessionProtocol>

/**
 * Describes an authenticator. This includes general description
 * of the authenticator and its status.
 */
@property (nonatomic, readonly) TSXAuthenticatorDescription *authDescription;

/**
 *
 * Authenticator UI session modes.
 */
@property (nonatomic, readonly) TSXAuthenticatorSessionMode currentMode;
@end

#pragma mark - Abstract Base Protocols
#pragma mark Base Presentor (Application)

/*! \protocol TSXBasePresentorProtocol TSXPresentorsProtocol.h
 *  \brief Base presentor protocol.
 *
 * Base for all presentor protocols.
 */
@protocol TSXBasePresentorProtocol <NSObject>
@end

#pragma mark General Session Presentor Delegate (SDK)

/*! \protocol TSXGeneralPresentorDelegate TSXPresentorsProtocol.h
 *  \brief General presentor delegate protocol
 *
 * General presentor delegate protocol that provides common
 * properties and methods for non-authentication sessions and control flow actions.
 *
 * @implementation provided by SDK
 */
@protocol TSXGeneralPresentorDelegate <NSObject>

/**
 Cancel the current non-authentication session or control flow action.
 */
-(void)provideCancel;
@end

#pragma mark - General Session Presentor (Application)
/*! \protocol TSXGeneralPresentorProtocol TSXPresentorsProtocol.h
 *  \brief General UI session presentor protocol
 *
 * General UI session presentor protocol for non-authentication sessions and control flow actions.
 *
 * @implementation should be provided by application developer
 */
@protocol TSXGeneralPresentorProtocol<TSXBasePresentorProtocol>

/**
 Informs the presentor that the session has started.
 
 @param session General session object.
 */
-(void)startSession:(id<TSXGeneralSessionProtocol>)session;

/**
 Informs the presentor that the session has ended.
 */
-(void)endSession;
@end


#pragma mark - Authentication General Session Presentor Delegate (SDK)

/*! \protocol TSXGeneralAuthenticationPresentorDelegate TSXPresentorsProtocol.h
 *  \brief Authentication UI session presentor delegate protocol
 *
 * Authentication UI session presentor delegate protocol that provides common
 * properties and methods for authentication UI sessions.
 *
 * @implementation provided by SDK
 */
@protocol TSXGeneralAuthenticationPresentorDelegate <TSXGeneralPresentorDelegate>

/**
 Handle authentication input or control response.
 
 @param input Authentication input or control response object.
 */
-(void)provideInput:(TSXInputOrControlResponse *)input;

/**
 Handle error with set of valid recovery options, return response asynchronously to the
 provided handler.
 Use to call customized implementation of TSXErrorRecoveryPresentorProtocol through SDK
 rather than directly from the current customized Presentor.
 
 @param error Error object contains the error code, error message and additional data.
 @param validRecoveries The Recoveries options that allow to invoke them.
 @param handler The handler of the select option.
 */
-(void)showDefaultUIRecoveryForError:(nonnull TSXAuthenticationError *)error validRecoveries:(TSXAuthenticationErrorRecoverySet)validRecoveries asynchronouslyWithHandler:(nonnull void (^)(TSXAuthenticationErrorRecovery))handler;
@end

#pragma mark - Authentication General Session Presentor (Application)

/*! \protocol TSXAuthenticationPresentorProtocol TSXPresentorsProtocol.h
 *  \brief General authentication UI session presentor protocol
 *
 * General authentication UI session presentor protocol for handling single Authenticator.
 *
 * @implementation should be provided by application developer
 */
@protocol TSXAuthenticationPresentorProtocol<TSXBasePresentorProtocol>


/**
 Informs the presentor that the authentication session has started.
 
 @param session General authentication UI session object
 */
-(void)startSession:(id<TSXGeneralAuthenticatorSessionProtocol>)session;

/**
 Informs the presentor that the authentication session has ended.
 */
-(void)endSession;

/**
 Informs the presentor that the session mode has changed to registration after expiration.
 */
-(void)changeSessionModeToRegistrationAfterExpiration;



/**
 Informs the presentor that the authentication session is ready for input.
 */
-(void)promiseInputRetry;

/**
 Handle error with set of valid recovery options, return response asynchronously to the
 provided handler.
 
 @param error Error object contains the error code, error message and additional data.
 @param validRecoveries The Recoveries options that allow to invoke them.
 @param handler The handler of the select option.
 */
-(void)handleRecoveryOptionsForError:(TSXAuthenticationError *)error validRecoveries:(TSXAuthenticationErrorRecoverySet)validRecoveries asynchronouslyWithHandler:(void (^)(TSXAuthenticationErrorRecovery))handler;

/**
 Handle authentication error.
 
 @param error Error object.
 */
-(void)retryAuthenticationAfterInputError:(TSXAuthenticationError * _Nullable)error;

/**
 General authentication UI session delegate object.
 */
@property (weak, nonatomic) id<TSXGeneralAuthenticationPresentorDelegate> authenticatorDelegate;
@end

#pragma mark - MultiStepAuthentication General Session Presentor (Application)

/*! \protocol TSXMultiStepAuthenticationPresentorProtocol TSXPresentorsProtocol.h
 *  \brief Multistep authentication UI session protocol
 *
 * Multistep authentication UI session protocols for handling single multistep authenticators.
 *
 * @implementation should be provided by application developer
 */
@protocol TSXMultiStepAuthenticationPresentorProtocol<TSXAuthenticationPresentorProtocol>

/**
 * Set the current input step. This is called before the session is ready for authentication input.
 *
 * @param stepNumber The current, 0-based step number. This is incremented to reflect progress in the session.
 * @param maxStepNumber The number of steps in the session, if known in advance. If this is not known this is -1.
 * @param stepDescription An object describing the step, and possibly the input required for this step.
 */
-(void)setInputStepWithStepNumber:(long)stepNumber maxStepNumber:(long)maxStepNumber stepDescription:(nullable id)stepDescription;
@end

#pragma mark - Pin Authenticator Extension (Application)
/*! \protocol TSXPinPresentorProtocol TSXPresentorsProtocol.h
 *  \brief PIN authentication presentor protocol
 *
 * Provides additional details about PIN Authenticator.
 *
 * @implementation should be provided by application developer
 */
@protocol TSXPinPresentorProtocol <TSXAuthenticationPresentorProtocol>

/**
 Provide the PIN length
 
 @param length The pin length
 */
-(void)pinLength:(long)length;
@end


#pragma mark - Pattern Authenticator Extension (Application)

/*! \protocol TSXPatternPresentorProtocol TSXPresentorsProtocol.h
 *  \brief Pattern authentication presentor protocol
 *
 * Provides additional details about pattern authenticator.
 *
 * @implementation should be provided by application developer
 */
@protocol TSXPatternPresentorProtocol <TSXAuthenticationPresentorProtocol>

/**
 Provides the pattern matrix width and height.
 
 @param width The pattern matrix number of columns.
 @param height The pattern matrix number of rows.
 */
-(void)patternWidth:(long)width height:(long)height;
@end

#pragma mark - OTP Authenticator Delegate Extension (SDK)

/*! \protocol TSXOTPAuthenticatorDelegate TSXPresentorsProtocol.h
 *  \brief OTP authentication session delegate protocol
 *
 * Additional delegate for OTP operations other than those provided
 * by the authenticator delegate.
 *
 * @implementation provided by SDK
 */
@protocol TSXOTPAuthenticatorDelegate<TSXGeneralAuthenticationPresentorDelegate>

/**
 Handle the selected OTP target, such as phone number or email.
 
 @param target The selected target.
 */
-(void)provideOtpTarget:(TSXOtpTarget*)target;

/**
 Request a new OTP code.
 */
-(void)resendOtpCode;
@end

#pragma mark - OTP Authenticator Presentor Extension (Application)

/*! \protocol TSXOtpPresentorProtocol TSXPresentorsProtocol.h
 *  \brief OTP authentication presentor protocol
 *
 * Provides OTP available targets as well as input format type and
 * additional details about OTP authenticator.
 *
 * @implementation should be provided by application developer
 */
@protocol TSXOtpPresentorProtocol <TSXAuthenticationPresentorProtocol>

/**
 Provides the OTP targets
 
 @param targets The available OTP targets
 */
-(void)setOTPTargets:(NSArray<TSXOtpTarget*>*)targets;

/**
 Provides the OTP format and selected target.
 
 @param format The OTP format type (Numeric, QR).
 @param target The selected target.
 */
-(void)setOTPInputFormat:(TSXOtpFormat *)format target:(TSXOtpTarget *)target;

/**
 Delegate object for OTP specific operations.
 */
@property (weak, nonatomic) id<TSXOTPAuthenticatorDelegate> otpDelegate;
@end

#pragma mark - TOTP Authenticator Presentor Delegate Extension (SDK)

/*! \protocol TSXTotpAuthenticatorDelegate TSXPresentorsProtocol.h
 *  \brief TOTP authentication session delegate protocol
 *
 * Additional delegate for TOTP operations other than those provided
 * by the authenticator delegate.
 *
 * @implementation provided by SDK
 */
@protocol TSXTotpAuthenticatorDelegate<TSXGeneralAuthenticationPresentorDelegate>

/**
 Handle the selected TOTP target, such as mobile device.
 
 @param target The selected target.
 */
-(void)provideTotpTarget:(TSXTotpTarget*)target;
@end

#pragma mark - TOTP Authenticator Presentor Extension (Application)

/*! \protocol TSXTotpAuthenticatorPresentorProtocol TSXPresentorsProtocol.h
 *  \brief TOTP authentication presentor protocol
 *
 * Provides TOTP available targets as well as input format type and
 * additional details about TOTP authenticator.
 *
 * @implementation should be provided by application developer
 */
@protocol TSXTotpAuthenticatorPresentorProtocol<TSXAuthenticationPresentorProtocol>

/**
 Provides the available targets that can be used to generate TOTP codes.
 
 @param targets The available targets.
 */
-(void)setAvailableTargets:(NSArray<TSXTotpTarget *> *)targets;

/**
 Provide the external challenge input type for which a challenge input
 should be collected, such as QR or numeric input.
 
 @param challenge The TOTP challenge.
 */
-(void)setChallenge:(TSXTotpChallenge *)challenge;

/**
 Delegate object for TOTP specific operations.
 */
@property (weak, nonatomic) id<TSXTotpAuthenticatorDelegate> totpAuthenticatorDelegate;
@end

#pragma mark - Available Control Options Base Class (SDK)

/**
 Base available options class for listing common control options
 *
 * @implementation provided by SDK
 */
@interface TSXAvailableOptions : NSObject

/**
 Retry current operation option available
 */
@property (nonatomic, readonly) BOOL retry;

/**
 Abort control flow option available
 */
@property (nonatomic, readonly) BOOL abort;
@end

#pragma mark - Authenticators Available Control Options (SDK)

/**
 Extended available options class for multiple authenticators control.
 *
 * @implementation provided by SDK
 */
@interface TSXAuthenticatorAvailableOptions : TSXAvailableOptions

/**
 Change to any other enabled authenticator option available
 */
@property (nonatomic, readonly) BOOL change;

/**
 List all provided authenticators option available
 */
@property (nonatomic, readonly) BOOL select;
@end

#pragma mark - Fallback Available Control Options (SDK)

/**
 Extended available options class for authentication fallback control.
 *
 * @implementation provided by SDK
 */
@interface TSXFallbackAvailableOptions : TSXAvailableOptions

/**
 Choose fallback to another authenticator option available
 */
@property (nonatomic, readonly) BOOL fallback;

/**
 Choose fallback from Authenticators menu option available
 */
@property (nonatomic, readonly) BOOL authMenu;
@end

#pragma mark - Control Options Delegate (SDK)

/*! \protocol TSXBaseControlOptionDelegate TSXPresentorsProtocol.h
 *  \brief Base control options delegate protocol
 *
 * Delegate protocol to handle the available control options.
 *
 * @implementation provided by SDK
 */
@protocol TSXBaseControlOptionDelegate<TSXGeneralPresentorDelegate>

/**
 Retry current operation.
 */
-(void)provideControlRetry;

/**
 Abort control flow.
 */
-(void)provideControlAbort;
@end

#pragma mark - Authenticator Control Options Delegate (SDK)

/*! \protocol TSXControlOptionDelegate TSXPresentorsProtocol.h
 *  \brief Extended authentication control options delegate protocol
 *
 * Delegate protocol to handle the available control options during authentication.
 *
 * @implementation provided by SDK
 */
@protocol TSXAuthenticatorControlOptionDelegate<TSXBaseControlOptionDelegate>

/**
 Select from Authenticators list
 */
-(void)provideControlSelect;

/**
 Change to another enabled Authenticator
 */
-(void)provideControlChange;
@end

#pragma mark - Authenticator Fallback Control Options Delegate (SDK)
/*! \protocol TSXAuthenticatorFallbackDelegate TSXPresentorsProtocol.h
 *  \brief Fallback from current authentication option list presentor delegate protocol
 *
 * Provides the fallback from current authentication control options.
 *
 * @implementation provided by SDK
 */
@protocol TSXAuthenticatorFallbackDelegate<TSXBaseControlOptionDelegate>

/**
 Switch to predefined fallback Authenticator.
 */
-(void)provideFallback;

/**
 Present list of other enabled Authenticators
 */
-(void)provideAuthMenu;
@end

#pragma mark - Cancellation Dialog Presentor Protocol (Application)
/*! \protocol TSXAuthenticationCancellationPresentorProtocol TSXPresentorsProtocol.h
 *  \brief Authentication cancelation option list presentor protocol
 *
 * Provides the available actions option when authentication cancelation is invoked.
 *
 * @implementation should be provided by application developer
 */
@protocol TSXAuthenticationCancellationPresentorProtocol<TSXBasePresentorProtocol>

/**
 Provide the authentication cancellation title, message and the available control option.
 
 @param title Title.
 @param message Body text.
 @param availableOptions available control options list.
 */
-(void)setTitle:(nullable NSString*)title message:(nullable NSString*)message availableOptions:(TSXAuthenticatorAvailableOptions*)availableOptions;

/**
 Authentication cancelation option list delegate object.
 */
@property (weak, nonatomic) id<TSXAuthenticatorControlOptionDelegate> controlOptionDelegate;
@end

#pragma mark - Error Dialog Presentor Protocol (Application)
/*! \protocol TSXErrorRecoveryPresentorProtocol TSXPresentorsProtocol.h
 *  \brief Error recovery option list presentor protocol
 *
 * Provides the error recovery control options.
 *
 * @implementation should be provided by application developer
 */
@protocol TSXErrorRecoveryPresentorProtocol<TSXBasePresentorProtocol>

/**
 Provide the error title, message and the available control options.
 
 @param title Title.
 @param message Body text.
 @param availableOptions The error available control options.
 */
-(void)setTitle:(nullable NSString*)title message:(nullable NSString*)message availableOptions:(TSXAuthenticatorAvailableOptions*)availableOptions;

/**
 Error recovery option list delegate object.
 */
@property (weak, nonatomic) id<TSXAuthenticatorControlOptionDelegate> controlOptionDelegate;
@end

#pragma mark - Fallback Dialog Presentor Protocol (Application)

/*! \protocol TSXAuthenticatorFallbackPresentorProtocol TSXPresentorsProtocol.h
 *  \brief Authenticatior fallback option list presentor protocol
 *
 * Provides the fallback control options for current authenticator session.
 *
 * @implementation should be provided by application developer
 */
@protocol TSXAuthenticatorFallbackPresentorProtocol<TSXBasePresentorProtocol>

/**
  Provide the authenticator fallback title, message and the available control option.

 @param title Title.
 @param message Body text.
 @param sessionName The failed Authenticator session name.
 @param availableOptions The authenticator fallback contorl options.
 */
-(void)setTitle:(nullable NSString*)title message:(nullable NSString*)message failedSessionName:(NSString *)sessionName availableOptions:(TSXFallbackAvailableOptions*)availableOptions;

/**
 Authenticator fallback option list delegate object.
 */
@property (weak, nonatomic) id<TSXAuthenticatorFallbackDelegate> fallbackDelegate;
@end

#pragma mark - Info Action Delegate (SDK)

/*! \protocol TSXInfoActionDelegate TSXPresentorsProtocol.h
 *  \brief Information action presentor delegate protocol
 *
 * Delegate protocol for control flow information action UI session presentor.
 *
 * @implementation provided by SDK
 */
@protocol TSXInfoActionDelegate<TSXGeneralPresentorDelegate>

/**
 Handle positive response.
 */
-(void)provideContinue;
@end

#pragma mark - Info Action Presentor (SDK)

/*! \protocol TSXInfoActionPresentorProtocol TSXPresentorsProtocol.h
 *  \brief Control flow action UI session presentor protocol
 *
 * Provides details for Information, Confirmation and Rejection control flow actions.
 *
 * @implementation should be provided by application developer
 */
@protocol TSXInfoActionPresentorProtocol<TSXBasePresentorProtocol>

/**
 Handle action presentation details.
 
 @param title Title.
 @param text Body text.
 @param continueButtonText Continue button text.
 @param cancelButtonText Cancel button text.
 */
-(void)setTitle:(NSString *)title text:(NSString *)text continueButtonText:(NSString *)continueButtonText cancelButtonText:(NSString* _Nullable)cancelButtonText;

/**
 Delegate object for control flow action control options.
 */
@property (weak, nonatomic) id<TSXInfoActionDelegate> actionDelegate;
@end

#pragma mark - TOTP (Soft Token) Generation Session Delegate (SDK)
/*! \protocol TSXTotpDelegate TSXPresentorsProtocol.h
 *  \brief TOTP code generation presentor delegate protocol
 *
 * Protocol for client side initiated TOTP code generation presentor delegate
 *
 * @implementation provided by SDK
 */
@protocol TSXTotpDelegate <TSXGeneralAuthenticationPresentorDelegate>
/**
 Called to provide the challenge input.
 
 @param challengeInput The challenge input.
 */
-(void)provideChallengeInput:(NSString*)challengeInput;
@end

#pragma mark - TOTP (Soft Token) Generation Session Presentor (Application)
/*! \protocol TSXTotpPresentorProtocol TSXPresentorsProtocol.h
 *  \brief TOTP code generation presentor protocol
 *
 * Provides TOTP available challenges, optionally a predefined message and generated code details.
 *
 * @implementation should be provided by application developer
 */
@protocol TSXTotpPresentorProtocol <TSXGeneralPresentorProtocol>
/**
 Code presentation details. When time based includes time to live and remaining seconds.
 When canonical generation is used, a message is provided.
 
 @param code TOTP code.
 @param ttlSeconds Total seconds.
 @param remainingSeconds Remaining seconds until new code is generated.
 */
-(void)setTotpCode:(NSString*)code ttlSeconds:(long)ttlSeconds remainingSeconds:(long)remainingSeconds;

/**
 Provide constant message in canonical TOTP generation mode.
 
 @param message Code generation message.
 */
-(void)setMessage:(NSString*)message;


/**
 Provide array of optional TOTP challenges (Numeric,QR)

 @param challenges TOTP challenges
 */
-(void)setTotpChallenges:(NSArray<TSXTotpChallengeFormat*>*)challenges;

/**
 Delegate object to call the TOTP actions.
 */
@property (weak, nonatomic) id<TSXTotpDelegate> totpDelegate;
@end


#pragma mark - Promotion Session Delegate (SDK)
/*! \protocol TSXPromotionDelegate TSXPresentorsProtocol.h
 *  \brief Authenticators promotion presentor delegate protocol
 *
 * Provides control options for promotion presentor and consumes choice of Authenticator
 * to register.
 *
 * @implementation provided by SDK
 */
@protocol TSXPromotionDelegate

/**
 Skip the promotion session.
 */
-(void)providePromotionSkip;

/**
 Cancel promotion and abort control flow.
 */
-(void)providePromotionAbort;

/**
 Continue from promotional introduction presentation step to Authenticators list.
 */
-(void)providePromotionContinue;

/**
 Provide Authenticator to register.
 
 @param authenticator Selected authenticator.
 */
-(void)provideInputAuthenticator:(TSXAuthenticatorDescription*)authenticator;
@end

#pragma mark - Promotion Session Presentor (Application)
/*! \protocol TSXPromotionPresentorProtocol TSXPresentorsProtocol.h
 *  \brief Authenticator promotion introduction and regitration presentor protocol
 *
 * Provides introductory information about the promotion options, suggests list of
 * Authenticators to promote and allows Authenticator registration.
 *
 * @implementation should be provided by application developer
 */
@protocol TSXPromotionPresentorProtocol <TSXGeneralPresentorProtocol>
/**
 Provide promotion introduction details.
 
 @param title Title.
 @param text Body text.
 @param continueText Continue button text.
 @param cancelText Cancel button text.
 */
-(void)setIntroduction:(NSString *)title text:(NSString *)text continueText:(NSString *)continueText cancelText:(NSString *)cancelText;

/**
 Provide the promotion authenticators list and continue button text.
 
 @param authenticators Available Authenticators list.
 @param continueText Continue button text.
 */
-(void)setAuthenticatorsList:(NSArray<TSXAuthenticatorDescription*>*)authenticators continueText:(NSString*)continueText;

/**
 Delegate object for promotion control options in Authenticator choice input.
 */
@property (weak, nonatomic) id<TSXPromotionDelegate> promotionDelegate;
@end


#pragma mark - Configuration Session Delegate (SDK)
/*! \protocol TSXConfigurationDelegate TSXPresentorsProtocol.h
 *  \brief Authenticators configuration presentor delegate protocol
 *
 * Provides actions on Authenticators available throughout the application flows.
 *
 * @implementation provided by SDK
 */

@protocol TSXConfigurationDelegate <TSXGeneralPresentorDelegate>
/**
 Register an unregistered Authenticator.
 Completion block returns no data on success. Returns error on failure.

 @param authenticator Selected Authenticator.
 @param completion Optional completion block.
 */
-(void)registerAuthenticator:(TSXConfigurableAuthenticator *)authenticator completion:(Completion _Nullable)completion;

/**
 Unregister a registered authenticator.
 Completion block returns no data on success. Returns error on failure.

 @param authenticator Selected Authenticator.
 @param completion Optional completion block.
 */
-(void)unregisterAuthenticator:(TSXConfigurableAuthenticator *)authenticator completion:(Completion _Nullable)completion;

/**
 Register a registered Authenticator.
 Completion block returns no data on success. Returns error on failure.

 @param authenticator Selected Authenticator.
 @param completion Optional completion block.
 */
-(void)reregisterAuthenticator:(TSXConfigurableAuthenticator *)authenticator completion:(Completion _Nullable)completion;

/**
 Set Authenticator as default for authentication.
 Completion block returns no data on success. Returns error on failure.

 @param authenticator Selected Authenticator.
 @param completion Optional completion block.
 */
-(void)setDefaultAuthenticator:(TSXConfigurableAuthenticator *)authenticator completion:(Completion _Nullable)completion;
@end

#pragma mark - Configuration Session Presentor (Application)
/*! \protocol TSXConfigurationPresentorProtocol TSXPresentorsProtocol.h
 *  \brief Authenticators configuration presentor protocol
 *
 * Provides list of Authenticators available throughout the application flows.
 *
 * @implementation should be provided by application developer
 */
@protocol TSXConfigurationPresentorProtocol <TSXGeneralPresentorProtocol>

/**
 Provide list of the available authenticators
 
 @param authenticators Available authenticators.
 */
-(void)setAuthenticatorsList:(NSArray<TSXConfigurableAuthenticator *> *)authenticators;

/**
 Delegate object for Authenticator actions.
 */
@property (weak, nonatomic) id<TSXConfigurationDelegate> configurationDelegate;
@end


#pragma mark - Authenticators List Delegate (SDK)
/*! \protocol TSXAuthenticatorsListDelegate TSXPresentorsProtocol.h
 *  \brief Authenticators list presentor delgate protocol
 *
 * Provides Authenticator option selection action.
 *
 * @implementation provided by SDK
 */
@protocol TSXAuthenticatorsListDelegate <TSXGeneralPresentorDelegate>
/**
 Select Authenticator to use.
 
 @param authenticator Selected Authenticator.
 */
-(void)provideInputAuthenticator:(TSXAuthenticationOption *)authenticator;
@end

#pragma mark - Authenticators List Presentor (Application)
/*! \protocol TSXAuthenticatorsListPresentorProtocol TSXPresentorsProtocol.h
 *  \brief Authenticators list presentor protocol
 *
 * Provides list of optional Authenticators for current use (see actionContext).
 *
 * @implementation should be provided by application developer
 */
@protocol TSXAuthenticatorsListPresentorProtocol <TSXBasePresentorProtocol>

/**
 Provides list of optional Authenticators for current use as referenced by actionContext.
 The action context includes one of the following strings:
 1. "registration" - List of Authenticators available for registration.
 2. "authentication" - List of enabled Authenticators to authenticate with.
    This list may include unregistered or locked Authenticators.
    See -[TSXUIHandler shouldIncludeDisabledAuthenticatorsInMenuWithActionContext:clientContext:] for more details.
 3. "provision_totp" - List of Authenticators that may be used to protect a TOTP code generator.
 
 
 @param options List of Authenticators wrapped in options objects.
 @param actionContext Context of the Authenticators list (registration, authentication, provision_totp).
 @param clientContext Client context.
 */
-(void)setAuthenticatorsOptions:(NSArray<TSXAuthenticationOption *> *)options actionContext:(TSXPolicyAction *)actionContext clientContext:(NSDictionary *)clientContext;

/**
 Delegate object for selecting Authenticators.
 */
@property (weak, nonatomic) id<TSXAuthenticatorsListDelegate> authenticatorsListDelegate;
@end

#pragma mark - Scan QR Session Delegate (SDK)
/*! \protocol TSXScanQRDelegate TSXPresentorsProtocol.h
 *  \brief QR scan presentor delegate protocol
 *
 * Provides input action for QR scan presentor
 *
 * @implementation provided by SDK
 */
@protocol TSXScanQRDelegate<TSXGeneralPresentorDelegate>
/**
 Provides camera QR acquisition response. See "TSXCameraInputView.h" in TransmitSDK3.framework
 for "TSXCameraInputResponse" generation.
 
 @param response TSXCameraInputResponse object with QR data aqcuired by camera.
 */
-(void)provideCameraInputResponse:(TSXCameraInputResponse*)response;
@end

#pragma mark - Scan QR Session Presentor (Application)
/*! \protocol TSXScanQRPresentorProtocol TSXPresentorsProtocol.h
 *  \brief QR scan presentor protocol
 *
 * Provides context for QR acquisition with TSXCameraInputView.
 * See "TSXCameraInputView.h" in TransmitSDK3.framework for "TSXCameraInputResponse" generation.
 *
 * @implementation should be provided by application developer
 */
@protocol TSXScanQRPresentorProtocol<TSXGeneralPresentorProtocol>

/**
 Provide instructions text and QR code format type.
 
 @param instructionsText Instructions text.
 @param qrCodeFormat QR code format type.
 */
-(void)startQrInputWithInstructions:(NSString*)instructionsText qrCodeFormat:(TSXQrCodeFormat)qrCodeFormat;

/**
 Delegate object for QR scan input handling.
 */
@property (weak, nonatomic) id<TSXScanQRDelegate> scanQRDelegate;
@end

#pragma mark - Local Authenticator Invalidated Delegate (SDK)
/*! \protocol TSXLocalAuthenticatorInvalidateDelegate TSXPresentorsProtocol.h
 *  \brief Local Authenticator invalidation notice presentor delegate protocol
 *
 * Provides notice about local Authenticator which got unregistered by the hosting platform.
   E.g. Transmit biometric Authenticator invalidated after editing device biometrics settings.
 *
 * @implementation provided by SDK
 */
@protocol TSXLocalAuthenticatorInvalidatedDelegate
/**
 Dismiss and acknowledge notice.
 */
-(void)provideComplete;
@end

#pragma mark - Local Authenticator Invalidated Presentor (Application)
/*! \protocol TSXLocalAuthenticatorInvalidatedPresentorProtocol TSXPresentorsProtocol.h
 *  \brief Local Authenticator invalidation notice presentor protocol
 *
 * Provide local Authenticator invalidation notice details.
 *
 * @implementation should be provided by application developer
 */
@protocol TSXLocalAuthenticatorInvalidatedPresentorProtocol<TSXBasePresentorProtocol>

/**
 Provide description object of the invalidated Authenticator.
 
 @param description Authenticator description object.
 */
-(void)localAuthenticatorInvalidatedWithDescription:(TSXAuthenticatorDescription* _Nonnull)description;

/**
 Delegate object for completion of notice presentation.
 */
@property (weak, nonatomic) id<TSXLocalAuthenticatorInvalidatedDelegate> localAuthenticatorInvalidateDelegate;
@end

NS_ASSUME_NONNULL_END


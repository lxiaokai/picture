//
//  TwoViewController.h
//  TransmitSDKDemo
//
//  Created by Alex on 2020/1/6.
//  Copyright © 2020 alex. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface TwoViewController : UIViewController

@end

NS_ASSUME_NONNULL_END

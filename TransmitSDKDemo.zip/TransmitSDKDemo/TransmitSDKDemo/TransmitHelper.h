//
//  TransmitHelper.h
//  HSBC_CMB
//
//  Created by felix guan on 2018/8/23.
//  Copyright © 2018年 Green Tomato. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

#import <TransmitSDK3/TransmitSDK3.h>
#import "TSCustomUIHandler.h"
#import "TSXTestUIHandler.h"
#import "TSOtpSession.h"


@interface TransmitHelper : NSObject

@property (nonatomic, copy) NSString *nextPolicy;

@property (nonatomic, copy) NSString *isInProvisioned;

@property (nonatomic, copy) NSString *randomNum;

@property (nonatomic, strong) NSArray<TSXManagedDevice*> *deviceList;

@property (nonatomic, strong) NSDictionary *touchidFristResponseBody;

@property (nonatomic, copy) NSString *openAMCookie;

@property (nonatomic, strong) TSXApprovalManagementSessionServices *tsApprovalService;

@property (nonatomic, strong) TSXManagedMobileApproval *tsManagedApproval;

@property (nonatomic, strong) TSCustomUIHandler *customUIHandler;
@property (nonatomic, strong) TSXTestUIHandler *testUIHandler;

@property (nonatomic, copy) NSString *removeDeviceID;

@property (nonatomic, copy) NSString *currentDeviceID;

@property (nonatomic, strong) NSArray *devicesInProvisioned;

@property (nonatomic, assign) BOOL isAuthenticated;

@property (nonatomic, copy) NSString *currentApproveId;

@property (nonatomic, copy) NSString *expiredFlag;

@property (nonatomic, copy) NSString *comeFromMorePage;

@property (nonatomic, copy) NSString *noPendingApproval;

@property (nonatomic, copy) NSString *authenticatorNotFound;

@property (nonatomic, assign) BOOL biometricUpdated;

@property (nonatomic, assign) BOOL errorWhileApprove;

+ (instancetype)sharedInstance;

- (void)setPushAuthentificationInformnation:(NSDictionary *)info;

- (NSArray *)getBoundUserIds;

- (BOOL)isBoundForUserWithUserId:(NSString *)userId;

- (void)logoff;

- (void)logoffTransmitWithHandler:(void (^ _Nonnull)(BOOL, TSXAuthenticationError* _Nullable))handler;

-(void)setPushToken:(NSString* _Nonnull)pushToken;

- (void)cancelCurrentRunningControlFlow;

- (void)invokePolicyToMakeTokenValidCompletionHandler: (void (^ _Nonnull)(TSXAuthenticationResult* _Nonnull, TSXAuthenticationError* _Nullable))handler;

- (void)extendTransmitSession;

- (void)restartSessionWithCompletionHandler: (void (^ _Nonnull)(TSXAuthenticationResult* _Nonnull, TSXAuthenticationError* _Nullable))handler;

// initialize transmit SDK
- (void)initializeTransmitSdkCompletionHandler:(void (^ _Nonnull)(BOOL, TSXAuthenticationError* _Nullable))completionHandler;

- (void)handleTransmitStartActivateMSK:(NSDictionary *)functionParams completionWithHandler:(void (^ _Nonnull)(TSXAuthenticationResult* _Nonnull, TSXAuthenticationError* _Nullable))handler;

- (void)handleTransmitSetOTPRegister:(NSDictionary *)functionParams completionWithHandler:(void (^ _Nonnull)(TSXAuthenticationResult* _Nonnull, TSXAuthenticationError* _Nullable))handler;

- (void)processHandleTransmitCreatePin:(NSDictionary *)functionParams completionWithHandler:(void (^ _Nonnull)(TSXAuthenticationResult* _Nonnull, TSXAuthenticationError* _Nullable))handler;

- (void)handleTransmitSetFingerPrint:(NSDictionary *)functionParams tsPrompt:(NSString *)prompt completionWithHandler:(void (^ _Nonnull)(TSXAuthenticationResult* _Nonnull, TSXAuthenticationError* _Nullable))handler;

- (void)handleTransmitGetMobileAuthActivatedDevices:(NSDictionary *)functionParams completionWithHandler:(void (^ _Nonnull)(BOOL,NSArray* _Nullable, TSXAuthenticationError* _Nullable))handler;

- (void)handleTransmitLogonBySMK:(NSDictionary *)functionParams completionWithHandler:(void (^ _Nonnull)(TSXAuthenticationResult* _Nonnull, TSXAuthenticationError* _Nullable))handler;

- (void)handleTransmitResetPin:(NSDictionary *)functionParams completionWithHandler:(void (^ _Nonnull)(TSXAuthenticationResult* _Nonnull, TSXAuthenticationError* _Nullable))handler;

- (void)handleTransmitVerifyOtpPwd:(NSDictionary *)functionParams completionWithHandler:(void (^ _Nonnull)(TSXAuthenticationResult* _Nonnull, TSXAuthenticationError* _Nullable))handler;

- (void)handleTransmitGetTouchIDAuthID:(NSDictionary *)functionParams completionWithHandler:(void (^ _Nonnull)(TSXAuthenticationResult* _Nonnull, TSXAuthenticationError* _Nullable))handler;

- (void)handleTransmitLogonByBiometric:(NSDictionary *)functionParams completionWithHandler:(void (^ _Nonnull)(TSXAuthenticationResult* _Nonnull, TSXAuthenticationError* _Nullable))handler;

- (void)phandleTransmitDeactivate:(NSDictionary *)functionParams completionWithHandler:(void (^ _Nonnull)(BOOL, TSXAuthenticationError* _Nullable))handler;

- (void)handleTransmitDeactivateFingerprint:(NSDictionary *)functionParams completionWithHandler:(void (^ _Nonnull)(TSXAuthenticationResult* _Nonnull, TSXAuthenticationError* _Nullable))handler;

- (void)handleTransmitDeactivateCurrentDeviceMSKCompletionWithHandler:(void (^ _Nonnull)(BOOL, TSXAuthenticationError* _Nullable))handler;

- (void)handleTransmitIsParamsInvalid:(NSDictionary *)functionParams completionWithHandler:(void (^ _Nonnull)(TSXAuthenticationResult* _Nonnull, TSXAuthenticationError* _Nullable))handler;

- (void)handleTransmitDeviceIsRegister:(NSDictionary *)functionParams completionWithHandler:(void (^ _Nonnull)(TSXAuthenticationResult* _Nonnull, TSXAuthenticationError* _Nullable))handler;

- (void)handletransmitCheckExpried:(NSDictionary *)functionParams completionWithHandler:(void (^ _Nonnull)(BOOL, TSXAuthenticationError* _Nullable))handler;

- (void)handleTransmitApprove:(NSDictionary *)functionParams completionWithHandler:(void (^ _Nonnull)(BOOL, TSXAuthenticationError* _Nullable))handler;

- (void)handleTransmitDoNotApprove:(NSDictionary *)functionParams completionWithHandler:(void (^ _Nonnull)(BOOL, TSXAuthenticationError* _Nullable))handler;

- (void)handleTransmitRenameDevice:(NSDictionary *)functionParams completionWithHandler:(void (^ _Nonnull)(BOOL, TSXAuthenticationError* _Nullable))handler;

- (void)handleTransmitGet8DigitNumber:(NSDictionary *)functionParams completionWithHandler:(void (^ _Nonnull)(TSXAuthenticationResult* _Nonnull, TSXAuthenticationError* _Nullable))handler;

- (void)handleTransmitCheckNotification:(NSDictionary *)functionParams completionWithHandler:(void (^ _Nonnull)(BOOL, TSXAuthenticationError* _Nullable))handler;

- (void)handleTransmitRefreshApproveStatus:(NSDictionary *)functionParams completionWithHandler:(void (^ _Nonnull)(BOOL, TSXAuthenticationError* _Nullable))handler;

- (void)handleTransmitDeactivateMSKPIN:(NSDictionary *)functionParams completionWithHandler:(void (^ _Nonnull)(TSXAuthenticationResult* _Nonnull, TSXAuthenticationError* _Nullable))handler;

// Desktop payment TDS authentication -- start
- (void)startApproveSession:(NSDictionary *)context completionWithHandler:(void (^ _Nonnull)(BOOL result, TSXAuthenticationError* _Nullable error))handler;

- (void)handleRefreshTransmitApprovalWithClientContext: (NSDictionary *)context
                                   CompleteWithHandler: (void (^ _Nonnull)(BOOL, TSXAuthenticationError* _Nullable))handler;

- (void)handleDoNotApproveWithClientContext: (NSDictionary *)context
                        CompleteWithHandler: (void (^ _Nonnull)(BOOL, TSXAuthenticationError* _Nullable))handler;

- (void)handleTransmitDesktopTDSApproveIsFaceId: (BOOL)isFaceId
                                  promptMessage: (NSString *)message
                                  clientContext: (NSDictionary *)clientContext
                            completeWithHandler: (void (^ _Nonnull)(TSXAuthenticationResult *_Nullable, TSXAuthenticationError* _Nullable))handler;

- (void)handleTransmitDesktopTDSApproveWithPin: (NSString *)pin
                                 clientContext: (NSDictionary *)clientContext
                           completeWithHandler: (void (^ _Nonnull)(TSXAuthenticationResult *_Nullable, TSXAuthenticationError* _Nullable))handler;
// Desktop payment TDS authentication -- end

// MARK: - For TDS
- (void)handleTransmitMSKDigitalSigningWithPin: (NSString *)pin
                                    withParams: (NSDictionary *)params
                        andCompleteWithHandler: (void (^ _Nonnull)(TSXAuthenticationResult* _Nonnull, TSXAuthenticationError* _Nullable))handler;

- (void)handleTransmitBiometricDigitalSigningIsFaceId: (BOOL)isFaceId
                                     andPromptMessage: (NSString *)message
                                           withParams: (NSDictionary *)params
                               andCompleteWithHandler: (void (^ _Nonnull)(TSXAuthenticationResult* _Nonnull, TSXAuthenticationError* _Nullable))handler;

- (void)handleTransmitParameter:(NSString *)parameter
             completionWithHandler:(void (^ _Nonnull)(TSXAuthenticationResult* _Nonnull, TSXAuthenticationError* _Nullable))handler;
@end

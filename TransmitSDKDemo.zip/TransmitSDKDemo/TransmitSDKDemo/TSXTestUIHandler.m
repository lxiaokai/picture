//
//  TSXTestUIHandler.m
//  TransmitSDKDemo
//
//  Created by Alex on 2019/11/20.
//  Copyright © 2019 alex. All rights reserved.
//

#import "TSXTestUIHandler.h"
#import "TestFormInputSession.h"
#import "OneViewController.h"
#import "TestOtpAuthenticationSession.h"

@implementation TSXTestUIHandler

-(void)startActivityIndicatorWithActionContext:(TSXPolicyAction *)actionContext clientContext:(NSDictionary *)clientContext {
    // show network indicator
    [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
    NSLog(@"%s",__func__);
}

-(void)endActivityIndicatorWithActionContext:(TSXPolicyAction *)actionContext clientContext:(NSDictionary *)clientContext {
    // hide network indicator
    [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:YES];
    NSLog(@"%s",__func__);
}


-(void)processJsonDataWithJsonData:(NSDictionary *)jsonData
                     actionContext:(TSXPolicyAction *)actionContext
                     clientContext:(NSDictionary *)clientContext
         asynchronouslyWithHandler:(void (^)(TSXJsonDataProcessingResult * _Nonnull))handler
{
    NSString *jsonStr = [[NSString alloc] initWithData:[NSJSONSerialization dataWithJSONObject:jsonData options:NSJSONWritingPrettyPrinted error:nil] encoding:NSUTF8StringEncoding];
    UIAlertController *jsonOptMenu =
    [UIAlertController alertControllerWithTitle:@"JSON received"
                                        message:jsonStr
                                 preferredStyle:UIAlertControllerStyleActionSheet];
    __weak UIAlertController *weakAlert = jsonOptMenu;
    
    UIAlertAction *jsonConfirm = [UIAlertAction actionWithTitle:@"Confirm"
                                                          style:UIAlertActionStyleDefault
                                                        handler:^(UIAlertAction * _Nonnull action) {
                                                            [weakAlert dismissViewControllerAnimated:YES completion:nil];
                                                            handler([TSXJsonDataProcessingResult createWithContinueProcessing:YES]);
                                                        }];
    [jsonOptMenu addAction:jsonConfirm];
    
    
    UIAlertAction *jsonAbort = [UIAlertAction actionWithTitle:@"Cancel"
                                                        style:UIAlertActionStyleCancel
                                                      handler:^(UIAlertAction * _Nonnull action) {
                                                          [weakAlert dismissViewControllerAnimated:YES completion:nil];
                                                          
                                                          handler([TSXJsonDataProcessingResult createWithContinueProcessing:NO]);
                                                      }];
    [jsonOptMenu addAction:jsonAbort];
    
    // Present menu to user and resume auth
    TSXDefaultUIHandlerHostingContext *hostingContext = [TSXDefaultUIHandler hostingContextFromClientContext:clientContext];
    [hostingContext presentDialogViewController:jsonOptMenu];
}

- (void)getConfirmationInputWithTitle:(NSString *)title text:(NSString *)text continueText:(NSString *)continueText cancelText:(NSString *)cancelText actionContext:(TSXPolicyAction *)actionContext clientContext:(NSDictionary *)clientContext asynchronouslyWithHandler:(void (^)(TSXConfirmationInput * _Nonnull))handler {
    
}

 // 获取弹窗dialog的内容
- (void)getInformationResponseWithTitle:(NSString *)title text:(NSString *)text continueText:(NSString *)continueText actionContext:(TSXPolicyAction *)actionContext clientContext:(NSDictionary *)clientContext asynchronouslyWithHandler:(void (^)(TSXConfirmationInput * _Nonnull))handler {
    TSXDefaultUIHandlerHostingContext *hostingContext = [TSXDefaultUIHandler hostingContextFromClientContext:clientContext];
    NSLog(@" title: %@\n text: %@\n continueText: %@\n", title, text, continueText);
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:title message:text preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *okAction = [UIAlertAction actionWithTitle:continueText style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        NSLog(@"确定");
        [hostingContext.hostingViewController.navigationController popToRootViewControllerAnimated:YES];
        handler([TSXConfirmationInput createWithUserChoice:-1]);
    }];
    [alertController addAction:okAction];
    
    
    [hostingContext.hostingViewController.navigationController presentViewController:alertController animated:YES completion:nil];
//    [hostingContext presentDialogViewController:alertController];
//    [hostingContext presentViewController:alertController animated:YES];
}




-(void)handlePolicyRejectionWithTitle:(NSString *)title text:(NSString *)text buttonText:(NSString *)buttonText failureData:(NSDictionary *)failureData actionContext:(TSXPolicyAction *)actionContext clientContext:(NSDictionary *)clientContext asynchronouslyWithHandler:(void (^)(TSXConfirmationInput * _Nonnull))handler {
    handler([TSXConfirmationInput createWithUserChoice:-1]);
}

// FormSession
-(TSXUIFormSession* _Null_unspecified)createFormSessionWithFormId:(NSString* _Nonnull)formId payload:(NSDictionary * _Nonnull)payload {
    // formId : Test_Form_ID
    return [[TestFormInputSession alloc] initWithFormId:formId payload:payload];

}

-(TSXUIAuthenticatorSessionOtp *)createOtpAuthSessionWithTitle:(NSString *)title username:(NSString *)username possibleTargets:(NSArray<TSXOtpTarget *> *)possibleTargets autoExecedTarget:(TSXOtpTarget *)autoExecedTarget {
    return [[TestOtpAuthenticationSession alloc] initWithTargets:possibleTargets
                                                  selectedTarget:autoExecedTarget];
}

- (void)selectAuthenticatorWithOptions:(NSArray<TSXAuthenticationOption *> *)options actionContext:(TSXPolicyAction *)actionContext clientContext:(NSDictionary *)clientContext asynchronouslyWithHandler:(void (^)(TSXAuthenticatorSelectionResult * _Nonnull))handler {
    // Prepare authentication method menu UIAlertController *authOptionMenu =
   
}

-(TSXUIAuthenticatorSession<TSXPasswordInput *> *)createPasswordAuthSessionWithTitle:(NSString *)title username:(NSString *)username {
   
    return [[TSXUIAuthenticatorSession alloc] init];
}

-(TSXUIAuthenticatorSession<TSXPinInput *> *)createPinAuthSessionWithTitle:(NSString *)title username:(NSString *)username pinLength:(long)pinLength {
    return [[TSXUIAuthenticatorSession alloc] init];
}

-(TSXUIAuthenticatorSession<TSXFingerprintInput *> *)createFingerprintAuthSessionWithTitle:(NSString *)title username:(NSString *)username {
    return [[TSXUIAuthenticatorSession alloc] init];
}

- (TSXUITotpGenerationSession *)createTotpGenerationSessionWithUserId:(NSString *)userId generatorName:(NSString *)generatorName {
    return [[TSXUIAuthenticatorSession alloc] init];
}


@end



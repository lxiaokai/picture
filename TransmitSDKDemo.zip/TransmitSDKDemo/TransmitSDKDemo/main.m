//
//  main.m
//  TransmitSDKDemo
//
//  Created by Alex on 2019/11/15.
//  Copyright © 2019 alex. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}

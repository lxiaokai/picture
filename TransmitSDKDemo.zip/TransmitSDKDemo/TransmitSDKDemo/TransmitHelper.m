//
//  TransmitHelper.m
//  HSBC_CMB
//
//  Created by felix guan on 2018/8/23.
//  Copyright © 2018年 Green Tomato. All rights reserved.
//

#import "TransmitHelper.h"
#import "ViewController.h"
#import "TSCustomTransportProvider.h"

#define tsAuthenticatorTypePassword                     1 << 0
#define tsAuthenticatorTypeOtp                          1 << 4
#define tsAuthenticatorTypePlacehoder                   1 << 11
#define tsAuthenticatorTypeFingerprint                  1 << 1
#define tsAuthenticatorTypePincode                      1 << 2
#define tsAuthenticatorTypeFaceId                       1 << 10
#define tsAuthenticatorTypeTotp                         1 << 13


@interface TransmitHelper ()

@property (nonatomic, copy) NSString *currentPolicy;

@property (nonatomic, strong) TSXTransmitSDKXm *sdk;


@end

@implementation TransmitHelper

+ (instancetype)sharedInstance {
    static dispatch_once_t onceToken;
    static id instance;
    dispatch_once(&onceToken, ^{
        instance = [[self alloc] init];
    });
    return instance;
}

// set connection timeout
-(void)setTransmitHttpConnectionTimeout{
    //TSCustomTransportProvider *provider = [[TSCustomTransportProvider alloc] init];
    //[self.sdk setTransportProvider:provider];
    TSXHTTPTransportProvider *tsTransportProvider = [[TSXHTTPTransportProvider alloc] init];
    tsTransportProvider.timeoutInterval = 30.0;
    [self.sdk setTransportProvider:tsTransportProvider];
    
    
}

// initialize transmit SDK
- (void)initializeTransmitSdkCompletionHandler:(void (^ _Nonnull)(BOOL, TSXAuthenticationError* _Nullable))completionHandler {
    // Obtain SDK shared instance
    self.sdk = [TSXTransmitSDKXm sharedInstance];
    [self.sdk setEnabledCollectors:
                            (CollectorTypeAccounts |
                             CollectorTypeDeviceDetails |
                             CollectorTypeOwner |
                             CollectorTypeSoftware |
                             CollectorTypeBluetooth |
                             CollectorTypeExternalSDKDetails |
                             CollectorTypeHWAuthenticators |
                             CollectorTypeCapabilities)];
    
    // Configure SDK server connection
    TSXSDKConnectionSettings * connectionSettings =
    [TSXSDKConnectionSettings createWithServerAddress:@"https://qualityassurance-amh-dbbsp-mauth-dev.p2g.netd2.hsbc.com.hk"
                                                appId:@"poc_mobile"
                                            tokenName:@"hsbcbizexpress"
                                                token:@"1399a590-b894-48e2-b164-ffab82e23eae"];
    
//    TSXSDKConnectionSettings * connectionSettings =
//    [TSXSDKConnectionSettings createWithServerAddress:@"https://qualityassurance-amh-dbbsp-mauth-dev.p2g.netd2.hsbc.com.hk"
//                                                appId:@"hsbcbizexpress"
//                                            tokenName:@"hsbcbizexpress"
//                                                token:@"1399a590-b894-48e2-b164-ffab82e23eae"];

    
    
    
    [self.sdk setConnectionSettings:connectionSettings];
    
    // setting UIHandler
    self.testUIHandler = [[TSXTestUIHandler alloc] init];
    [self.sdk setUiHandler:self.testUIHandler];
    
    [self setTransmitHttpConnectionTimeout];
    
    // Initialize SDK
    [self.sdk initializeAsynchronouslyWithHandler:^(BOOL result, TSXAuthenticationError *error) {
        completionHandler(result, error);
    }];
}

- (NSArray *)getBoundUserIds {
    return [self.sdk getBoundUserIds];
}

- (BOOL)isBoundForUserWithUserId:(NSString *)userId {
    return [self.sdk isBoundForUserWithUserId:userId];
}

- (void)invokePolicyToMakeTokenValidCompletionHandler: (void (^ _Nonnull)(TSXAuthenticationResult* _Nonnull, TSXAuthenticationError* _Nullable))handler; {
    [self.sdk invokePolicyWithPolicyId:@"get8BitRandomNum" additionalParameters:@{} clientContext:@{} asynchronouslyWithHandler:^(TSXAuthenticationResult * _Nonnull result, TSXAuthenticationError * _Nullable error) {
        handler(result, error);
    }];
}

- (void)extendTransmitSession {
    [self.sdk invokePolicyWithPolicyId:@"get8BitRandomNum" additionalParameters:@{} clientContext:@{} asynchronouslyWithHandler:^(TSXAuthenticationResult * _Nonnull result, TSXAuthenticationError * _Nullable error) {
    }];
}

- (void)restartSessionWithCompletionHandler: (void (^ _Nonnull)(TSXAuthenticationResult* _Nonnull, TSXAuthenticationError* _Nullable))handler {
    [self authenticateUserWithUserId: self.getBoundUserIds.lastObject
                            policyId: @"get8BitRandomNum"
               completionWithHandler: ^(TSXAuthenticationResult * _Nonnull result, TSXAuthenticationError * _Nullable error)
     {
         handler(result, error);
     }];
}

- (void)logoff {
    [self logoffTransmitWithHandler:^(BOOL result, TSXAuthenticationError * _Nullable error) {
        
    }];
}

- (void)logoffTransmitWithHandler:(void (^ _Nonnull)(BOOL result, TSXAuthenticationError* _Nullable error))handler {
    
    [self.sdk logoutAsynchronouslyWithHandler:^(BOOL result, TSXAuthenticationError * _Nullable error) {
        self.isAuthenticated = NO;
        NSLog(@"logoffTransmit --> %@", error);
        handler(result, error);
    }];
}

-(void)setPushToken:(NSString* _Nonnull)pushToken {
    [self.sdk setPushToken:pushToken];
}

- (void)cancelCurrentRunningControlFlow {
    [self.sdk cancelCurrentRunningControlFlow];
}

- (void)setPushAuthentificationInformnation:(NSDictionary *)info {
    self.currentApproveId = [info objectForKey:@"approval_id"];
//    self.approveUserId =[info objectForKey:@"user_id"];
}

- (void)setDevicesInProvisioned:(NSArray *)devicesInProvisioned {
    _devicesInProvisioned = devicesInProvisioned;
    
    NSMutableArray *devicesM = [NSMutableArray arrayWithCapacity:3];
    if (devicesInProvisioned) {
        for (NSDictionary *device in devicesInProvisioned) {
            NSDictionary *hw_details = [device objectForKey:@"hw_details"];
            NSMutableDictionary *deviceInfo = [NSMutableDictionary dictionaryWithCapacity:4];
            [deviceInfo setObject:[device objectForKey:@"device_id"] forKey:@"device_id"];
            [deviceInfo setObject:[hw_details objectForKey:@"device_model"] forKey:@"device_model"];
            [deviceInfo setObject:[device objectForKey:@"alias"] forKey:@"device_name"];
            if ([[device objectForKey:@"device_id"] isEqualToString:self.currentDeviceID]) {
                [deviceInfo setObject:@"true" forKey:@"is_current_device"];
            } else {
                [deviceInfo setObject:@"false" forKey:@"is_current_device"];
            }
            
            [devicesM addObject:deviceInfo];
        }
    }
    self.deviceList = devicesM.copy;
}


- (void)authenticateUserWithUserId: (NSString *)userId
                          policyId: (NSString *)policyId
             completionWithHandler: (void (^ _Nonnull)(TSXAuthenticationResult* _Nonnull, TSXAuthenticationError* _Nullable))handler
{
    [self authenticateUserWithUserId:userId
                            policyId:policyId
                             skipOtp:NULL
               completionWithHandler:handler];
}

- (void)authenticateUserWithUserId: (NSString *)userId
                          policyId: (NSString *)policyId
                           skipOtp: (NSString *)skipOtp
             completionWithHandler: (void (^ _Nonnull)(TSXAuthenticationResult* _Nonnull, TSXAuthenticationError* _Nullable))handler
{
    [self authenticateUserWithUserId:userId
                            policyId:policyId
                             skipOtp:skipOtp
                additionalParameters:NULL
               completionWithHandler:handler];
}

- (void)authenticateUserWithUserId: (NSString *)userId
                          policyId: (NSString *)policyId
                           skipOtp: (NSString *)skipOtp
              additionalParameters: (NSDictionary * _Nullable)additionalParameters
             completionWithHandler: (void (^ _Nonnull)(TSXAuthenticationResult* _Nonnull, TSXAuthenticationError* _Nullable))handler
{
    NSMutableDictionary* mAdditionalParameters = [additionalParameters copy];
    
    // Default value for additionalParameters
    if (skipOtp) {
        [additionalParameters setValue:skipOtp forKey:@"skipOtp"];
    }
    
    // Get the top most presenting viewcontroller to present any authentication ui (GMNA-7900)
    UIViewController *vc = [[ViewController alloc] init];
    NSDictionary *uiHandlerDict = [TSCustomUIHandler createClientContextForPresentingViewController: vc];
    
    [self logoffTransmitWithHandler:^(BOOL res, TSXAuthenticationError * _Nullable err) {
        if(![self.sdk isBoundForUserWithUserId:userId]){
            [self.sdk bindWithUserId:userId
                additionalParameters:mAdditionalParameters
                       clientContext:uiHandlerDict
           asynchronouslyWithHandler:^(TSXAuthenticationResult * _Nonnull result, TSXAuthenticationError * _Nullable error) {
               if (!error) {
                   self.isAuthenticated = YES;
               } else {
                   self.isAuthenticated = NO;
               }
               handler(result, error);
           }];
        }else{
            [self.sdk authenticateWithUserId:userId
                                    policyId:policyId
                        additionalParameters:mAdditionalParameters
                               clientContext:uiHandlerDict
                   asynchronouslyWithHandler:^(TSXAuthenticationResult *result, TSXAuthenticationError *error) {
                       if (!error) {
                           self.isAuthenticated = YES;
                       } else {
                           self.isAuthenticated = NO;
                       }
                       handler(result, error);
                   }];
        }
    }];
}

- (void)handleTransmitStartActivateMSK:(NSDictionary *)functionParams completionWithHandler:(void (^ _Nonnull)(TSXAuthenticationResult* _Nonnull, TSXAuthenticationError* _Nullable))handler {
    
    NSString *username = [functionParams objectForKey:@"username"];
    NSString *policyId = [functionParams objectForKey:@"policyId"];
    NSString *skipOtp  = [functionParams objectForKey:@"skipOtp"];
    
    [self logoffTransmitWithHandler:^(BOOL res, TSXAuthenticationError * _Nullable err) {
        [self.sdk clearAllData];
        [self authenticateUserWithUserId:username policyId:policyId skipOtp:skipOtp completionWithHandler:^(TSXAuthenticationResult * _Nonnull result, TSXAuthenticationError * _Nullable error) {
            handler(result, error);
        }];
    }];
}

- (void)handleTransmitSetOTPRegister:(NSDictionary *)functionParams completionWithHandler:(void (^ _Nonnull)(TSXAuthenticationResult* _Nonnull, TSXAuthenticationError* _Nullable))handler {
    
    NSString *username = [functionParams objectForKey:@"username"];
    NSString *tsOtp = [functionParams objectForKey:@"securityCode"];
    NSString *policyId = [functionParams objectForKey:@"policyId"];
    NSString *password = [functionParams objectForKey:@"password"];
    
    self.customUIHandler.tsOtp = tsOtp;
    self.customUIHandler.currentAuthenticator = tsAuthenticatorTypeOtp;
    
    if (self.isAuthenticated) {
        [self.sdk invokePolicyWithPolicyId:policyId additionalParameters:@{} clientContext:@{} asynchronouslyWithHandler:^(TSXAuthenticationResult * _Nonnull result, TSXAuthenticationError * _Nullable error) {
            handler(result, error);
        }];
    } else {
        [self authenticateUserWithUserId:username policyId:policyId completionWithHandler:^(TSXAuthenticationResult * _Nonnull result, TSXAuthenticationError * _Nullable error) {
            handler(result, error);
        }];
    }
}

- (void)processHandleTransmitCreatePin:(NSDictionary *)functionParams completionWithHandler:(void (^ _Nonnull)(TSXAuthenticationResult* _Nonnull, TSXAuthenticationError* _Nullable))handler {
    
    NSString *username = [functionParams objectForKey:@"username"];
    NSString *tsPin = [functionParams objectForKey:@"pin"];
    NSString *policyId = [functionParams objectForKey:@"policyId"];
    
    self.customUIHandler.tsPin = tsPin;
    self.customUIHandler.currentAuthenticator = tsAuthenticatorTypePincode;
    
    [self.sdk invokePolicyWithPolicyId:policyId additionalParameters:@{} clientContext:@{} asynchronouslyWithHandler:^(TSXAuthenticationResult * _Nonnull result, TSXAuthenticationError * _Nullable error) {
        handler(result, error);
    }];
}

- (void)handleTransmitSetFingerPrint:(NSDictionary *)functionParams tsPrompt:(NSString *)prompt completionWithHandler:(void (^ _Nonnull)(TSXAuthenticationResult* _Nonnull, TSXAuthenticationError* _Nullable))handler {

    self.customUIHandler.tsPrompt = prompt;
    NSString *policyId = [functionParams objectForKey:@"policyId"];
    
    //[TouchIDUtil setTouchIDRuningFlag:YES];
    [self.sdk invokePolicyWithPolicyId:policyId additionalParameters:@{} clientContext:@{@"functionName": @"SetFingerPrint"} asynchronouslyWithHandler:^(TSXAuthenticationResult * _Nonnull result, TSXAuthenticationError * _Nullable error) {
        //[TouchIDUtil setTouchIDRuningFlag:NO];
        handler(result, error);
    }];
}

- (void)handleTransmitGetMobileAuthActivatedDevices:(NSDictionary *)functionParams completionWithHandler:(void (^ _Nonnull)(BOOL,NSArray* _Nullable, TSXAuthenticationError* _Nullable))handler {
    
    NSString *policyId = [functionParams objectForKey:@"policyId"];
    
    [self.sdk invokePolicyWithPolicyId:policyId additionalParameters:@{} clientContext:@{} asynchronouslyWithHandler:^(TSXAuthenticationResult * _Nonnull res, TSXAuthenticationError * _Nullable err) {
        handler(res, self.deviceList, err);
    }];
}

- (void)handleTransmitLogonBySMK:(NSDictionary *)functionParams completionWithHandler:(void (^ _Nonnull)(TSXAuthenticationResult* _Nonnull, TSXAuthenticationError* _Nullable))handler {
    
    NSString *Authenticator = [functionParams objectForKey:@"Authenticator"];
    NSString *pin = [functionParams objectForKey:@"pin"];
    NSString *prompt = [functionParams objectForKey:@"prompt"];
    NSString *username = [self.sdk getBoundUserIds].lastObject;
    
    
    if ([Authenticator isEqualToString:@"Fingerprint"]) {
        self.customUIHandler.currentAuthenticator = AuthenticatorTypeFingerprint;
    } else if ([Authenticator isEqualToString:@"Pin"]) {
        self.customUIHandler.currentAuthenticator = AuthenticatorTypePincode;
    } else if ([Authenticator isEqualToString:@"FaceId"]) {
        self.customUIHandler.currentAuthenticator = AuthenticatorTypeFaceID;
    } else {
        
    }
    
    self.customUIHandler.tsPin = pin;
    self.customUIHandler.tsPrompt = prompt;
    
    //[TouchIDUtil setTouchIDRuningFlag:YES];
    [self authenticateUserWithUserId:username policyId:nil completionWithHandler:^(TSXAuthenticationResult * _Nonnull result, TSXAuthenticationError * _Nullable error) {
        //[TouchIDUtil setTouchIDRuningFlag:NO];
        handler(result, error);
    }];
}

- (void)handleTransmitResetPin:(NSDictionary *)functionParams completionWithHandler:(void (^ _Nonnull)(TSXAuthenticationResult* _Nonnull, TSXAuthenticationError* _Nullable))handler {
    
    NSString *username = [functionParams objectForKey:@"username"];
    NSString *password = [functionParams objectForKey:@"password"];
    NSString *policyId = [functionParams objectForKey:@"policyId"];
    
    self.customUIHandler.tsPassword = password;
    [self.sdk invokePolicyWithPolicyId:policyId additionalParameters:@{} clientContext:@{} asynchronouslyWithHandler:^(TSXAuthenticationResult * _Nonnull result, TSXAuthenticationError * _Nullable error) {
        handler(result, error);
    }];
}

- (void)handleTransmitVerifyOtpPwd:(NSDictionary *)functionParams completionWithHandler:(void (^ _Nonnull)(TSXAuthenticationResult* _Nonnull, TSXAuthenticationError* _Nullable))handler {
    
    NSString *password = [functionParams objectForKey:@"password"];
    NSString *securityCode = [functionParams objectForKey:@"securityCode"];
    NSString *policyId = [functionParams objectForKey:@"policyId"];
    
    // GT amend
    NSString *deviceId = [functionParams objectForKey:@"deviceId"];
    NSString *metaInfo = [functionParams objectForKey:@"metaInfo"];
    NSString *language = [functionParams objectForKey:@"language"];
    
    self.customUIHandler.tsOtp = securityCode;
    self.customUIHandler.tsPassword = password;
    [self.sdk invokePolicyWithPolicyId:policyId
                  additionalParameters:@{
                                         @"deviceId": deviceId ?: [NSNull null],
                                         @"metaInfo": metaInfo ?: [NSNull null],
                                         @"language": language ?: [NSNull null]
                                         }
                         clientContext:@{}
             asynchronouslyWithHandler:^(TSXAuthenticationResult * _Nonnull res, TSXAuthenticationError * _Nullable err)
    {
        handler(res, err);
    }];
}

- (void)handleTransmitGetTouchIDAuthID:(NSDictionary *)functionParams completionWithHandler:(void (^ _Nonnull)(TSXAuthenticationResult* _Nonnull, TSXAuthenticationError* _Nullable))handler {
    
    NSString *username = [functionParams objectForKey:@"username"];
    NSString *policyId = [functionParams objectForKey:@"policyId"];
    
    if (self.isAuthenticated) {
        [self.sdk invokePolicyWithPolicyId:policyId additionalParameters:@{} clientContext:@{} asynchronouslyWithHandler:^(TSXAuthenticationResult * _Nonnull result, TSXAuthenticationError * _Nullable error) {
            handler(result, error);
        }];
    } else {
        [self authenticateUserWithUserId:username policyId:policyId completionWithHandler:^(TSXAuthenticationResult * _Nonnull result, TSXAuthenticationError * _Nullable error) {
            handler(result, error);
        }];
    }
}

- (void)handleTransmitLogonByBiometric:(NSDictionary *)functionParams completionWithHandler:(void (^ _Nonnull)(TSXAuthenticationResult* _Nonnull, TSXAuthenticationError* _Nullable))handler {
    NSString *authid = [functionParams objectForKey:@"authid"];
    NSString *deviceid = [functionParams objectForKey:@"deviceid"];
    NSString *policyId = [functionParams objectForKey:@"policyId"];
    NSString *prompt = [functionParams objectForKey:@"prompt"];
    NSString *userid = [functionParams objectForKey:@"userid"];
    
    NSString *signcode = [functionParams objectForKey:@"signcode"];
    
    NSDictionary *params = @{
                             @"password" : signcode,
                             @"authid" : authid,
                             @"deviceid" : deviceid,
                             @"userid" : userid,
                             @"prompt" : prompt,
                             @"openAMCookie" : self.openAMCookie
                             };
    
    [self.sdk invokePolicyWithPolicyId:policyId
                  additionalParameters: params
                         clientContext:@{}
             asynchronouslyWithHandler:^(TSXAuthenticationResult * _Nonnull res, TSXAuthenticationError * _Nullable err) {
        handler(res, err);
    }];
}

- (void)phandleTransmitDeactivate:(NSDictionary *)functionParams completionWithHandler:(void (^ _Nonnull)(BOOL, TSXAuthenticationError* _Nullable))handler {
    NSString *device_id = [functionParams objectForKey:@"device_id"];
    self.removeDeviceID = device_id;
    
    [self.sdk startDeviceManagementSessionWithClientContext:@{@"function":@"deactivate_other_device_msk"} asynchronouslyWithHandler:^(BOOL result, TSXAuthenticationError * _Nullable error) {
        handler(result, error);
    }];
}

- (void)handleTransmitDeactivateFingerprint:(NSDictionary *)functionParams completionWithHandler:(void (^ _Nonnull)(TSXAuthenticationResult* _Nonnull, TSXAuthenticationError* _Nullable))handler {
    
    NSString *policyId = [functionParams objectForKey:@"policyId"];
    
    //BOOL userLogoned = [LegacyLogonBridgeHandler getUserIsLogon];
    BOOL userLogoned = YES;
    if (userLogoned && self.isAuthenticated) {
        [self.sdk invokePolicyWithPolicyId:policyId additionalParameters:@{} clientContext:@{} asynchronouslyWithHandler:^(TSXAuthenticationResult * _Nonnull reslut, TSXAuthenticationError * _Nullable error) {
            handler(reslut, error);
        }];
    } else {
        [self logoffTransmitWithHandler:^(BOOL res, TSXAuthenticationError * _Nullable err) {
            [self.sdk authenticateWithUserId:[self getBoundUserIds].lastObject policyId:policyId additionalParameters:@{} clientContext:@{} asynchronouslyWithHandler:^(TSXAuthenticationResult * _Nonnull result, TSXAuthenticationError * _Nullable error) {
                handler(result, error);
            }];
        }];
        
    }
}

- (void)handleTransmitDeactivateCurrentDeviceMSKCompletionWithHandler:(void (^ _Nonnull)(BOOL, TSXAuthenticationError* _Nullable))handler {
    
    [self restartSessionWithCompletionHandler:^(TSXAuthenticationResult *result, TSXAuthenticationError * _Nullable error) {
        [self.sdk startDeviceManagementSessionWithClientContext:@{@"function":@"deactivate_current_device_msk"} asynchronouslyWithHandler:^(BOOL result, TSXAuthenticationError * _Nullable error) {
            handler(result, error);
        }];
    }];
}

- (void)handleTransmitIsParamsInvalid:(NSDictionary *)functionParams completionWithHandler:(void (^ _Nonnull)(TSXAuthenticationResult* _Nonnull, TSXAuthenticationError* _Nullable))handler {
    
    NSString *username = [functionParams objectForKey:@"username"];
    NSString *policyId = [functionParams objectForKey:@"policyId"];
    
    if (self.isAuthenticated) {
        [self.sdk invokePolicyWithPolicyId:policyId additionalParameters:@{} clientContext:@{} asynchronouslyWithHandler:^(TSXAuthenticationResult * _Nonnull result, TSXAuthenticationError * _Nullable error) {
            handler(result, error);
        }];
    } else {
        [self authenticateUserWithUserId:username policyId:policyId completionWithHandler:^(TSXAuthenticationResult * _Nonnull result, TSXAuthenticationError * _Nullable error) {
            handler(result, error);
        }];
    }
}

- (void)handleTransmitDeactivateMSKPIN:(NSDictionary *)functionParams completionWithHandler:(void (^ _Nonnull)(TSXAuthenticationResult* _Nonnull, TSXAuthenticationError* _Nullable))handler {
    
    [self restartSessionWithCompletionHandler:^(TSXAuthenticationResult *result, TSXAuthenticationError * _Nullable error) {
        NSString *policyId = [functionParams objectForKey:@"policyId"];
        NSString *deviceId = [functionParams objectForKey:@"deviceId"];
        NSString *isCurrentDevice = [functionParams objectForKey:@"isCurrentDevice"];
        if ([isCurrentDevice isEqualToString:@"true"]) {
            [self.sdk startDeviceManagementSessionWithClientContext:@{@"function":@"get_current_device_id"} asynchronouslyWithHandler:^(BOOL result, TSXAuthenticationError * _Nullable error) {
                if (error) {
                    handler(nil, error);
                } else {
                    NSDictionary *params = @{@"deviceId" : self.currentDeviceID};
                    if (self.isAuthenticated) {
                        [self.sdk invokePolicyWithPolicyId:policyId additionalParameters:params clientContext:@{} asynchronouslyWithHandler:^(TSXAuthenticationResult * _Nonnull result, TSXAuthenticationError * _Nullable error) {
                            handler(result, error);
                        }];
                    } else {
                        [self.sdk authenticateWithUserId:[self getBoundUserIds].lastObject policyId:policyId additionalParameters:params clientContext:@{} asynchronouslyWithHandler:^(TSXAuthenticationResult * _Nonnull result, TSXAuthenticationError * _Nullable error) {
                            handler(result, error);
                        }];
                    }
                }
            }];
        } else {
            NSDictionary *params = @{@"deviceId" : deviceId};
            if (self.isAuthenticated) {
                [self.sdk invokePolicyWithPolicyId:policyId additionalParameters:params clientContext:@{} asynchronouslyWithHandler:^(TSXAuthenticationResult * _Nonnull result, TSXAuthenticationError * _Nullable error) {
                    handler(result, error);
                }];
            } else {
                [self.sdk authenticateWithUserId:[self getBoundUserIds].lastObject policyId:policyId additionalParameters:params clientContext:@{} asynchronouslyWithHandler:^(TSXAuthenticationResult * _Nonnull result, TSXAuthenticationError * _Nullable error) {
                    handler(result, error);
                }];
            }
        }
    }];
}

- (void)handleTransmitRenameDevice:(NSDictionary *)functionParams completionWithHandler:(void (^ _Nonnull)(BOOL, TSXAuthenticationError* _Nullable))handler {
    
    [self.sdk invokePolicyWithPolicyId:@"TokenlessPoc" additionalParameters:@{} clientContext:@{} asynchronouslyWithHandler:^(TSXAuthenticationResult * _Nonnull result, TSXAuthenticationError * _Nullable error) {
        NSLog(@"%@",result);
        //handler(result, error);
    }];
    
    [self.sdk startDeviceManagementSessionWithClientContext:@{@"function":@"rename_current_device"} asynchronouslyWithHandler:^(BOOL result, TSXAuthenticationError * _Nullable error) {
        handler(result, error);
    }];
}

- (void)handleTransmitGet8DigitNumber:(NSDictionary *)functionParams completionWithHandler:(void (^ _Nonnull)(TSXAuthenticationResult* _Nonnull, TSXAuthenticationError* _Nullable))handler {
    
    NSString *policyId = [functionParams objectForKey:@"policyId"];
    
    [self.sdk invokePolicyWithPolicyId:policyId additionalParameters:@{} clientContext:@{} asynchronouslyWithHandler:^(TSXAuthenticationResult * _Nonnull res, TSXAuthenticationError * _Nullable err) {
        handler(res, err);
    }];
}

- (void)handleTransmitDeviceIsRegister:(NSDictionary *)functionParams completionWithHandler:(void (^ _Nonnull)(TSXAuthenticationResult* _Nonnull, TSXAuthenticationError* _Nullable))handler {
    
    NSString *username = self.getBoundUserIds.lastObject;
    NSString *policyId = [functionParams objectForKey:@"policyId"];
    
//    BOOL userLogoned = [LegacyLogonBridgeHandler getUserIsLogon];
//    if (userLogoned && self.isAuthenticated) {
    if (self.isAuthenticated) {
        [self.sdk invokePolicyWithPolicyId:policyId additionalParameters:@{} clientContext:@{} asynchronouslyWithHandler:^(TSXAuthenticationResult * _Nonnull result, TSXAuthenticationError * _Nullable error) {
            if (error.errorCode == AuthenticationErrorCodeSessionRequired) {
                [self authenticateUserWithUserId:username policyId:policyId completionWithHandler:^(TSXAuthenticationResult * _Nonnull result, TSXAuthenticationError * _Nullable error) {
                    handler(result, error);
                }];
            } else {
                handler(result, error);
            }
        }];
    } else {
        [self authenticateUserWithUserId:username policyId:policyId completionWithHandler:^(TSXAuthenticationResult * _Nonnull result, TSXAuthenticationError * _Nullable error) {
            handler(result, error);
        }];
    }
}

- (void)handletransmitCheckExpried:(NSDictionary *)functionParams completionWithHandler:(void (^ _Nonnull)(BOOL, TSXAuthenticationError* _Nullable))handler {
    
    [self handleApproveWithClientContext:@{@"function" : @"TransmitCheckExpried"} completionWithHandler:^(BOOL result, TSXAuthenticationError * _Nullable error) {
        handler(result, error);
    }];
}

- (void)handleTransmitApprove:(NSDictionary *)functionParams completionWithHandler:(void (^ _Nonnull)(BOOL, TSXAuthenticationError* _Nullable))handler {
    
    NSString *Authenticator = [functionParams objectForKey:@"Authenticator"];
    NSString *pin = [functionParams objectForKey:@"pin"];
    NSString *prompt = [functionParams objectForKey:@"prompt"];
    NSString *username = [self.sdk getBoundUserIds].lastObject;
    
    if ([Authenticator isEqualToString:@"Fingerprint"]) {
        self.customUIHandler.currentAuthenticator = AuthenticatorTypeFingerprint;
    } else if ([Authenticator isEqualToString:@"Pin"]) {
        self.customUIHandler.currentAuthenticator = AuthenticatorTypePincode;
    } else if ([Authenticator isEqualToString:@"FaceId"]) {
        self.customUIHandler.currentAuthenticator = AuthenticatorTypeFaceID;
    } else {
        
    }
    
    self.customUIHandler.tsPin = pin;
    self.customUIHandler.tsPrompt = prompt;
    
    //[TouchIDUtil setTouchIDRuningFlag:YES];
    [self handleApproveWithClientContext:@{@"function" : @"TransmitApprove"} completionWithHandler:^(BOOL result, TSXAuthenticationError * _Nullable error) {
        //[TouchIDUtil setTouchIDRuningFlag:NO];
        handler(result, error);
    }];
}

- (void)handleTransmitDoNotApprove:(NSDictionary *)functionParams completionWithHandler:(void (^ _Nonnull)(BOOL, TSXAuthenticationError* _Nullable))handler {
    
    [self handleApproveWithClientContext:@{@"function" : @"TransmitDoNotApprove"} completionWithHandler:^(BOOL result, TSXAuthenticationError * _Nullable error) {
        handler(result, error);
    }];
}

- (void)handleTransmitCheckNotification:(NSDictionary *)functionParams completionWithHandler:(void (^ _Nonnull)(BOOL, TSXAuthenticationError* _Nullable))handler {
    
    [self handleApproveWithClientContext:@{@"function" : @"TransmitCheckNotification"} completionWithHandler:^(BOOL result, TSXAuthenticationError * _Nullable error) {
        handler(result, error);
    }];
}

- (void)handleTransmitRefreshApproveStatus:(NSDictionary *)functionParams completionWithHandler:(void (^ _Nonnull)(BOOL, TSXAuthenticationError* _Nullable))handler {

    [self handleApproveWithClientContext:@{@"function" : @"RefreshApproveStatus"} completionWithHandler:^(BOOL result, TSXAuthenticationError * _Nullable error) {
        handler(result, error);
    }];
}

- (void)handleApproveWithClientContext:(NSDictionary *)context completionWithHandler:(void (^ _Nonnull)(BOOL result, TSXAuthenticationError* _Nullable error))handler {
    NSString *boundUserId = self.getBoundUserIds.lastObject;
    if (self.isAuthenticated) {
        [self.sdk startApprovalsSessionForCurrentSessionWithClientContext:context asynchronouslyWithHandler:^(BOOL result, TSXAuthenticationError * _Nullable error) {
            handler(result, error);
        }];
    } else {
        TSXMobileApprovePushRequestPayload *payload = [TSXMobileApprovePushRequestPayload createWithUserIdWithUserId: boundUserId];
        [self.sdk startApprovalsSessionForPushedRequestWithPushRequestPayload:payload clientContext:context asynchronouslyWithHandler:^(BOOL result, TSXAuthenticationError * error){
            handler(result, error);
        }];
    }
}

// Desktop payment TDS authentication - start
- (void)handleTransmitDesktopTDSApproveIsFaceId: (BOOL)isFaceId
                                  promptMessage: (NSString *)message
                                  clientContext: (NSDictionary *)clientContext
                            completeWithHandler: (void (^ _Nonnull)(TSXAuthenticationResult *_Nullable, TSXAuthenticationError* _Nullable))handler {
    if (isFaceId) {
        self.customUIHandler.currentAuthenticator = AuthenticatorTypeFaceID;
    }
    else {
        self.customUIHandler.currentAuthenticator = AuthenticatorTypeFingerprint;
    }
    
    self.customUIHandler.tsPrompt = message;
    
    //[TouchIDUtil setTouchIDRuningFlag:YES];
    [self startApproveSession:clientContext completionWithHandler:^(BOOL result, TSXAuthenticationError * _Nullable error) {
        //[TouchIDUtil setTouchIDRuningFlag:NO];
        handler(nil, error);
    }];
}

- (void)handleTransmitDesktopTDSApproveWithPin: (NSString *)pin
                                  clientContext: (NSDictionary *)clientContext
                            completeWithHandler: (void (^ _Nonnull)(TSXAuthenticationResult * _Nullable, TSXAuthenticationError* _Nullable))handler {
    self.customUIHandler.currentAuthenticator = tsAuthenticatorTypePincode;
    self.customUIHandler.tsPin = pin;
    
    [self startApproveSession:clientContext completionWithHandler:^(BOOL result, TSXAuthenticationError * _Nullable error) {
        handler(nil, error);
    }];
}

- (void)handleDoNotApproveWithClientContext: (NSDictionary *)context
                        CompleteWithHandler: (void (^ _Nonnull)(BOOL, TSXAuthenticationError* _Nullable))handler {
    
    [self startApproveSession:context completionWithHandler:^(BOOL result, TSXAuthenticationError * _Nullable error) {
        handler(result, error);
    }];
}

- (void)handleRefreshTransmitApprovalWithClientContext: (NSDictionary *)context
                                   CompleteWithHandler: (void (^ _Nonnull)(BOOL, TSXAuthenticationError* _Nullable))handler {
    
    [self startApproveSession:context completionWithHandler:^(BOOL result, TSXAuthenticationError * _Nullable error) {
        handler(result, error);
    }];
}

- (void)startApproveSession:(NSDictionary *)context completionWithHandler:(void (^ _Nonnull)(BOOL result, TSXAuthenticationError* _Nullable error))handler {
    NSString *boundUserId = self.getBoundUserIds.lastObject;
    if (self.isAuthenticated) {
        [self.sdk startApprovalsSessionForCurrentSessionWithClientContext:context asynchronouslyWithHandler:^(BOOL result, TSXAuthenticationError * _Nullable error) {
            handler(result, error);
        }];
    } else {
        TSXMobileApprovePushRequestPayload *payload = [TSXMobileApprovePushRequestPayload createWithUserIdWithUserId: boundUserId];
        [self.sdk startApprovalsSessionForPushedRequestWithPushRequestPayload:payload clientContext:context asynchronouslyWithHandler:^(BOOL result, TSXAuthenticationError * _Nullable error){
            handler(result, error);
        }];
    }
}
// Desktop payment TDS authentication - end


// MARK: - For TDS
- (void)handleTransmitBiometricDigitalSigningIsFaceId: (BOOL)isFaceId
                                     andPromptMessage: (NSString *)message
                                           withParams: (NSDictionary *)params
                               andCompleteWithHandler: (void (^ _Nonnull)(TSXAuthenticationResult* _Nonnull, TSXAuthenticationError* _Nullable))handler
{
    NSString *username = [self.sdk getBoundUserIds].lastObject;
    
    if (isFaceId) {
        self.customUIHandler.currentAuthenticator = AuthenticatorTypeFaceID;
    }
    else {
        self.customUIHandler.currentAuthenticator = AuthenticatorTypeFingerprint;
    }
    
    self.customUIHandler.tsPrompt = message;
    
    /*
     @{
     @"creditAccount": @"123456",
     @"debitAccount": @"123456",
     @"amount": @"123456"
     }
     */
    
    //[TouchIDUtil setTouchIDRuningFlag:YES];
    [self authenticateUserWithUserId: username
                            policyId: @"TDS-Mobile"
                             skipOtp: NULL
                additionalParameters: params
               completionWithHandler: ^(TSXAuthenticationResult * result, TSXAuthenticationError * error) {
                                //[TouchIDUtil setTouchIDRuningFlag:NO];
                                handler(result, error);   
               }];
    
//    [TouchIDUtil setTouchIDRuningFlag:YES];
//    [self.sdk invokePolicyWithPolicyId:@"TDS-Mobile"
//                  additionalParameters:params
//                         clientContext:@{}
//             asynchronouslyWithHandler:^(TSXAuthenticationResult * result, TSXAuthenticationError * error) {
//                 [TouchIDUtil setTouchIDRuningFlag:NO];
//                 handler(result, error);
//             }];
}

- (void)handleTransmitMSKDigitalSigningWithPin: (NSString *)pin
                                    withParams: (NSDictionary *)params
                        andCompleteWithHandler: (void (^ _Nonnull)(TSXAuthenticationResult* _Nonnull, TSXAuthenticationError* _Nullable))handler
{
    NSString *username = [self.sdk getBoundUserIds].lastObject;
    
    self.customUIHandler.currentAuthenticator = tsAuthenticatorTypePincode;
    self.customUIHandler.tsPin = pin;
    
    [self authenticateUserWithUserId: username
                            policyId: @"TDS-Mobile"
                             skipOtp: NULL
                additionalParameters: params
               completionWithHandler: handler];
}

- (void)handleTransmitParameter:(NSString *)parameter completionWithHandler:(void (^ _Nonnull)(TSXAuthenticationResult* _Nonnull, TSXAuthenticationError* _Nullable))handler {
    
    [self.sdk invokePolicyWithPolicyId:parameter additionalParameters:@{} clientContext:@{} asynchronouslyWithHandler:^(TSXAuthenticationResult * _Nonnull result, TSXAuthenticationError * _Nullable error) {
        NSLog(@"%@",result);
        handler(result, error);
    }];
}

@end

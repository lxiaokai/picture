//
//  TSXApprovalsSession.h
//  TSXDemo
//
//  Created by Sletean Inbar on 11/07/2018.
//  Copyright © 2018 Transmit Security LTD. All rights reserved.
//
#import "SDK3.h"

@interface TSXApprovalsSession : TSXUIApprovalsSession

@end

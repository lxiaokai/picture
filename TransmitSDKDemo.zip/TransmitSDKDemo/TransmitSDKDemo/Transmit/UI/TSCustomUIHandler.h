//
//  TSCustomUIHandler.h
//  HSBCHybrid
//
//  Created by Janice on 2018/1/16.
//
//

#import <TransmitSDK3/TransmitSDK3.h>
//#import <TransmitSDK3/TSXUIDefaultUIHandler.h>
#import <TransmitSDKUILayer/TSXDefaultUIHandler.h>
#import "TSApprovalSession.h"

@protocol TSCustomUIHandlerDelegate <NSObject>

@optional
-(void)TSCustomUIHandlerCheckExpiredFlag:(NSString *)expiredFlag withService:(TSXApprovalManagementSessionServices *)approvalService withApproval:(TSXManagedMobileApproval*)managedMobileApproval;
@optional
-(void)TSCustomUIHandlerSetAuthenticationList:(NSString *)authenticationList;

//Transmit: add by Manuel on 2018/01/25 for legacy touchId placeholder
@optional
-(void)getContextData:(NSString *)contextData andCurrentHandler:(void (^)(TSXInputOrControlResponse *))currentHandler;
@optional
- (void)getFaceIdContextData:(NSString *)contextData andCurrentHandler:(void (^)(TSXInputOrControlResponse *))currentHandler;
//Transmit: add by Manuel on 2018/04/25 for check authenticator locked status
@optional
-(void)TSCustomUIHandlerCheckLockedStatus:(NSString *)checkStatus withService:(TSXApprovalManagementSessionServices *)approvalService withApproval:(TSXManagedMobileApproval*)managedMobileApproval;
@optional
-(void)TSCheckLockedStatusResult:(NSString *)strResult;

@optional
- (void)getTotpCode:(NSString *)code ttlSeconds:(long)ttlSeconds remainingSeconds:(long)remainingSeconds isEnd:(BOOL)end;

@optional
-(void)TSCustomUIHandlerLocalAuthenticatorInvalidated;

@optional
- (void)transmitHandleDeviceDeactivateNotFound;

@optional
- (void)transmitHandleDeviceManagementWithType:(NSString *)type error:(TSXAuthenticationError *)error;

@optional
- (void)TSApprovalSessionWithType:(NSString *)type error:(TSXAuthenticationError *)error;

@optional
- (void)handleApprovalErrorWithFunctionType:(NSString *)type error:(TSXAuthenticationError *)error;

@end

@interface TSCustomUIHandler : TSXDefaultUIHandler <TSApprovalSessionDelegate>

@property (nonatomic,weak)   id<TSCustomUIHandlerDelegate> delegate;

//Transmit: add by Manuel on 2018/01/25 for legacy touchId placeholder (start)
@property (nonatomic,weak) id<TSCustomUIHandlerDelegate> delegatePlaceholder;
//Transmit: add by Manuel on 2018/01/25 for legacy touchId placeholder (stop)

@property (nonatomic,strong) NSString *tsPassword;
@property (nonatomic,strong) NSString *tsPin;
@property (nonatomic,strong) NSString *tsPrompt;
@property (nonatomic,strong) NSString *tsOtp;
@property (nonatomic,assign) NSUInteger currentAuthenticator;
@property (nonatomic,assign) BOOL tsSetAuthenticationList;
@property (nonatomic,strong) NSString *tsFingerprintStatus;
@property (nonatomic,strong) NSString *tsPinStatus;

@property (nonatomic,strong) NSString *tsCheckLockedStatusFlag;
@property (nonatomic,strong) NSString *tsAmtokenInvalidStatusFlag;
@property (nonatomic,strong) NSString *tsPinAlreadyActivatedStatusFlag;
@end

//
//  TSPinInputSession.m
//  HSBCHybrid
//  Created by [Manuel L M Zhang] on 07/12/2017.
//  Copyright © 2017 HSBC. All rights reserved.
//

#import "TSPinInputSession.h"

@implementation TSPinInputSession
@synthesize tsPin;
@synthesize tsPinDescription;

-(void)startSessionWithDescription:(TSXAuthenticatorDescription* _Nonnull)description mode:(TSXAuthenticatorSessionMode)mode actionContext:(TSXPolicyAction* _Nullable)actionContext clientContext:(NSDictionary * _Nullable)clientContext {
    
//    if(mode == AuthenticatorSessionModeAuthentication){
//
//    }else if(mode == AuthenticatorSessionModeRegistration){
//
//    }
    
    tsPinDescription = description;
}

-(void)promiseInputAsynchronouslyWithHandler:(void (^)(TSXInputOrControlResponse<TSXPasswordInput*> *))handler {
    
    self.currentHandler = handler;
    
    self.currentHandler([TSXInputOrControlResponse createInputResponseWithInputResponse:[TSXPinInput createWithPin:tsPin]]);
}

//Transmit: add by Manuel on 20180212 to handle the error case exceptional flow
-(void)promiseRecoveryForErrorWithError:(TSXAuthenticationError *)error validRecoveries:(TSXAuthenticationErrorRecoverySet)validRecoveries defaultRecovery:(TSXAuthenticationErrorRecovery)defaultRecovery asynchronouslyWithHandler:(void (^)(TSXAuthenticationErrorRecovery))handler {
    
    //handler(defaultRecovery);
    handler(AuthenticationErrorRecoveryFail);
}

-(void)changeSessionModeToRegistrationAfterExpiration {
    //for expiration
}

-(void)endSession {
    NSLog(@"endSession:%d",tsPinDescription.locked);
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    NSString *tsPinLockStatus = @"FALSE";
    if (tsPinDescription.locked){
        if (tsPinDescription.locked == 0) {
            tsPinLockStatus = @"FALSE";
        }else if (tsPinDescription.locked == 1){
            tsPinLockStatus = @"TRUE";
            //Transmit: add by Manuel to synchronize the flag for checklockedstatus hook
            [[NSUserDefaults standardUserDefaults] setObject:@"locked" forKey:@"pinStatusTS"];
        }
    }
    [userDefault setObject:tsPinLockStatus forKey:@"tsPinLockStatus"];
}

@end

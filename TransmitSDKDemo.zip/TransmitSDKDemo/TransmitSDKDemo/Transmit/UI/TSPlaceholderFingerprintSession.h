//
//  TSPlaceholderFingerprintSession.h
//  HSBCHybrid
//
//  Created by [Manuel L M Zhang] on 07/12/2017.
//  Copyright © 2017 HSBC. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <TransmitSDK3/TransmitSDKXm.h>

@protocol TsPldFpSesnDelegate <NSObject>

- (void)getContextData:(NSString *)contextData andCurrentHandler:(void (^)(TSXInputOrControlResponse *))currentHandler;

@end

@interface TSPlaceholderFingerprintSession : TSXUIAuthenticatorSession<TSXPlaceholderInputResponse *>

@property (strong, nonatomic) void (^currentHandler)(TSXInputOrControlResponse *);

@property (nonatomic,weak) id<TsPldFpSesnDelegate> delegate;

@property (strong, nonatomic) NSString *userName;
@property (strong, nonatomic) NSString *serverPayload;

@end

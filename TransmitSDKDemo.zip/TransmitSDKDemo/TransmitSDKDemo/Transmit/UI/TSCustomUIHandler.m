//
//  TSCustomUIHandler.m
//  HSBCHybrid
//
//  Created by Janice on 2018/1/16.
//
//

#import "TSCustomUIHandler.h"
#import "TSPasswordInputSession.h"
#import "TSPinInputSession.h"
#import "TSFingerprintInputSession.h"
#import "TSOtpSession.h"
//Transmit: add by Manuel on 2018/01/25
#import "TSPlaceholderFingerprintSession.h"
#import "TSDeviceManagementSession.h"
#import "TSNativeFaceInputSession.h"
#import "TSPlacehoderFaceIdSession.h"
#import "TSTotpGenerationSession.h"

#import "TransmitHelper.h"

@interface TSCustomUIHandler () <TSPlacehoderFaceIdSessionDelegate, TsPldFpSesnDelegate, TSTotpGenerationSessionDelegate>

@end

@implementation TSCustomUIHandler

@synthesize tsPassword;
@synthesize tsPin;
@synthesize tsPrompt;
@synthesize tsOtp;
@synthesize currentAuthenticator;
@synthesize tsSetAuthenticationList;
@synthesize tsCheckLockedStatusFlag;
@synthesize tsFingerprintStatus;
@synthesize tsPinStatus;
@synthesize tsAmtokenInvalidStatusFlag;
@synthesize tsPinAlreadyActivatedStatusFlag;


//Transmit: add by Manuel on 20180125 to rewrite the method for avoiding the default loading view
-(void)startActivityIndicatorWithActionContext:(TSXPolicyAction *)actionContext clientContext:(NSDictionary *)clientContext {
	// show network indicator
    [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:YES];
    NSLog(@"%@",clientContext);
    //TSXClientContextKeyDefaultUIHandlerHostingContext = "<TSXDefaultUIHandlerHostingContext: 0x600000c34d70>";
    //[TSXDefaultUIHandler hostingContextFromClientContext:clientContext].activityIndicator.hidden = NO;
}

-(void)endActivityIndicatorWithActionContext:(TSXPolicyAction *)actionContext clientContext:(NSDictionary *)clientContext {
	// hide network indicator
    [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:NO];
    //[TSXDefaultUIHandler hostingContextFromClientContext:clientContext].activityIndicator.hidden = YES;
}

-(TSXUIAuthenticatorSession<TSXPasswordInput *> *)createPasswordAuthSessionWithTitle:(NSString *)title username:(NSString *)username {
	TSPasswordInputSession *tsPasswordInputSession = [[TSPasswordInputSession alloc] init];
	tsPasswordInputSession.tsPassword = tsPassword;
	return tsPasswordInputSession;
}

-(TSXUIAuthenticatorSession<TSXPinInput *> *)createPinAuthSessionWithTitle:(NSString *)title username:(NSString *)username pinLength:(long)pinLength {
	TSPinInputSession *tsPinInputSession = [[TSPinInputSession alloc] init];
	tsPinInputSession.tsPin = tsPin;
	return tsPinInputSession;
}

-(TSXUIAuthenticatorSession<TSXFingerprintInput *> *)createFingerprintAuthSessionWithTitle:(NSString *)title username:(NSString *)username {
	TSFingerprintInputSession *tsFingerprintInputSession = [[TSFingerprintInputSession alloc] init];
	tsFingerprintInputSession.tsPrompt = tsPrompt;
	return tsFingerprintInputSession;
}

- (TSXUITotpGenerationSession *)createTotpGenerationSessionWithUserId:(NSString *)userId generatorName:(NSString *)generatorName {
	TSTotpGenerationSession *generationSession = [[TSTotpGenerationSession alloc] init];
	generationSession.delegate = self;
	return generationSession;
}

- (void)TSTotpGenerationSssionSetCode:(NSString *)code ttlSeconds:(long)ttlSeconds remainingSeconds:(long)remainingSeconds isEnd:(BOOL)end {
	if ([self.delegate respondsToSelector:@selector(getTotpCode:ttlSeconds:remainingSeconds:isEnd:)]) {
		[self.delegate getTotpCode:code ttlSeconds:ttlSeconds remainingSeconds:remainingSeconds isEnd:end];
	}
}

-(TSXUIAuthenticatorSession<TSXNativeFaceInput*>* _Null_unspecified)createNativeFaceAuthSessionWithTitle:(NSString* _Nonnull)title username:(NSString* _Nonnull)username {
	TSNativeFaceInputSession *faceInputSession = [[TSNativeFaceInputSession alloc] init];
	faceInputSession.tsPrompt = tsPrompt;
	return faceInputSession;
}

-(TSXUIAuthenticatorSessionOtp *)createOtpAuthSessionWithTitle:(NSString *)title username:(NSString *)username possibleTargets:(NSArray<TSXOtpTarget *> *)possibleTargets autoExecedTarget:(TSXOtpTarget *)autoExecedTarget {
	TSOtpSession *tsOtpSession = [[TSOtpSession alloc] init];
	//Transmit: add by Manuel on 20180326 with updated api of the sdk
	tsOtpSession.availableTargets = possibleTargets;
	tsOtpSession.possibleTargets = possibleTargets;
	tsOtpSession.autoExecedTarget = autoExecedTarget;
	tsOtpSession.tsOtp = tsOtp;
	return tsOtpSession;
}

//Transmit: add by Manuel on 2018/01/25 (Legacy TouchId placeholder)
-(TSXUIAuthenticatorSession<TSXPlaceholderInputResponse *> *)createPlaceholderAuthSessionWithPlaceholderName:(NSString*)placeholderName
																							 placeholderType:(NSString*)placeholderType
																									   title:(NSString*)title
																									username:(NSString*)username
																				 authenticatorConfiguredData:(NSString*)data
																							   serverPayload:(NSString*)serverPayload {
	if([placeholderName isEqualToString:@"idvfingerprint"]) {
		TSPlaceholderFingerprintSession *tsPldFnptSesn = [[TSPlaceholderFingerprintSession alloc] init];
		tsPldFnptSesn.userName = username;
		tsPldFnptSesn.serverPayload = serverPayload;
		tsPldFnptSesn.delegate = self;
		NSLog(@"The serverPayload is %@ that as context_data lar", serverPayload);
		return tsPldFnptSesn;
	}
	else if([placeholderName isEqualToString:@"idvfaceid"]) {
		TSPlacehoderFaceIdSession *tsPldFnptSesn = [[TSPlacehoderFaceIdSession alloc] init];
		tsPldFnptSesn.userName = username;
		tsPldFnptSesn.serverPayload = serverPayload;
		tsPldFnptSesn.delegate = self;
		NSLog(@"The serverPayload is %@ that as context_data lar", serverPayload);
		return tsPldFnptSesn;
	}
	else {
		return nil;
	}
}

- (void)getContextData:(NSString *)contextData andCurrentHandler:(void (^)(TSXInputOrControlResponse *))currentHandler {
	[self.delegatePlaceholder getContextData:contextData andCurrentHandler:currentHandler];
}

- (void)getFaceIdContextData:(NSString *)contextData andCurrentHandler:(void (^)(TSXInputOrControlResponse *))currentHandler {
	[self.delegatePlaceholder getFaceIdContextData:contextData andCurrentHandler:currentHandler];
}

-(TSXUIApprovalsSession *)createApprovalsSessionWithUserId:(NSString *)userId {
	TSApprovalSession *tsApprovalSession = [[TSApprovalSession alloc] init];
	tsApprovalSession.delegate = self;
	return tsApprovalSession;
}

//Transmit: add by Manuel on 2018/04/25 for checkLockedStatus delegate method
- (void)TSApprovalSessionCheckLockedStatus:(NSString *)status withService:(TSXApprovalManagementSessionServices *)approvalService withApproval:(TSXManagedMobileApproval *)managedMobileApproval {
	[self.delegate TSCustomUIHandlerCheckLockedStatus:status withService:approvalService withApproval:managedMobileApproval];
}

- (void)TSApprovalSessionCheckExpiredFlag:(NSString *)expiredFlag withService:(TSXApprovalManagementSessionServices *)approvalService withApproval:(TSXManagedMobileApproval *)managedMobileApproval {
	NSLog(@"%@",expiredFlag);
	if([self.delegate respondsToSelector:@selector(TSCustomUIHandlerCheckExpiredFlag:withService:withApproval:)]){
		[self.delegate TSCustomUIHandlerCheckExpiredFlag:expiredFlag withService:approvalService withApproval:managedMobileApproval];
	}
}

//Transmit: add by Manuel that this api had change the actionContext from _Nonnull to _Nullable since v3.3 sdk
-(void)processJsonDataWithJsonData:(NSDictionary * _Nonnull)jsonData actionContext:(TSXPolicyAction* _Nullable)actionContext clientContext:(NSDictionary * _Nullable)clientContext asynchronouslyWithHandler:(void (^ _Nonnull)(TSXJsonDataProcessingResult* _Nonnull))handler {
	NSLog(@"Status: %@",jsonData);
	NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
	if(jsonData != nil){
        if ([[jsonData allKeys] containsObject:@"touchid_frist_response"]) {
            [TransmitHelper sharedInstance].touchidFristResponseBody = [[jsonData objectForKey:@"touchid_frist_response"] objectForKey:@"body"];
            [TransmitHelper sharedInstance].openAMCookie = [jsonData objectForKey:@"openAMCookie"];
        } else if ([[jsonData allKeys] containsObject:@"next_policy"]){
            [TransmitHelper sharedInstance].nextPolicy = [jsonData objectForKey:@"next_policy"];
        } else if ([[jsonData allKeys] containsObject:@"devicesInProvisioned"]){
            [TransmitHelper sharedInstance].currentDeviceID = [jsonData objectForKey:@"current_device_id"];
            [TransmitHelper sharedInstance].devicesInProvisioned = [jsonData objectForKey:@"devicesInProvisioned"];
        } else if ([[jsonData allKeys] containsObject:@"isInProvisioned"]){
            [TransmitHelper sharedInstance].isInProvisioned = [jsonData objectForKey:@"isInProvisioned"];
        } else if ([[jsonData allKeys] containsObject:@"randomNum"]){
            [TransmitHelper sharedInstance].randomNum = [jsonData objectForKey:@"randomNum"];
        }
	} else {
        
	}
	handler([TSXJsonDataProcessingResult createWithContinueProcessing:true]);
}

-(void)localAuthenticatorInvalidatedWithDescription:(TSXAuthenticatorDescription* _Nonnull)description clientContext:(NSDictionary * _Nullable)clientContext asynchronouslyWithHandler:(void (^ _Nonnull)(BOOL))handler {
    NSLog(@"localAuthenticatorInvalidatedWithDescription");
//    if ([self.delegate respondsToSelector:@selector(TSCustomUIHandlerLocalAuthenticatorInvalidated)]) {
//        [self.delegate TSCustomUIHandlerLocalAuthenticatorInvalidated];
//    }
    
    NSString *functionName = [clientContext objectForKey:@"functionName"];
    if ([functionName isEqualToString:@"SetFingerPrint"]) {
        handler(YES);
    } else {
        [TransmitHelper sharedInstance].biometricUpdated = YES;
        [[TransmitHelper sharedInstance] cancelCurrentRunningControlFlow];
        handler(YES);
    }
}

//TransmitSDK: add by Janice at 2018/01/16 Cancel Fingerprint Authenticator
-(void)controlOptionForCancellationRequestInSessionWithValidOptions:(TSXControlRequestTypeSet)validOptions session:(TSXUIAuthenticatorSession<TSXInputResponseType *> *)session asynchronouslyWithHandler:(void (^)(TSXControlRequest * _Nonnull))handler {
	if (validOptions & ControlRequestTypeAbortAuthentication) {
		handler([TSXControlRequest createWithRequestType:ControlRequestTypeAbortAuthentication]);
	}
}

//Transmit: add by Manuel on 20180326 to select Authenticator List with updated api of sdk
-(void)selectAuthenticatorWithOptions:(NSArray<TSXAuthenticationOption *> *)options actionContext:(TSXPolicyAction *)actionContext clientContext:(NSDictionary *)clientContext asynchronouslyWithHandler:(void (^)(TSXAuthenticatorSelectionResult * _Nonnull))handler {
	TSXAuthenticatorDescription *selected = NULL;
	
    for(TSXAuthenticationOption *authOption in options) {
        TSXAuthenticatorDescription *auth = authOption.authenticator;
        NSLog(@"auth.authenticatorId:%@,auth.name:%@",auth.authenticatorId,auth.name);
        if(currentAuthenticator == AuthenticatorTypePassword && [auth.authenticatorId isEqualToString:@"password"] && [auth.name isEqualToString:@"Password"]){
            selected = auth;
            break;
        }else if(currentAuthenticator == AuthenticatorTypePassword && [auth.authenticatorId isEqualToString:@"password"] && [auth.name isEqualToString:@"password"]){// used when setPinPage Hook,push logon,ActivateSOTP
            selected = auth;
            break;
        }else if(currentAuthenticator == AuthenticatorTypeOtp && [auth.authenticatorId isEqualToString:@"otp"] && [auth.name isEqualToString:@"OTP"]){
            selected = auth;
            break;
        }else if(currentAuthenticator == AuthenticatorTypeGeneric && [auth.authenticatorId isEqualToString:@"placeholder_idvfingerprint"] && [auth.name isEqualToString:@"Fingerprint"]){
            selected = auth;
            break;
        }else if(currentAuthenticator == AuthenticatorTypeFingerprint && [auth.authenticatorId isEqualToString:@"fingerprint"] && [auth.name isEqualToString:@"Fingerprint"]){
            selected = auth;
            break;
        }else if(currentAuthenticator == AuthenticatorTypePincode && [auth.authenticatorId isEqualToString:@"pin"] && [auth.name isEqualToString:@"PIN"]){
            selected = auth;
            break;
        }else if(currentAuthenticator == AuthenticatorTypeFaceID && [auth.authenticatorId isEqualToString:@"face_id"] && [auth.name isEqualToString:@"FaceID"]){
            selected = auth;
            break;
        }
        else if(currentAuthenticator == AuthenticatorTypeGeneric && [auth.authenticatorId isEqualToString:@"placeholder_idvfaceid"] && [auth.name isEqualToString:@"FaceID"]){
            selected = auth;
            break;
        }
        
    }
    if(selected != NULL){
        handler([TSXAuthenticatorSelectionResult createSelectionRequestWithSelectedAuthenticator:selected]);
    } else {
        [TransmitHelper sharedInstance].authenticatorNotFound = @"true";
        handler([TSXAuthenticatorSelectionResult createAbortRequest]);
//        handler([TSXAuthenticatorSelectionResult createSelectionRequestWithSelectedAuthenticator:selected]);
    }
}

//Transmit: add by Manuel on 20180425 to rename the device name that would show on desktop
-(TSXUIDeviceManagementSession *)createDeviceManagementSessionWithUserId:(NSString *)userId {
	TSDeviceManagementSession *tsUiDvceMgtSess = [[TSDeviceManagementSession alloc] init];
    tsUiDvceMgtSess.delegate = self;
	return tsUiDvceMgtSess;
}

- (void)transmitHandleDeviceManagementWithType:(NSString *)type error:(TSXAuthenticationError *)error {
    if ([self.delegate respondsToSelector:@selector(transmitHandleDeviceManagementWithType:error:)]) {
        [self.delegate transmitHandleDeviceManagementWithType:type error:error];
    }
}

- (void)TSApprovalSessionWithType:(NSString *)type error:(TSXAuthenticationError *)error {
    if ([self.delegate respondsToSelector:@selector(TSApprovalSessionWithType:error:)]) {
        [self.delegate TSApprovalSessionWithType:type error:error];
    }
}

- (void)handleApprovalErrorWithFunctionType:(NSString *)type error:(TSXAuthenticationError *)error {
    if ([self.delegate respondsToSelector:@selector(handleApprovalErrorWithFunctionType:error:)]) {
        [self.delegate handleApprovalErrorWithFunctionType:type error:error];
    }
}

- (void)transmitHandleDeviceDeactivateNotFound {
    if ([self.delegate respondsToSelector:@selector(transmitHandleDeviceDeactivateNotFound)]) {
        [self.delegate transmitHandleDeviceDeactivateNotFound];
    }
}

-(void)handlePolicyRejectionWithTitle:(NSString *)title text:(NSString *)text buttonText:(NSString *)buttonText failureData:(NSDictionary *)failureData actionContext:(TSXPolicyAction *)actionContext clientContext:(NSDictionary *)clientContext asynchronouslyWithHandler:(void (^)(TSXConfirmationInput * _Nonnull))handler {
	handler([TSXConfirmationInput createWithUserChoice:-1]);
}

// ask for confirmation
//-(void)getConfirmationInputWithTitle:(NSString* _Nonnull)title text:(NSString* _Nonnull)text continueText:(NSString* _Nonnull)continueText cancelText:(NSString* _Nonnull)cancelText actionContext:(TSXPolicyAction* _Nullable)actionContext clientContext:(NSDictionary * _Nullable)clientContext asynchronouslyWithHandler:(void (^ _Nonnull)(TSXConfirmationInput* _Nonnull))handler {
//    handler([TSXConfirmationInput createWithUserChoice:0]);
//}

@end

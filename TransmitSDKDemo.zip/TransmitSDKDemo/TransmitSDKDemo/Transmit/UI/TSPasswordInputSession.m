//
//  TSPasswordInputSession.m
//  HSBCHybrid
//
//  Created by Janice on 2018/1/14.
//
//

#import "TSPasswordInputSession.h"

@implementation TSPasswordInputSession
@synthesize tsPassword;

-(void)startSessionWithDescription:(TSXAuthenticatorDescription *)description mode:(TSXAuthenticatorSessionMode)mode actionContext:(TSXPolicyAction *)actionContext clientContext:(NSDictionary *)clientContext {
    
}

-(void)promiseInputAsynchronouslyWithHandler:(void (^)(TSXInputOrControlResponse * _Nonnull))handler {

    self.currentHandler = handler;
    
    self.currentHandler([TSXInputOrControlResponse createInputResponseWithInputResponse:[TSXPasswordInput createWithPassword:tsPassword]]);
}

-(void)endSession {
    
}

//Transmit: add by Manuel on 20180212 to handle the error case exceptional flow
-(void)promiseRecoveryForErrorWithError:(TSXAuthenticationError *)error validRecoveries:(TSXAuthenticationErrorRecoverySet)validRecoveries defaultRecovery:(TSXAuthenticationErrorRecovery)defaultRecovery asynchronouslyWithHandler:(void (^)(TSXAuthenticationErrorRecovery))handler {
    
    //handler(defaultRecovery);
    handler(AuthenticationErrorRecoveryFail);
}

-(void)changeSessionModeToRegistrationAfterExpiration {
    
}

@end

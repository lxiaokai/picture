//
//  TSDeviceManagementSession.m
//  HSBCHybrid
//
//  Created by [Manuel L M Zhang] on 20180425.
//

#import "TSDeviceManagementSession.h"
#import "TransmitHelper.h"

@interface TSDeviceManagementSession ()

@property (nonatomic, strong) NSArray *devices;

@end

@implementation TSDeviceManagementSession
// 1
-(void)setSessionDevicesList:(NSArray<TSXManagedDevice*> * _Nonnull)devices{
    
    self.devices = devices;
}
// 2
-(void)startSessionWithDeviceManagementSessionServices:(TSXDeviceManagementSessionServices* _Nonnull)deviceManagementSessionServices actionContext:(TSXPolicyAction* _Nullable)actionContext clientContext:(NSDictionary * _Nullable)clientContext{
    
    NSString *function = [clientContext objectForKey:@"function"];
    if ([function isEqualToString:@"deactivate_current_device_msk"]) {
        [deviceManagementSessionServices removeCurrentDeviceAndFinishSessionWithClientContext:@{} asynchronouslyWithHandler:^(BOOL result, TSXAuthenticationError * _Nullable error) {
            
            [TransmitHelper sharedInstance].isAuthenticated = NO;
            [deviceManagementSessionServices finishSession];
        }];
    } else if ([function isEqualToString:@"deactivate_other_device_msk"]) {
        NSString *device_id = [TransmitHelper sharedInstance].removeDeviceID;
        
        TSXManagedDevice *removeDevice = [[TSXManagedDevice alloc] init];
        if (self.devices) {
            for (TSXManagedDevice *device in self.devices) {
                if ([device_id isEqualToString:device.info.deviceId]) {
                    removeDevice = device;
                }
            }
        }
        
        if ([removeDevice.info.deviceId isEqualToString:device_id]) {
            [deviceManagementSessionServices removeDeviceWithDevice:removeDevice clientContext:@{} asynchronouslyWithHandler:^(BOOL result, TSXAuthenticationError * _Nullable error) {
                if (error) {
                    if ([self.delegate respondsToSelector:@selector(transmitHandleDeviceManagementWithType:error:)]) {
                        [self.delegate transmitHandleDeviceManagementWithType:@"deactivate_other_device_msk" error:error];
                    }
                }
                [deviceManagementSessionServices finishSession];
            }];
        } else {
            if ([self.delegate respondsToSelector:@selector(transmitHandleDeviceDeactivateNotFound)]) {
                [self.delegate transmitHandleDeviceDeactivateNotFound];
            }
        }
    } else if ([function isEqualToString:@"rename_current_device"]) {
        for (TSXManagedDevice *device in self.devices) {
            if (device.info.isCurrent) {
                NSString * deviceName = [[UIDevice currentDevice] name];
                [deviceManagementSessionServices renameDeviceWithDevice:device newName:deviceName clientContext:@{} asynchronouslyWithHandler:^(BOOL result, TSXAuthenticationError * _Nullable error) {
                    if (error) {
                        if ([self.delegate respondsToSelector:@selector(transmitHandleDeviceManagementWithType:error:)]) {
                            [self.delegate transmitHandleDeviceManagementWithType:@"rename_current_device" error:error];
                        }
                    }
                    [deviceManagementSessionServices finishSession];
                }];
            }
        }
    } else if ([function isEqualToString:@"get_current_device_id"]) {
        for (TSXManagedDevice *device in self.devices) {
            if (device.info.isCurrent) {
                [TransmitHelper sharedInstance].currentDeviceID = device.info.deviceId;
                [deviceManagementSessionServices finishSession];
            }
        }
    } else {
        [deviceManagementSessionServices finishSession];
    }
}
// 3
-(void)endSession{
    
}

@end

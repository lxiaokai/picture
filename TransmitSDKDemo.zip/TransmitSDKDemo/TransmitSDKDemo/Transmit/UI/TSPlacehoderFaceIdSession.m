//
//  TSPlacehoderFaceIdSession.m
//  HSBCHybrid
//
//  Created by lyd on 2018/6/25.
//

#import "TSPlacehoderFaceIdSession.h"

@interface TSPlacehoderFaceIdSession() <NSURLConnectionDelegate, NSURLConnectionDataDelegate>{
	
}

@end

@implementation TSPlacehoderFaceIdSession

-(void)startSessionWithDescription:(TSXAuthenticatorDescription* _Nonnull)description mode:(TSXAuthenticatorSessionMode)mode actionContext:(TSXPolicyAction* _Nullable)actionContext clientContext:(NSDictionary * _Nullable)clientContext {
}

-(void)promiseInputAsynchronouslyWithHandler:(void (^)(TSXInputOrControlResponse * _Nonnull))handler {
	self.currentHandler = handler;
	//[self invokeTokenAPI];
	[self.delegate getFaceIdContextData:self.serverPayload andCurrentHandler:self.currentHandler];
}

-(void)promiseRecoveryForErrorWithError:(TSXAuthenticationError *)error validRecoveries:(TSXAuthenticationErrorRecoverySet)validRecoveries defaultRecovery:(TSXAuthenticationErrorRecovery)defaultRecovery asynchronouslyWithHandler:(void (^)(TSXAuthenticationErrorRecovery))handler {
	handler(AuthenticationErrorRecoveryFail);
}

-(void)endSession {
	
}

@end

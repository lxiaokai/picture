//
//  TSApprovalSession.m
//  HSBCHybrid
//
//  Created by [Manuel L M Zhang] on 07/12/2017.
//  Copyright © 2017 HSBC. All rights reserved.
//

#import "TSApprovalSession.h"
#import "TransmitHelper.h"
#import "NSDate+Externsion.h"

@implementation TSApprovalSession

@synthesize expiredFlag;

-(void)setSessionApprovalsList:(NSArray<TSXManagedMobileApproval *> *)approvals {
    
    TSXManagedMobileApproval *latestMApproval = nil;
    if (approvals.count > 0) {
        latestMApproval = approvals.firstObject;
        for (TSXManagedMobileApproval *mApproval in approvals) {
            TSXMobileApproval *approval = mApproval.approval;
            
            int result = [NSDate compareOneDay:latestMApproval.approval.creationTime withAnotherDay:approval.creationTime];
            if (result == -1) {
                latestMApproval = mApproval;
            }
        }
    }
    
    NSString *selectedApproveId = [TransmitHelper sharedInstance].currentApproveId;
    if (selectedApproveId == nil) {
        self.tsManagedMobileApproval = latestMApproval;
    } else {
        
        if ([latestMApproval.approval.approvalId isEqualToString:selectedApproveId]) {
            self.tsManagedMobileApproval = latestMApproval;
        } else {
            self.tsManagedMobileApproval = nil;
        }
    }
    
//    self.tsManagedMobileApproval = approvals.firstObject;
    NSLog(@"last approval creationTime --- %@", self.tsManagedMobileApproval.approval.creationTime);
    
    if (self.tsManagedMobileApproval.approval.status == MobileApprovalStatusPending) {
        expiredFlag = @"false";
        [TransmitHelper sharedInstance].noPendingApproval = @"false";
    } else {
        expiredFlag = @"true";
        [TransmitHelper sharedInstance].noPendingApproval = @"true";
    }
    NSLog(@"TransmitApproveExpiredFlag:%@",expiredFlag);
    [TransmitHelper sharedInstance].expiredFlag = expiredFlag;
}

-(void)startSessionWithApprovalManagementSessionServices:(TSXApprovalManagementSessionServices *)approvalManagementSessionServices actionContext:(TSXPolicyAction *)actionContext clientContext:(NSDictionary *)clientContext {
    
    NSString *function = [clientContext objectForKey:@"function"];
    NSString *fromNative = [clientContext objectForKey:@"fromNative"];
    
    if ([function isEqualToString:@"TransmitCheckExpried"] || [function isEqualToString:@"TransmitCheckNotification"]) {
        if ([fromNative isEqualToString:@"true"]) {
            [TransmitHelper sharedInstance].tsApprovalService = approvalManagementSessionServices;
            [TransmitHelper sharedInstance].tsManagedApproval = self.tsManagedMobileApproval;
        } else {
            if([self.delegate respondsToSelector:@selector(TSApprovalSessionCheckExpiredFlag:withService:withApproval:)]){
                [self.delegate TSApprovalSessionCheckExpiredFlag:expiredFlag withService:approvalManagementSessionServices withApproval:self.tsManagedMobileApproval];
            }
        }
        [approvalManagementSessionServices finishSession];
        
    } else if ([function isEqualToString:@"RefreshApproveStatus"]) {
        if ([fromNative isEqualToString:@"true"]) {
            [approvalManagementSessionServices finishSession];
        } else {
            [approvalManagementSessionServices requestRefreshApprovalsAsynchronouslyWithHandler:^(BOOL result, TSXAuthenticationError * _Nullable error) {
                if (error) {
                    if ([self.delegate respondsToSelector:@selector(TSApprovalSessionWithType:error:)]) {
                        [self.delegate TSApprovalSessionWithType:function error:error];
                    }
                }
                
                [approvalManagementSessionServices finishSession];
            }];
        }
    } else if ([function isEqualToString:@"TransmitApprove"]) {
        if ([fromNative isEqualToString:@"true"] && [expiredFlag isEqualToString:@"true"]) {
            [approvalManagementSessionServices finishSession];
        } else {
            [approvalManagementSessionServices approveWithApproval:self.tsManagedMobileApproval clientContext:clientContext asynchronouslyWithHandler:^(TSXAuthenticationResult * _Nonnull res, TSXAuthenticationError * _Nullable error) {
                
                if (error) {
                    if ([fromNative isEqualToString:@"true"]) {
                        if ([self.delegate respondsToSelector:@selector(handleApprovalErrorWithFunctionType:error:)]) {
                            [self.delegate handleApprovalErrorWithFunctionType:function error:error];
                        }
                    } else {
                        if ([self.delegate respondsToSelector:@selector(TSApprovalSessionWithType:error:)]) {
                            [self.delegate TSApprovalSessionWithType:function error:error];
                        }
                    }
                } else {
                    if ([fromNative isEqualToString:@"true"]) {
                        // set expired flag "false" when approve success.
                        // when approve success, transmie will call setSessionApprovalsList method again before get callbback
                        [TransmitHelper sharedInstance].expiredFlag = @"false";
                    }
                }
                
                [approvalManagementSessionServices finishSession];
            }];
        }
    } else if ([function isEqualToString:@"TransmitDoNotApprove"]) {
        if ([fromNative isEqualToString:@"true"] && [expiredFlag isEqualToString:@"true"]) {
            [approvalManagementSessionServices finishSession];
        } else {
            [approvalManagementSessionServices denyWithApproval:self.tsManagedMobileApproval asynchronouslyWithHandler:^(BOOL result, TSXAuthenticationError * _Nullable error) {
                
                if (error) {
                    if ([fromNative isEqualToString:@"true"]) {
                        if ([self.delegate respondsToSelector:@selector(handleApprovalErrorWithFunctionType:error:)]) {
                            [self.delegate handleApprovalErrorWithFunctionType:function error:error];
                        }
                    } else {
                        if ([self.delegate respondsToSelector:@selector(TSApprovalSessionWithType:error:)]) {
                            [self.delegate TSApprovalSessionWithType:function error:error];
                        }
                    }
                } else {
                    if ([fromNative isEqualToString:@"true"]) {
                        // set expired flag "false" when approve success.
                        // when approve success, transmie will call setSessionApprovalsList method again before get callbback
                        [TransmitHelper sharedInstance].expiredFlag = @"false";
                    }
                }
                
                [approvalManagementSessionServices finishSession];
            }];
        }
    } else {
        [approvalManagementSessionServices finishSession];
    }
	
}

-(void)endSession {
    
}

@end

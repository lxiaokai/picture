//
//  TSPasswordInputSession.h
//  HSBCHybrid
//
//  Created by Janice on 2018/1/14.
//
//
#import <UIKit/UIKit.h>

#import <TransmitSDK3/TransmitSDK3.h>
#import <TransmitSDKUILayer/TSXDefaultUIHandler.h>
#import <TransmitSDKUILayer/TSXDefaultUIHandlerHostingContext.h>



@interface TSPasswordInputSession : TSXUIAuthenticatorSession<TSXPasswordInput *>{
    
}

@property (strong, nonatomic) void (^currentHandler)(TSXInputOrControlResponse<TSXPasswordInput*> *);

@property (nonatomic,strong) NSString *tsPassword;

@end

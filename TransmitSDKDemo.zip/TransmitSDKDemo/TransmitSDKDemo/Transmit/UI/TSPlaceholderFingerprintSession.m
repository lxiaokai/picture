//
//  TSPlaceholderFingerprintSession.m
//  HSBCHybrid
//
//  Created by [Manuel L M Zhang] on 07/12/2017.
//  Copyright © 2017 HSBC. All rights reserved.
//

#import "TSPlaceholderFingerprintSession.h"

@interface TSPlaceholderFingerprintSession() <NSURLConnectionDelegate, NSURLConnectionDataDelegate>{
    
}

@end

@implementation TSPlaceholderFingerprintSession

-(void)startSessionWithDescription:(TSXAuthenticatorDescription* _Nonnull)description mode:(TSXAuthenticatorSessionMode)mode actionContext:(TSXPolicyAction* _Nullable)actionContext clientContext:(NSDictionary * _Nullable)clientContext {
}

-(void)promiseInputAsynchronouslyWithHandler:(void (^)(TSXInputOrControlResponse * _Nonnull))handler {
    self.currentHandler = handler;
    //[self invokeTokenAPI];
    [self.delegate getContextData:self.serverPayload andCurrentHandler:self.currentHandler];
}

-(void)promiseRecoveryForErrorWithError:(TSXAuthenticationError *)error validRecoveries:(TSXAuthenticationErrorRecoverySet)validRecoveries defaultRecovery:(TSXAuthenticationErrorRecovery)defaultRecovery asynchronouslyWithHandler:(void (^)(TSXAuthenticationErrorRecovery))handler {
    handler(AuthenticationErrorRecoveryFail);
}

-(void)endSession {
    
}

@end

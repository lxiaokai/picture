//
//  ViewController.m
//  TransmitSDKDemo
//
//  Created by Alex on 2019/11/15.
//  Copyright © 2019 alex. All rights reserved.
//

#import "ViewController.h"
#import "TransmitHelper.h"
#import "LKAutoMessageDialog.h"
#import "OneViewController.h"
#import "TSCustomTransportProvider.h"

@interface ViewController ()

@property (nonatomic, strong) TransmitHelper *transmitHelper;

@property (weak, nonatomic) IBOutlet UITextField *accountTF;
@property (weak, nonatomic) IBOutlet UITextField *tokenTF;
@property (weak, nonatomic) IBOutlet UITextField *policyIdTF;

@end

@implementation ViewController



- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"Transmit";
    
    self.transmitHelper = [TransmitHelper sharedInstance];
    
    
}


- (IBAction)verifyAccount:(UIButton *)sender {
    
    NSDictionary *functionParams = @{@"callbackjs": @"iMobile.callBackHandler",
                                     @"function": @"TransmitStartActivateMSK",
                                     @"policyId": @"Verify_Username",
                                     @"skipOtp": @"undefined",
                                     @"username": self.accountTF.text,
                                     };
    __block __typeof(self) weakSelf = self;
    TSXTransmitSDKXm *sdk = [TSXTransmitSDKXm sharedInstance];
    [self.transmitHelper handleTransmitStartActivateMSK:functionParams completionWithHandler:^(TSXAuthenticationResult * _Nonnull result, TSXAuthenticationError * _Nullable error) {
        if(error) {
            
        } else {
            [LKAutoMessageDialog showWithMessage:@"verifyAccount success"];
        }
    }];
}

- (IBAction)clickLogonBtn:(UIButton *)sender {

    //TokenlessPoc
    TSXTransmitSDKXm *sdk = [TSXTransmitSDKXm sharedInstance];
    NSString *user = self.accountTF.text;
 
//    [sdk invokePolicyWithPolicyId:@"TokenlessPoc" additionalParameters:@{} clientContext:[self defaultClientContext] asynchronouslyWithHandler:^(TSXAuthenticationResult * _Nonnull result, TSXAuthenticationError * _Nullable error) {
//        //handler(result, error);
//    }];
    [sdk authenticateWithUserId:user policyId:@"TokenlessPoc" additionalParameters:nil clientContext:[self defaultClientContext] asynchronouslyWithHandler:^(TSXAuthenticationResult * result, TSXAuthenticationError * err) {
         NSLog(@"+++  %@", result);
         NSLog(@" %@ ~~~ %@ ~~~ %@", result.data, result.deviceId, result.token);
    }];
    //        [sdk startApprovalsSessionForCurrentSessionWithClientContext:[self clientContext] asynchronouslyWithHandler:^(BOOL res, TSXAuthenticationError * _Nullable err) {
    //            NSLog(@"+++  %d", res);
    //        }];
    
    // 显示身份验证器配置
    //        [sdk startAuthenticationConfigurationWithClientContext:[self cl ientContext] asynchronouslyWithHandler:^(BOOL res, TSXAuthenticationError * _Nullable err) {
    //            NSLog(@"+++  %d", res);
    //        }];
    
    //        [sdk startDeviceManagementSessionWithClientContext:[self clientContext] asynchronouslyWithHandler:^(BOOL res, TSXAuthenticationError * _Nullable err) {
    //            NSLog(@"+++  %d", res);
    //        }];
}

-(void) promptIntroductionWithTitle:(NSString *)title text:(NSString *)text continueText:(NSString *)continueText cancelText:(NSString *)cancelText asynchronouslyWithHandler:(void (^)(TSXPromotionInput * _Nonnull))handler {
    NSLog(@"title: %@  textr:%@  continueText:%@ cancelText:%@", title, text, continueText, cancelText);
}



- (IBAction)click:(UIButton *)sender {
    TSXTransmitSDKXm *sdk = [TSXTransmitSDKXm sharedInstance];
    NSString *user = self.accountTF.text;
    __weak typeof(self) weakSelf = self;
    
    [sdk authenticateWithUserId:user policyId:@"testotp" additionalParameters:nil clientContext:[self defaultClientContext] asynchronouslyWithHandler:^(TSXAuthenticationResult * result, TSXAuthenticationError * err) {
        NSLog(@"+++  %@", result);
        NSLog(@" %@ ~~~ %@ ~~~ %@", result.data, result.deviceId, result.token);

//        [sdk startApprovalsSessionForCurrentSessionWithClientContext:[self defaultClientContext] asynchronouslyWithHandler:^(BOOL res, TSXAuthenticationError * _Nullable err) {
//
//        }];
        //[[TSXDefaultUIHandler hostingContextFromClientContext:[weakSelf defaultClientContext]] teardownUi];
    }];
    
  
}

- (NSDictionary *)defaultClientContext {
    return [TSXDefaultUIHandler createClientContextForPresentingViewController:self];
}

- (NSDictionary *)customClientContext {
    return [TSXDefaultUIHandler createClientContextForPresentingViewController:[[OneViewController alloc] init]];
}

- (void)onConfigureAuthenticators {
    TSXTransmitSDKXm *sdk = [TSXTransmitSDKXm sharedInstance];
    [sdk startAuthenticationConfigurationWithClientContext:[self defaultClientContext] asynchronouslyWithHandler:^(BOOL res, TSXAuthenticationError * _Nullable err) {
        
    }];
}

- (void)onShowApprovals {
    TSXTransmitSDKXm *sdk = [TSXTransmitSDKXm sharedInstance];
    [sdk startApprovalsSessionForCurrentSessionWithClientContext:[self defaultClientContext] asynchronouslyWithHandler:^(BOOL res, TSXAuthenticationError * _Nullable err) {
        NSLog(@"%@", err);
    }];
}


- (void)logon {
    NSString *user = self.accountTF.text;
    TSXTransmitSDKXm *sdk = [TSXTransmitSDKXm sharedInstance];
    if (![sdk isBoundForUserWithUserId:user]) {
        [sdk bindWithUserId:user additionalParameters:@{} clientContext:[self defaultClientContext] asynchronouslyWithHandler:^(TSXAuthenticationResult * _Nullable res, TSXAuthenticationError * _Nullable err) {
            if (err) {
                
            }
        }];
    } else {
        //TokenlessPoc
        [sdk authenticateWithUserId:user policyId:@"TokenlessPoc" additionalParameters:@{} clientContext:[self defaultClientContext] asynchronouslyWithHandler:^(TSXAuthenticationResult * _Nullable res, TSXAuthenticationError * _Nullable err) {
            
            
        
        }];
        
        
    }
}



@end

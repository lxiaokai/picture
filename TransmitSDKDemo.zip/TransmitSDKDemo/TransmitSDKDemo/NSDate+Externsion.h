//
//  NSDate+Externsion.h
//  HSBCHybrid
//
//  Created by GBB-Mobile on 15/12/17.
//

#import <Foundation/Foundation.h>

@interface NSDate (Externsion)

+ (int)compareOneDay:(NSDate *)oneDay withAnotherDay:(NSDate *)anotherDay;

+ (NSDate *)getDateFromString: (NSString *)dateStr formatter: (NSString *)formatter;

+ (NSString *)getStringFromDate: (NSDate *)date formatter: (NSString *)formatter;

+ (NSDate *)getLaterDateFromDate:(NSDate *)date withYear:(NSInteger)year month:(NSInteger)month day:(NSInteger)day;

@end

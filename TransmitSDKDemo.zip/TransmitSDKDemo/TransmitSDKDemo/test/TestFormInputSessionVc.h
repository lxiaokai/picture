//
//  TestFormInputSessionVc.h
//  TSXMSampleApp
//
//  Created by Eldan Ben Haim on 01/04/2018.
//  Copyright © 2018 Transmit Security. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TestFormInputSession.h"

@protocol FormInputSessionVcDelegate

-(void)receiveFormInput:(NSDictionary*)formInput;
-(void)cancelFormInput;

@end

@interface TestFormInputSessionVc : UIViewController

@property (nonatomic)TestFormInputSession *testFormInputSession;

@property NSDictionary *currentPayload;
@property (nonatomic) NSString *formIdentifier;

-(void)showFormError:(NSString*)errorMessage;
-(void)showFormContinuePrompt:(NSString*)continuePrompt;

@property (weak) NSObject<FormInputSessionVcDelegate>* delegate;

@end

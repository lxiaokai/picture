//
//  TestFormInputSession.h
//  TransmitSDK3Static
//
//  Created by Eldan Ben Haim on 01/04/2018.
//  Copyright © 2018 TransmitSecurity. All rights reserved.
//

#import <TransmitSDKUILayer/TransmitSDKUILayer.h>

@interface TestFormInputSession : TSXUIFormSession

-(instancetype)initWithFormId:(NSString*)formId payload:(NSDictionary*)payload;

@end

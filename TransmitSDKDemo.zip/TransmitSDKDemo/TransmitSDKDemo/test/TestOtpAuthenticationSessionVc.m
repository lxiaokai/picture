//
//  TestOtpAuthenticationSessionVc.m
//  NoUIApp
//
//  Created by Eldan Ben Haim on 11/09/2017.
//  Copyright © 2017 Eran Berkovitz. All rights reserved.
//

#import "TestOtpAuthenticationSessionVc.h"

@interface TestOtpAuthenticationSessionVc () {
    TSXOtpTarget* _currentTarget;
    TSXOtpFormat* _currentFormat;    
}

@property (weak, nonatomic) IBOutlet UITextField *passwordField;
@property (weak, nonatomic) IBOutlet UILabel *errorBar;
@property (weak, nonatomic) IBOutlet UILabel *otpSentLabel;
@property (weak, nonatomic) IBOutlet UIView *otpInputHost;

@end

@implementation TestOtpAuthenticationSessionVc

-(void)setupForOtpTarget:(TSXOtpTarget*)target format:(TSXOtpFormat*)format
{
    _currentTarget = target;
    _currentFormat = format;
    
    if(!_currentTarget) {
        self.otpSentLabel.text = @"Please select target to generate OTP.";
        return;
    }
    
    if([_currentFormat isKindOfClass:[TSXOtpFormatNumeric class]]) {
        long otpLen = [(TSXOtpFormatNumeric*)_currentFormat otpLength];
        self.otpSentLabel.text = [NSString stringWithFormat:@"An OTP was sent to '%@'. Len=%lu. Please type the OTP you received below.", target.description, otpLen];
    } else
    if([_currentFormat isKindOfClass:[TSXOtpFormatQr class]]) {
        self.otpSentLabel.text = [NSString stringWithFormat:@"A QR OTP was sent to '%@'. Please type the content of the QR code you received below.", target.description];
    } else
    if([_currentFormat isKindOfClass:[TSXOtpFormatExternal class]]) {
        TSXOtpFormatExternal *extFormat = (TSXOtpFormatExternal*)_currentFormat;
        NSData *extFormatJsonData = [extFormat data] ? [NSJSONSerialization dataWithJSONObject:[extFormat data]
                                                                                       options:0
                                                                                         error:nil] :
                                                        [@"<<nil>>" dataUsingEncoding:NSUTF8StringEncoding];
        
        self.otpSentLabel.text = [NSString stringWithFormat:@"An OTP with external format was sent to '%@'. Format parameters: %@. Please type OTP input below.",
                                  target.description,
                                  [[NSString alloc] initWithData:extFormatJsonData
                                                        encoding:NSUTF8StringEncoding]
                                  ];
    }
    
    [self.view layoutSubviews];
}

-(void)viewDidLoad {
    self.navigationItem.hidesBackButton = YES;
    self.navigationItem.title = @"OTP Authentication";
    self.navigationItem.leftBarButtonItems = @[
                                               [[UIBarButtonItem alloc] initWithTitle:@"Cancel" style:UIBarButtonItemStylePlain target:self action:@selector(cancelClicked:)]
                                               ];
    
    [self.errorBar.topAnchor constraintEqualToAnchor:self.topLayoutGuide.bottomAnchor].active = true;
}

-(void)setErrorPrompt:(NSString*)prompt {
    self.errorBar.text = prompt;
    self.errorBar.hidden = NO;
}

- (IBAction)cancelClicked:(id)sender {
    [self.session cancelAuthenticator];
}

-(IBAction)otpSubmitted:(id)sender {
    [self.session userSubmittedOtp:self.passwordField.text];
}

- (IBAction)resendOtpRequested:(id)sender {
    [self.session resendOtpRequested];
}

-(void)selectTarget {
    UIAlertController *targetSelectorAlert = [UIAlertController alertControllerWithTitle:@"Select OTP Target" message:@"Please select target for OTP delivery" preferredStyle:UIAlertControllerStyleActionSheet];
    
    for(TSXOtpTarget *target in self.session.targets) {
        TSXOtpTarget *curTarget = target;
        [targetSelectorAlert addAction:[UIAlertAction actionWithTitle:[NSString stringWithFormat:@"%@ (%lu)",
                                                                       target.description, (unsigned long)target.channel]
                                                                style:UIAlertActionStyleDefault
                                                              handler:^(UIAlertAction * _Nonnull action) {
                                                                  [self.session userSelectedTarget:curTarget];
                                                              }]];
    }
    
    [targetSelectorAlert addAction:[UIAlertAction actionWithTitle:@"Cancel"
                                                            style:UIAlertActionStyleDestructive
                                                          handler:^(UIAlertAction * _Nonnull action) {
                                                              if(!_currentTarget) {
                                                                  [self.session cancelAuthenticator];
                                                              }
                                                          }]];

    UIPopoverPresentationController *popover = targetSelectorAlert.popoverPresentationController;
    if (popover) {
        popover.sourceView = self.view;
        popover.sourceRect = self.view.bounds;
        popover.permittedArrowDirections = 0;
    }
    
    [self presentViewController:targetSelectorAlert animated:YES completion:nil];
}

@end

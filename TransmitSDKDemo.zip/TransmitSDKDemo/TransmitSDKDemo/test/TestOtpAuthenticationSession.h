//
//  TestOtpAuthenticationSession.h
//  NoUIApp
//
//  Created by Eldan Ben Haim on 11/09/2017.
//  Copyright © 2017 Eran Berkovitz. All rights reserved.
//

#import "TSXTestUIHandler.h"

@interface TestOtpAuthenticationSession : TSXUIAuthenticatorSessionOtp

-(instancetype)initWithTargets:(NSArray<TSXOtpTarget*>*)targets
                selectedTarget:(TSXOtpTarget*)selectedTarget;

// Callbacks from VC
-(void)userSubmittedOtp:(NSString*)otp;
-(void)resendOtpRequested;
-(void)userSelectedTarget:(TSXOtpTarget*)target;
-(void)cancelAuthenticator;

@property (readonly) NSArray<TSXOtpTarget*>* targets;

@end

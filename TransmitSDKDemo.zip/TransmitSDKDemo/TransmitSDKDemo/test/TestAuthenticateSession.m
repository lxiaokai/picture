//
//  TestAuthenticateSession.m
//  TransmitSDKDemo
//
//  Created by Alex on 2020/1/6.
//  Copyright © 2020 alex. All rights reserved.
//

#import "TestAuthenticateSession.h"

@implementation TestAuthenticateSession

-(instancetype)initWithUserId:(NSString*)userId {
    self = [super init];
    
    
    return self;
}

@end

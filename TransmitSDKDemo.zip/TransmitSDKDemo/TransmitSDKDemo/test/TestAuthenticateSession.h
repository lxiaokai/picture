//
//  TestAuthenticateSession.h
//  TransmitSDKDemo
//
//  Created by Alex on 2020/1/6.
//  Copyright © 2020 alex. All rights reserved.
//

#import <TransmitSDK3/TransmitSDK3.h>

NS_ASSUME_NONNULL_BEGIN

@interface TestAuthenticateSession : TSXUIAuthenticationConfigurationSession

-(instancetype)initWithUserId:(NSString*)userId;


@end

NS_ASSUME_NONNULL_END

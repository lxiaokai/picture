//
//  NSDate+Externsion.m
//  HSBCHybrid
//
//  Created by GBB-Mobile on 15/12/17.
//

#import "NSDate+Externsion.h"

@implementation NSDate (Externsion)

+ (NSDate *)getDateFromString: (NSString *)dateStr formatter: (NSString *)formatter {
    NSDateFormatter *format = [[NSDateFormatter alloc]init];
    [format setDateFormat:formatter];
    NSDate *endDate = [format dateFromString:dateStr];
    return endDate;
}

+ (NSString *)getStringFromDate: (NSDate *)date formatter: (NSString *)formatter {
    NSTimeZone *timeZone = [NSTimeZone timeZoneWithName:@"HKT"];
    NSDateFormatter *format = [[NSDateFormatter alloc] init];
    [format setDateFormat:formatter];
    [format setTimeZone:timeZone];
    
    NSString *dateStr = [format stringFromDate:date];
    return dateStr;
}

+ (NSDate *)getLaterDateFromDate:(NSDate *)date withYear:(NSInteger)year month:(NSInteger)month day:(NSInteger)day {
    NSCalendar *calendar = [[NSCalendar alloc] initWithCalendarIdentifier:NSCalendarIdentifierGregorian];
    
    NSDateComponents *adcomps = [[NSDateComponents alloc] init];
    
    [adcomps setYear:year];
    [adcomps setMonth:month];
    [adcomps setDay:day];
    
    NSDate *newdate = [calendar dateByAddingComponents:adcomps toDate:date options:0];
    return newdate;
}

+ (int)compareOneDay:(NSDate *)oneDay withAnotherDay:(NSDate *)anotherDay {
    
    NSString *oneDayStr = [self getStringFromDate:oneDay formatter:@"yyyy-MM-dd HH:mm:ss"];
    NSString *anotherDayStr = [self getStringFromDate:anotherDay formatter:@"yyyy-MM-dd HH:mm:ss"];
    
    NSComparisonResult result = [oneDayStr compare:anotherDayStr];
    if (result == NSOrderedDescending) {
        return 1;
    } else if (result == NSOrderedAscending) {
        return -1;
    }
    return 0;
}

@end
